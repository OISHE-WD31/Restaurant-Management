-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 24, 2026 at 07:58 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `restaurant_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `role` enum('owner','manager','kitchen') NOT NULL DEFAULT 'owner'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `name`, `email`, `password_hash`, `created_at`, `role`) VALUES
(1, 'mim09876543', 'admin@osh.com', '$2y$10$nR6FWDbbLLb2/OOiSZsmreEyJhQlf16YpOyZLTKenwOqW1pgT4RPO', '2026-11-21 18:58:08', 'owner'),
(3, 'oishu', 'oishe43322@gmail.com', '$2y$10$9g5OyChBlQZYkorRwAtjIOCeZaSMVnb3i5SSW4GNRrNoVQeod1tcC', '2026-11-23 14:03:28', 'manager'),
(5, 'alu', 'alu09875566@gmail.com', '$2y$10$fE24bNqLEsF3t8ai63tBZ.0tX0PV2TG.1M0J/ZJGF4lJ7bs6V3jwC', '2026-11-23 14:12:58', 'kitchen'),
(6, 'anissaaa', 'anishe5423@osh.com', '$2y$10$G2guQ9g7gPmFgYaxInTqjuN7M3GwFUyqU0uHAl2QyIbJB.IiywP/S', '2026-11-24 05:55:52', 'kitchen');

-- --------------------------------------------------------

--
-- Table structure for table `admin_notifications`
--

CREATE TABLE `admin_notifications` (
  `id` int(11) NOT NULL,
  `type` varchar(20) NOT NULL,
  `title` varchar(150) NOT NULL,
  `message` varchar(500) NOT NULL,
  `related_id` int(11) NOT NULL DEFAULT 0,
  `link` varchar(255) NOT NULL DEFAULT '',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admin_notifications`
--

INSERT INTO `admin_notifications` (`id`, `type`, `title`, `message`, `related_id`, `link`, `created_at`) VALUES
(1, 'order', 'New order received', 'Order ORD2611225FD507 placed by alu · ৳730 · Cash on Delivery', 4, 'orders.php?q=ORD2611225FD507', '2026-11-22 15:22:41'),
(2, 'reservation', 'New reservation request', 'Oishe · 2026-11-25 15:30 · 2 guests', 1, 'reservations.php?date=2026-11-25', '2026-11-22 16:42:23'),
(3, 'reservation', 'New reservation request', 'alu · 2026-11-25 16:00 · 6 guests', 2, 'reservations.php?date=2026-11-25', '2026-11-22 16:45:10'),
(4, 'order', 'New order received', 'Order ORD261122C3752E placed by alu · ৳980 · Cash on Delivery', 5, 'orders.php?q=ORD261122C3752E', '2026-11-22 19:21:33'),
(5, 'order', 'New order received', 'Order ORD26112282EC7B placed by alu · ৳460 · Cash on Delivery', 6, 'orders.php?q=ORD26112282EC7B', '2026-11-22 19:26:13'),
(6, 'reservation', 'New reservation request', 'alu · 2026-11-27 18:30 · 4 guests', 3, 'reservations.php?date=2026-11-27', '2026-11-23 04:48:24'),
(7, 'reservation', 'New reservation request', 'alu · 2026-11-27 18:30 · 4 guests', 4, 'reservations.php?date=2026-11-27', '2026-11-23 04:49:54'),
(8, 'reservation', 'New reservation request', 'alu · 2026-11-28 16:30 · 2 guests', 5, 'reservations.php?date=2026-11-28', '2026-11-23 05:20:52'),
(9, 'reservation', 'New reservation request', 'alu · 2026-11-28 16:30 · 2 guests', 6, 'reservations.php?date=2026-11-28', '2026-11-23 05:22:00'),
(10, 'customer', 'New customer registered', 'Mim (mim33123@gmil.com) created an account.', 2, 'customers.php?view=2', '2026-11-23 13:58:15'),
(11, 'order', 'New order received', 'Order ORD2611232ADAC0 placed by Mim · ৳4,413 · Cash on Delivery', 7, 'orders.php?q=ORD2611232ADAC0', '2026-11-23 18:36:03'),
(12, 'reservation', 'New reservation request', 'Mim · 2026-11-24 09:00 · 2 guests', 7, 'reservations.php?date=2026-11-24', '2026-11-23 19:05:21');

-- --------------------------------------------------------

--
-- Table structure for table `admin_notification_state`
--

CREATE TABLE `admin_notification_state` (
  `admin_id` int(11) NOT NULL,
  `notification_id` int(11) NOT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admin_notification_state`
--

INSERT INTO `admin_notification_state` (`admin_id`, `notification_id`, `is_read`, `is_deleted`) VALUES
(1, 1, 1, 0),
(1, 2, 1, 0),
(1, 3, 1, 0),
(1, 4, 1, 0),
(1, 5, 1, 0),
(1, 6, 1, 0),
(1, 7, 1, 0),
(1, 8, 1, 0),
(1, 9, 1, 0),
(1, 10, 1, 0),
(1, 11, 1, 0),
(1, 12, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `carts`
--

CREATE TABLE `carts` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `variation_id` int(11) DEFAULT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `slug` varchar(120) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `sort_order` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `slug`, `image`, `sort_order`, `created_at`) VALUES
(1, '🍕 Pizza', 'pizza', '3531e9d2a34a1a1da96e.jpg', 7, '2026-11-21 18:50:02'),
(5, '🍔 Burgers', 'burgers', NULL, 1, '2026-11-21 21:12:46'),
(6, '🍝 Pasta', 'pasta', NULL, 2, '2026-11-21 21:13:19'),
(7, '🍗 Main Course', 'main-course', NULL, 3, '2026-11-21 21:16:01'),
(8, '🥗 Salads', 'salads', NULL, 4, '2026-11-21 21:16:22'),
(9, '🥤 Drinks', 'drinks', NULL, 6, '2026-11-21 21:16:38'),
(10, '🍰 Desserts', 'desserts', NULL, 7, '2026-11-21 21:16:55'),
(11, '⭐ Chef\'s Specials', 'chef-s-specials', NULL, 1, '2026-11-21 21:17:13');

-- --------------------------------------------------------

--
-- Table structure for table `contact_messages`
--

CREATE TABLE `contact_messages` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `message` text NOT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `contact_messages`
--

INSERT INTO `contact_messages` (`id`, `name`, `email`, `message`, `is_read`, `created_at`) VALUES
(1, 'mim', 'imim56634@gmail.com', 'your food is too much bad i dont like is ,', 0, '2026-11-21 19:13:56');

-- --------------------------------------------------------

--
-- Table structure for table `coupons`
--

CREATE TABLE `coupons` (
  `id` int(11) NOT NULL,
  `code` varchar(40) NOT NULL,
  `type` enum('percent','fixed') NOT NULL,
  `value` decimal(10,2) NOT NULL,
  `expires_at` date DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `max_uses` int(11) DEFAULT NULL,
  `used_count` int(11) NOT NULL DEFAULT 0,
  `customer_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `coupons`
--

INSERT INTO `coupons` (`id`, `code`, `type`, `value`, `expires_at`, `is_active`, `max_uses`, `used_count`, `customer_id`) VALUES
(1, '3106', 'percent', 30.00, '2026-11-24', 1, NULL, 1, NULL),
(2, '0631', 'fixed', 50.00, '2026-12-25', 1, NULL, 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `gender` enum('male','female','other') DEFAULT NULL,
  `address` text DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `name`, `email`, `phone`, `gender`, `address`, `password_hash`, `is_active`, `created_at`) VALUES
(1, 'alu', 'alu0987@gmail.com', '94989085983', NULL, NULL, '$2y$10$NdaBkoHhuxCo31aB8PZa8uPyLAWuxlQhpOuKJmqgvK9C0cYHLq1dm', 1, '2026-11-21 19:01:34'),
(2, 'Mim', 'mim33123@gmil.com', '0173456708', NULL, NULL, '$2y$10$PQlQ6/L1JZrGmY.4SKBf9etLoU2GWDqJ2qy3ZGVY5EXMkezkUdN8S', 1, '2026-11-23 13:58:15');

-- --------------------------------------------------------

--
-- Table structure for table `customer_addresses`
--

CREATE TABLE `customer_addresses` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `address_type` enum('home','work','other') NOT NULL DEFAULT 'home',
  `full_address` varchar(255) NOT NULL,
  `city` varchar(80) NOT NULL DEFAULT '',
  `area` varchar(80) DEFAULT NULL,
  `postal_code` varchar(20) DEFAULT NULL,
  `instructions` varchar(255) DEFAULT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `customer_notifications`
--

CREATE TABLE `customer_notifications` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `type` varchar(40) NOT NULL,
  `title` varchar(150) NOT NULL,
  `message` varchar(600) NOT NULL,
  `reservation_id` int(11) DEFAULT NULL,
  `order_id` int(11) DEFAULT NULL,
  `reason` varchar(40) DEFAULT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `customer_notifications`
--

INSERT INTO `customer_notifications` (`id`, `customer_id`, `type`, `title`, `message`, `reservation_id`, `order_id`, `reason`, `is_read`, `created_at`) VALUES
(1, 1, 'reservation_cancelled', 'Reservation RSV05CDA6 was cancelled', 'Your reservation RSV05CDA6 for 28 Nov 2026 at 4:30 PM (2 guests) was cancelled. Reason: Table unavailable.', 5, NULL, 'table_unavailable', 1, '2026-11-23 05:21:54'),
(2, 2, 'order_preparing', 'Order is being prepared', 'Our kitchen is now preparing your order ORD2611232ADAC0.', NULL, 7, NULL, 1, '2026-11-23 18:36:40'),
(3, 2, 'order_delivered', 'Order delivered', 'Your order ORD2611232ADAC0 was delivered. Enjoy your meal!', NULL, 7, NULL, 1, '2026-11-23 18:37:07'),
(4, 2, 'reservation_booked', 'Reservation received', 'We received your reservation request RSVE99C34. We will confirm it shortly. (24 Nov 2026 at 9:00 AM, 2 guests)', 7, NULL, NULL, 1, '2026-11-23 19:05:21'),
(5, 2, 'reservation_confirmed', 'Reservation confirmed', 'Your reservation RSVE99C34 is confirmed. We look forward to seeing you! (24 Nov 2026 at 9:00 AM, 2 guests)', 7, NULL, NULL, 1, '2026-11-23 19:08:33');

-- --------------------------------------------------------

--
-- Table structure for table `ingredients`
--

CREATE TABLE `ingredients` (
  `id` int(11) NOT NULL,
  `name` varchar(120) NOT NULL,
  `unit` enum('kg','g','l','ml','piece','packet') NOT NULL,
  `stock` decimal(14,3) NOT NULL DEFAULT 0.000,
  `min_stock` decimal(14,3) NOT NULL DEFAULT 0.000,
  `unit_cost` decimal(12,4) NOT NULL DEFAULT 0.0000,
  `supplier_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `ingredients`
--

INSERT INTO `ingredients` (`id`, `name`, `unit`, `stock`, `min_stock`, `unit_cost`, `supplier_id`, `created_at`) VALUES
(1, 'Chicken', 'kg', 50.000, 5.000, 150.0000, 1, '2026-11-23 19:29:44'),
(2, 'Beef', 'kg', 29.000, 5.000, 700.0000, 5, '2026-11-23 19:33:33'),
(3, 'Potato', 'kg', 12.000, 2.000, 200.0000, 4, '2026-11-23 19:34:00'),
(4, 'Onion', 'kg', 12.000, 2.000, 100.0000, 4, '2026-11-23 19:34:31'),
(5, 'Cheese', 'packet', 22.000, 5.000, 200.0000, 1, '2026-11-23 19:35:31'),
(6, 'Butter', 'piece', 50.000, 5.000, 70.0000, 3, '2026-11-23 19:36:11');

-- --------------------------------------------------------

--
-- Table structure for table `inventory_movements`
--

CREATE TABLE `inventory_movements` (
  `id` int(11) NOT NULL,
  `ingredient_id` int(11) NOT NULL,
  `type` enum('purchase','order_deduction','order_restore','adjustment','wastage') NOT NULL,
  `quantity` decimal(14,3) NOT NULL,
  `balance_after` decimal(14,3) NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  `unit_cost` decimal(12,4) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `inventory_movements`
--

INSERT INTO `inventory_movements` (`id`, `ingredient_id`, `type`, `quantity`, `balance_after`, `order_id`, `note`, `unit_cost`, `created_by`, `created_at`) VALUES
(1, 1, 'adjustment', 50.000, 50.000, NULL, 'Opening stock', NULL, 1, '2026-11-23 19:29:44'),
(2, 2, 'adjustment', 29.000, 29.000, NULL, 'Opening stock', NULL, 1, '2026-11-23 19:33:33'),
(3, 3, 'adjustment', 12.000, 12.000, NULL, 'Opening stock', NULL, 1, '2026-11-23 19:34:00'),
(4, 4, 'adjustment', 12.000, 12.000, NULL, 'Opening stock', NULL, 1, '2026-11-23 19:34:31'),
(5, 5, 'adjustment', 22.000, 22.000, NULL, 'Opening stock', NULL, 1, '2026-11-23 19:35:31'),
(6, 6, 'adjustment', 50.000, 50.000, NULL, 'Opening stock', NULL, 1, '2026-11-23 19:36:11');

-- --------------------------------------------------------

--
-- Table structure for table `login_attempts`
--

CREATE TABLE `login_attempts` (
  `id` int(11) NOT NULL,
  `scope` enum('customer','admin') NOT NULL,
  `identifier` varchar(190) NOT NULL,
  `ip` varchar(45) NOT NULL DEFAULT '',
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `login_attempts`
--

INSERT INTO `login_attempts` (`id`, `scope`, `identifier`, `ip`, `created_at`) VALUES
(1, 'customer', 'admin@osh.com', '::1', '2026-11-23 14:56:30'),
(2, 'customer', 'alu09875566@gmail.com', '::1', '2026-11-23 18:15:33'),
(3, 'admin', 'alu0987@gmail.com', '::1', '2026-11-23 19:32:41'),
(4, 'customer', 'alu0987@gmail.com', '::1', '2026-11-23 19:33:26');

-- --------------------------------------------------------

--
-- Table structure for table `loyalty_accounts`
--

CREATE TABLE `loyalty_accounts` (
  `customer_id` int(11) NOT NULL,
  `points_balance` int(11) NOT NULL DEFAULT 0,
  `lifetime_points` int(11) NOT NULL DEFAULT 0,
  `tier` enum('bronze','silver','gold','vip') NOT NULL DEFAULT 'bronze',
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `loyalty_accounts`
--

INSERT INTO `loyalty_accounts` (`customer_id`, `points_balance`, `lifetime_points`, `tier`, `updated_at`) VALUES
(1, 222, 222, 'bronze', '2026-11-23 12:49:16'),
(2, 0, 0, 'bronze', '2026-11-23 13:58:32');

-- --------------------------------------------------------

--
-- Table structure for table `loyalty_transactions`
--

CREATE TABLE `loyalty_transactions` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `type` enum('earn','reverse','redeem','adjust') NOT NULL,
  `points` int(11) NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `loyalty_transactions`
--

INSERT INTO `loyalty_transactions` (`id`, `customer_id`, `type`, `points`, `order_id`, `note`, `created_by`, `created_at`) VALUES
(1, 1, 'earn', 94, 1, 'Order ORD261121F8162D', NULL, '2026-11-23 12:49:16'),
(2, 1, 'earn', 90, 5, 'Order ORD261122C3752E', NULL, '2026-11-23 12:49:16'),
(3, 1, 'earn', 38, 6, 'Order ORD26112282EC7B', NULL, '2026-11-23 12:49:16');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `order_no` varchar(30) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `full_name` varchar(100) NOT NULL,
  `phone` varchar(30) NOT NULL,
  `email` varchar(150) DEFAULT NULL,
  `address` text NOT NULL,
  `notes` text DEFAULT NULL,
  `subtotal` decimal(10,2) NOT NULL,
  `delivery_charge` decimal(10,2) DEFAULT 0.00,
  `discount` decimal(10,2) DEFAULT 0.00,
  `total` decimal(10,2) NOT NULL,
  `coupon_id` int(11) DEFAULT NULL,
  `payment_method` enum('cod','online') NOT NULL,
  `payment_status` enum('unpaid','paid','failed','cancelled','refunded') DEFAULT 'unpaid',
  `status` enum('pending','confirmed','preparing','ready','out_for_delivery','delivered','cancelled') NOT NULL DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `order_source` enum('website','kiosk','admin') NOT NULL DEFAULT 'website',
  `order_type` enum('delivery','takeaway','dine_in') NOT NULL DEFAULT 'delivery',
  `table_id` int(11) DEFAULT NULL,
  `stock_deducted` tinyint(1) NOT NULL DEFAULT 0,
  `confirmed_at` datetime DEFAULT NULL,
  `ready_at` datetime DEFAULT NULL,
  `delivered_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `order_no`, `customer_id`, `full_name`, `phone`, `email`, `address`, `notes`, `subtotal`, `delivery_charge`, `discount`, `total`, `coupon_id`, `payment_method`, `payment_status`, `status`, `created_at`, `order_source`, `order_type`, `table_id`, `stock_deducted`, `confirmed_at`, `ready_at`, `delivered_at`) VALUES
(1, 'ORD261121F8162D', 1, 'alu', '94989085983', 'alu0987@gmail.com', 'Madaripur chowresta', 'mosjid er samne', 740.00, 60.00, 0.00, 800.00, NULL, 'cod', 'paid', 'delivered', '2026-11-21 19:02:15', 'website', 'delivery', NULL, 1, NULL, NULL, NULL),
(2, 'ORD261121CDFC11', 1, 'alu', '94989085983', 'alu0987@gmail.com', 'old bus stand', 'infront of mou shop', 854.00, 60.00, 256.20, 657.80, 1, 'cod', 'paid', 'cancelled', '2026-11-21 19:29:03', 'website', 'delivery', NULL, 1, NULL, NULL, NULL),
(3, 'ORD261122DEC86A', 1, 'alu', '94989085983', 'alu0987@gmail.com', 'sfs dg dbd  dd', 'sf grgv drg', 3300.00, 80.00, 0.00, 3380.00, NULL, 'cod', 'unpaid', 'out_for_delivery', '2026-11-22 14:54:01', 'website', 'delivery', NULL, 1, '2026-11-23 02:49:32', '2026-11-23 02:49:38', NULL),
(4, 'ORD2611225FD507', 1, 'alu', '94989085983', 'alu0987@gmail.com', 'Itlay , vanice', 'Vanice', 650.00, 80.00, 0.00, 730.00, NULL, 'cod', 'unpaid', 'out_for_delivery', '2026-11-22 15:22:41', 'website', 'delivery', NULL, 1, '2026-11-23 02:49:57', '2026-11-23 02:50:04', NULL),
(5, 'ORD261122C3752E', 1, 'alu', '94989085983', 'alu0987@gmail.com', 'old bus stand', 'old bus stand', 900.00, 80.00, 0.00, 980.00, NULL, 'cod', 'paid', 'delivered', '2026-11-22 19:21:33', 'website', 'delivery', NULL, 1, NULL, NULL, '2026-11-23 01:22:02'),
(6, 'ORD26112282EC7B', 1, 'alu', '94989085983', 'alu0987@gmail.com', 'chowresta ,madaripur', 'chowresta ,madaripur', 380.00, 80.00, 0.00, 460.00, NULL, 'cod', 'paid', 'delivered', '2026-11-22 19:26:13', 'website', 'delivery', NULL, 1, NULL, NULL, '2026-11-23 01:26:37'),
(7, 'ORD2611232ADAC0', 2, 'Mim', '0173456708', 'mim33123@gmil.com', 'Madaripur ,Salina complex', 'In fron of hospital', 6190.00, 80.00, 1857.00, 4413.00, 1, 'cod', 'paid', 'delivered', '2026-11-23 18:36:03', 'website', 'delivery', NULL, 1, NULL, NULL, '2026-11-24 00:37:07');

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `name` varchar(150) NOT NULL,
  `variation` varchar(60) DEFAULT NULL,
  `unit_price` decimal(10,2) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `name`, `variation`, `unit_price`, `quantity`) VALUES
(1, 1, 2, 'Chicken Tehari', NULL, 280.00, 1),
(2, 1, 3, 'Charcoal Chicken Tikka', NULL, 320.00, 1),
(3, 1, 4, 'Rumali Roti & Dal', NULL, 140.00, 1),
(4, 2, 6, 'Best Burger', NULL, 399.00, 1),
(5, 2, 7, 'Best Burger', NULL, 455.00, 1),
(6, 3, 15, '- Seafood Pizza', NULL, 750.00, 3),
(7, 3, 19, 'BBQ Beef Burger', NULL, 350.00, 3),
(8, 4, 36, 'Chocolate Lava Cake', NULL, 450.00, 1),
(9, 4, 37, 'Strawberry Pudding', NULL, 200.00, 1),
(10, 5, 36, 'Chocolate Lava Cake', NULL, 450.00, 2),
(11, 6, 34, 'Iced Coffee', NULL, 180.00, 1),
(12, 6, 37, 'Strawberry Pudding', NULL, 200.00, 1),
(13, 7, 10, 'BBQ Chicken Pizza', NULL, 550.00, 1),
(14, 7, 11, 'Cheese Burst Pizza', NULL, 600.00, 1),
(15, 7, 15, '- Seafood Pizza', NULL, 750.00, 1),
(16, 7, 16, 'Classic Beef Burger', NULL, 280.00, 1),
(17, 7, 18, 'Double Cheese Burger', NULL, 380.00, 1),
(18, 7, 24, 'Chicken Carbonara', NULL, 380.00, 1),
(19, 7, 26, 'Mac & Cheese', NULL, 300.00, 1),
(20, 7, 29, 'Chicken Pesto Pasta', NULL, 380.00, 1),
(21, 7, 31, 'Chicken Parmesan', NULL, 480.00, 1),
(22, 7, 32, 'Caesar Salad', NULL, 250.00, 1),
(23, 7, 33, 'Chicken Garden Salad', NULL, 290.00, 1),
(24, 7, 38, 'Best Burger', NULL, 550.00, 2),
(25, 7, 40, 'Best Burger', NULL, 450.00, 1);

-- --------------------------------------------------------

--
-- Table structure for table `order_refunds`
--

CREATE TABLE `order_refunds` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `order_status_log`
--

CREATE TABLE `order_status_log` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `from_status` varchar(20) NOT NULL,
  `to_status` varchar(20) NOT NULL,
  `admin_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `gateway` varchar(30) NOT NULL,
  `transaction_id` varchar(100) DEFAULT NULL,
  `val_id` varchar(100) DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `status` enum('initiated','validated','failed','cancelled','refunded') DEFAULT 'initiated',
  `raw_response` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `name` varchar(150) NOT NULL,
  `description` text DEFAULT NULL,
  `ingredients` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `discount_price` decimal(10,2) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `rating` decimal(2,1) DEFAULT 4.5,
  `is_available` tinyint(1) DEFAULT 1,
  `is_featured` tinyint(1) DEFAULT 0,
  `is_popular` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `category_id`, `name`, `description`, `ingredients`, `price`, `discount_price`, `image`, `rating`, `is_available`, `is_featured`, `is_popular`, `created_at`, `updated_at`) VALUES
(8, 1, 'Margherita Pizza', 'A classic Italian pizza topped with rich tomato sauce, fresh mozzarella cheese, and fragrant basil leaves. Baked to perfection on a crispy golden crust with a delightful blend of fresh and savory flavors.', '- Pizza Dough\r\n- Tomato Sauce\r\n- Mozzarella Cheese\r\n- Fresh Basil Leaves\r\n- Olive Oil\r\n- Salt\r\n- Oregano', 500.00, 450.00, 'a89d358e29048bf3087a.jpg', 4.5, 1, 1, 1, '2026-11-21 21:24:11', '2026-11-21 21:25:37'),
(9, 1, 'Pepperoni Pizza', 'A delicious classic pizza topped with savory pepperoni slices, rich tomato sauce, and melted mozzarella cheese. Baked to perfection on a golden, crispy crust with a mouthwatering blend of cheesy and spicy flavors.', 'Pizza Dough\r\n\r\n\r\n\r\nTomato Sauce\r\n\r\n\r\n\r\nMozzarella Cheese\r\n\r\n\r\n\r\nBeef Pepperoni\r\n\r\n\r\n\r\nOlive Oil\r\n\r\n\r\n\r\nOregano\r\n\r\n\r\n\r\nChili Flakes', 599.98, 550.00, 'ab9d596880986d70e3ec.jpg', 4.5, 1, 1, 1, '2026-11-21 21:29:20', '2026-11-21 21:29:20'),
(10, 1, 'BBQ Chicken Pizza', 'A mouthwatering pizza loaded with tender grilled chicken, smoky BBQ sauce, and melted mozzarella cheese. Topped with fresh onions and a hint of herbs, baked on a golden crispy crust for the perfect balance of smoky, cheesy, and savory flavors.', 'Pizza Dough\r\n\r\n\r\n\r\nBBQ Sauce\r\n\r\n\r\n\r\nGrilled Chicken\r\n\r\n\r\n\r\nMozzarella Cheese\r\n\r\n\r\n\r\nRed Onion\r\n\r\n\r\n\r\nBell Pepper\r\n\r\n\r\n\r\nOregano\r\n\r\n\r\n\r\nOlive Oil', 600.00, 550.00, 'd9ebfc85a83ea36ee7eb.jpg', 4.5, 1, 1, 1, '2026-11-21 21:31:09', '2026-11-21 21:36:11'),
(11, 1, 'Cheese Burst Pizza', 'Description:\r\nIndulge in our irresistible Cheese Burst Pizza, featuring a crispy golden crust filled with rich, creamy melted cheese. Topped with delicious tomato sauce and a generous layer of mozzarella cheese, every bite delivers a mouthwatering burst of cheesy goodness.', 'Pizza Dough\r\n\r\n\r\n\r\nTomato Sauce\r\n\r\n\r\n\r\nMozzarella Cheese\r\n\r\n\r\n\r\nCream Cheese\r\n\r\n\r\n\r\nCheddar Cheese\r\n\r\n\r\n\r\nParmesan Cheese\r\n\r\n\r\n\r\nOregano\r\n\r\n\r\n\r\nOlive Oil', 600.00, NULL, 'e89360bbc98f01190f3e.jpg', 4.5, 1, 1, 1, '2026-11-21 21:32:54', '2026-11-21 21:41:30'),
(12, 1, 'Chicken Supreme Pizza', 'Enjoy our delicious Chicken Supreme Pizza, loaded with juicy grilled chicken, fresh vegetables, and a generous layer of melted mozzarella cheese. Topped with flavorful mushrooms, colorful bell peppers, and savory sauces, all baked on a crispy golden crust for a satisfying and delicious experience.', 'Pizza Dough\r\n\r\n\r\n\r\nGrilled Chicken\r\n\r\n\r\n\r\nTomato Sauce\r\n\r\n\r\n\r\nMozzarella Cheese\r\n\r\n\r\n\r\nMushrooms\r\n\r\n\r\n\r\nBell Peppers\r\n\r\n\r\n\r\nRed Onion\r\n\r\n\r\n\r\nBlack Olives\r\n\r\n\r\n\r\nOregano\r\n\r\n\r\n\r\nOlive Oil', 649.00, NULL, '1bbf2a5deb1c9ad93004.jpg', 4.5, 1, 0, 0, '2026-11-21 21:34:26', '2026-11-21 21:34:26'),
(13, 1, 'Italian Veggie Pizza', 'A delightful Italian-style vegetarian pizza topped with fresh garden vegetables, juicy tomatoes, and creamy mozzarella cheese. Baked on a crispy golden crust with aromatic herbs and rich tomato sauce, delivering a fresh, flavorful, and delicious taste in every bite.', 'Pizza Dough\r\n\r\n\r\n\r\nTomato Sauce\r\n\r\n\r\n\r\nMozzarella Cheese\r\n\r\n\r\n\r\nBell Peppers\r\n\r\n\r\n\r\nMushrooms\r\n\r\n\r\n\r\nBlack Olives\r\n\r\n\r\n\r\nCherry Tomatoes\r\n\r\n\r\n\r\nRed Onion\r\n\r\n\r\n\r\nFresh Basil\r\n\r\n\r\n\r\nOregano\r\n\r\n\r\n\r\nOlive Oil', 500.00, NULL, '6f9ff6d3d586daa46df7.jpg', 4.5, 1, 0, 0, '2026-11-21 21:35:56', '2026-11-21 21:35:56'),
(14, 1, 'Mushroom Pizza', 'A delicious pizza featuring fresh sliced mushrooms, creamy mozzarella cheese, and rich tomato sauce. Baked on a golden crispy crust and seasoned with aromatic Italian herbs, this pizza offers a delightful earthy flavor and a perfect cheesy experience in every bite.', 'Pizza Dough\r\n\r\n\r\n\r\nTomato Sauce\r\n\r\n\r\n\r\nMozzarella Cheese\r\n\r\n\r\n\r\nFresh Mushrooms\r\n\r\n\r\n\r\nGarlic\r\n\r\n\r\n\r\nOregano\r\n\r\n\r\n\r\nBlack Pepper\r\n\r\n\r\n\r\nOlive Oil', 450.00, NULL, '18a821096034a5956e10.jpg', 4.5, 1, 0, 0, '2026-11-21 21:37:36', '2026-11-21 21:37:36'),
(15, 1, '- Seafood Pizza', 'A delicious seafood pizza topped with juicy shrimp, tender fish, and a delightful mix of fresh seafood. Combined with rich tomato sauce, melted mozzarella cheese, and aromatic Italian herbs, all baked on a crispy golden crust for a savory ocean-inspired taste.', 'Pizza Dough\r\n\r\n\r\n\r\nTomato Sauce\r\n\r\n\r\n\r\nMozzarella Cheese\r\n\r\n\r\n\r\nShrimp\r\n\r\n\r\n\r\nFish Fillet\r\n\r\n\r\n\r\nCalamari\r\n\r\n\r\n\r\nGarlic\r\n\r\n\r\n\r\nBlack Pepper\r\n\r\n\r\n\r\nOregano\r\n\r\n\r\n\r\nOlive Oil', 750.00, NULL, '373c81e0bebb3b26a884.jpg', 4.5, 1, 0, 1, '2026-11-21 21:40:16', '2026-11-21 21:42:43'),
(16, 5, 'Classic Beef Burger', 'A timeless favorite featuring a juicy, perfectly grilled beef patty topped with fresh lettuce, ripe tomatoes, melted cheddar cheese, and crunchy pickles. Served in a soft toasted sesame bun with our signature burger sauce for a delicious and satisfying bite.', 'Sesame Burger Bun\r\n\r\n\r\n\r\nBeef Patty\r\n\r\n\r\n\r\nCheddar Cheese\r\n\r\n\r\n\r\nFresh Lettuce\r\n\r\n\r\n\r\nTomato Slices\r\n\r\n\r\n\r\nPickles\r\n\r\n\r\n\r\nOnion\r\n\r\n\r\n\r\nMayonnaise\r\n\r\n\r\n\r\nKetchup\r\n\r\n\r\n\r\nMustard Sauce\r\n\r\n\r\n\r\nBlack Pepper\r\n\r\n\r\n\r\nSalt', 280.00, NULL, '80c07f50262a96e26aa5.jpg', 4.5, 1, 1, 1, '2026-11-21 21:48:41', '2026-11-21 22:00:14'),
(17, 5, 'Crispy Chicken Burger', 'Enjoy our delicious Crispy Chicken Burger, featuring a juicy chicken fillet coated in a golden, crunchy batter and fried to perfection. Layered with fresh lettuce, creamy mayonnaise, and melted cheese, all served in a soft toasted sesame bun for an irresistible crispy and flavorful experience.', 'Sesame Burger Bun\r\n\r\n\r\n\r\nChicken Breast Fillet\r\n\r\n\r\n\r\nCrispy Chicken Coating\r\n\r\n\r\n\r\nBreadcrumbs\r\n\r\n\r\n\r\nFresh Lettuce\r\n\r\n\r\n\r\nCheddar Cheese\r\n\r\n\r\n\r\nMayonnaise\r\n\r\n\r\n\r\nBlack Pepper\r\n\r\n\r\n\r\nGarlic Powder\r\n\r\n\r\n\r\nSalt\r\n\r\n\r\n\r\nCooking Oil', 250.00, NULL, 'd3536c19b06b13e1c73b.jpg', 4.5, 1, 0, 1, '2026-11-21 21:50:23', '2026-11-21 21:50:23'),
(18, 5, 'Double Cheese Burger', 'Experience the ultimate cheesy delight with our Double Cheese Burger, featuring two juicy grilled beef patties layered with double slices of melted cheddar cheese. Topped with fresh lettuce, crunchy pickles, and our special burger sauce, all served in a soft toasted sesame bun for a rich and satisfying taste.', 'Sesame Burger Bun\r\n\r\n\r\n\r\nTwo Beef Patties\r\n\r\n\r\n\r\nDouble Cheddar Cheese\r\n\r\n\r\n\r\nFresh Lettuce\r\n\r\n\r\n\r\nTomato Slices\r\n\r\n\r\n\r\nPickles\r\n\r\n\r\n\r\nOnion\r\n\r\n\r\n\r\nMayonnaise\r\n\r\n\r\n\r\nBurger Sauce\r\n\r\n\r\n\r\nBlack Pepper\r\n\r\n\r\n\r\nSalt\r\n\r\n\r\n\r\nButter', 380.00, NULL, 'c925b89d27bc5d32d55d.jpg', 4.5, 1, 1, 0, '2026-11-21 21:51:44', '2026-11-21 21:51:44'),
(19, 5, 'BBQ Beef Burger', 'Enjoy our mouthwatering BBQ Beef Burger, featuring a juicy grilled beef patty generously coated with smoky barbecue sauce. Topped with melted cheddar cheese, crispy onion rings, and fresh lettuce, all served in a soft toasted sesame bun for a perfect combination of smoky, savory, and delicious flavors.', 'Sesame Burger Bun\r\n\r\n\r\n\r\nGrilled Beef Patty\r\n\r\n\r\n\r\nBBQ Sauce\r\n\r\n\r\n\r\nCheddar Cheese\r\n\r\n\r\n\r\nFresh Lettuce\r\n\r\n\r\n\r\nTomato Slices\r\n\r\n\r\n\r\nCrispy Onion Rings\r\n\r\n\r\n\r\nPickles\r\n\r\n\r\n\r\nMayonnaise\r\n\r\n\r\n\r\nBlack Pepper\r\n\r\n\r\n\r\nSalt\r\n\r\n\r\n\r\nButter', 350.00, NULL, 'b756eb21a71c4d74078e.jpg', 4.5, 1, 1, 1, '2026-11-21 21:53:04', '2026-11-21 21:53:04'),
(20, 5, 'Spicy Chicken Burger', 'Turn up the heat with our Spicy Chicken Burger, featuring a crispy golden chicken fillet coated in a delicious spicy seasoning. Topped with fresh lettuce, melted cheddar cheese, jalapeños, and our special spicy mayo sauce, all served in a soft toasted sesame bun for a bold and satisfying flavor.', 'Sesame Burger Bun\r\n\r\n\r\n\r\nChicken Breast Fillet\r\n\r\n\r\n\r\nCrispy Chicken Coating\r\n\r\n\r\n\r\nCheddar Cheese\r\n\r\n\r\n\r\nFresh Lettuce\r\n\r\n\r\n\r\nJalapeños\r\n\r\n\r\n\r\nSpicy Mayonnaise\r\n\r\n\r\n\r\nHot Sauce\r\n\r\n\r\n\r\nBreadcrumbs\r\n\r\n\r\n\r\nGarlic Powder\r\n\r\n\r\n\r\nChili Flakes\r\n\r\n\r\n\r\nBlack Pepper\r\n\r\n\r\n\r\nSalt\r\n\r\n\r\n\r\nCooking Oil', 280.00, NULL, 'c399abfff029c26b3cd5.jpg', 4.5, 1, 0, 1, '2026-11-21 21:54:15', '2026-11-21 21:54:15'),
(21, 5, 'Mushroom Swiss Burger', 'Treat yourself to our delicious Mushroom Swiss Burger, featuring a juicy grilled beef patty topped with sautéed mushrooms and rich, creamy Swiss cheese. Enhanced with caramelized onions and our special creamy sauce, all served in a soft toasted brioche bun for a perfectly savory and flavorful experience.', 'Brioche Burger Bun\r\n\r\n\r\n\r\nBeef Patty\r\n\r\n\r\n\r\nSwiss Cheese\r\n\r\n\r\n\r\nFresh Mushrooms\r\n\r\n\r\n\r\nCaramelized Onions\r\n\r\n\r\n\r\nMayonnaise\r\n\r\n\r\n\r\nGarlic Sauce\r\n\r\n\r\n\r\nButter\r\n\r\n\r\n\r\nBlack Pepper\r\n\r\n\r\n\r\nSalt\r\n\r\n\r\n\r\nFresh Lettuce', 380.00, NULL, '93235c53b9d6d0e44705.jpg', 4.5, 1, 0, 0, '2026-11-21 21:55:35', '2026-11-21 21:55:35'),
(22, 5, 'Zinger Burger', 'Enjoy our famous Zinger Burger, featuring a large, crispy and spicy chicken fillet fried to golden perfection. Layered with fresh crunchy lettuce and creamy mayonnaise, all served in a soft toasted sesame bun. Every bite delivers the perfect combination of crunchiness, juiciness, and spicy flavor.', 'Sesame Burger Bun\r\n\r\n\r\n\r\nChicken Breast Fillet\r\n\r\n\r\n\r\nCrispy Spicy Coating\r\n\r\n\r\n\r\nBreadcrumbs\r\n\r\n\r\n\r\nFresh Lettuce\r\n\r\n\r\n\r\nMayonnaise\r\n\r\n\r\n\r\nGarlic Powder\r\n\r\n\r\n\r\nPaprika\r\n\r\n\r\n\r\nChili Powder\r\n\r\n\r\n\r\nBlack Pepper\r\n\r\n\r\n\r\nSalt\r\n\r\n\r\n\r\nCooking Oil', 300.00, 270.00, '44394a567adfff9195eb.jpg', 4.5, 1, 0, 0, '2026-11-21 21:57:28', '2026-11-21 21:57:42'),
(23, 6, 'Creamy Alfredo Pasta', 'Creamy pasta tossed in rich Alfredo sauce with tender chicken, Parmesan cheese, and aromatic herbs for a deliciously smooth and cheesy taste.', 'Pasta, Chicken Breast, Heavy Cream, Parmesan Cheese, Butter, Garlic, Black Pepper, Salt, Parsley', 349.99, NULL, '42ed805e96b726eff924.jpg', 4.5, 1, 1, 1, '2026-11-21 22:07:57', '2026-11-21 22:07:57'),
(24, 6, 'Chicken Carbonara', 'Delicious creamy pasta with tender chicken, crispy beef bacon, Parmesan cheese, and a rich garlic cream sauce, finished with freshly cracked black pepper.', 'Pasta, Chicken Breast, Beef Bacon, Egg Yolk, Parmesan Cheese, Heavy Cream, Garlic, Black Pepper, Salt, Olive Oil', 380.00, NULL, '6003688930ed1b1249c2.jpg', 4.5, 1, 0, 1, '2026-11-21 22:09:37', '2026-11-21 22:09:37'),
(25, 6, 'Spaghetti Bolognese', 'Classic spaghetti topped with rich slow-cooked beef and tomato sauce, seasoned with Italian herbs and finished with Parmesan cheese.', 'Spaghetti, Ground Beef, Tomato Sauce, Onion, Garlic, Olive Oil, Parmesan Cheese, Basil, Oregano, Black Pepper, Salt', 399.00, 350.00, '58680e3c44071fa4b368.jpg', 4.5, 1, 1, 1, '2026-11-21 22:11:15', '2026-11-21 22:11:15'),
(26, 6, 'Mac & Cheese', 'Creamy macaroni pasta coated in rich melted cheese sauce, topped with mozzarella and cheddar for a deliciously cheesy experience.', 'Macaroni, Cheddar Cheese, Mozzarella Cheese, Milk, Butter, All-Purpose Flour, Heavy Cream, Black Pepper, Salt', 300.00, NULL, '5c76f63d011dd3aab23c.jpg', 4.5, 1, 0, 1, '2026-11-21 22:12:37', '2026-11-21 22:12:37'),
(27, 6, 'Creamy Mushroom Pasta', 'Delicious pasta tossed in a rich creamy mushroom sauce with garlic, Parmesan cheese, and aromatic herbs for a smooth and savory taste.', 'Pasta, Fresh Mushrooms, Heavy Cream, Parmesan Cheese, Butter, Garlic, Onion, Black Pepper, Salt, Parsley', 348.00, 320.00, '8b131f391512343a6191.jpg', 4.5, 1, 1, 1, '2026-11-21 22:14:02', '2026-11-21 22:14:02'),
(28, 6, 'Spicy Arrabbiata Pasta', 'Authentic Italian pasta tossed in a spicy tomato sauce with garlic, chili flakes, and fresh herbs for a bold and flavorful taste.', 'Pasta, Tomato Sauce, Garlic, Chili Flakes, Olive Oil, Fresh Basil, Oregano, Black Pepper, Salt, Parmesan Cheese', 300.00, NULL, '533a7df4e895ee073399.jpg', 4.5, 1, 1, 1, '2026-11-21 22:16:12', '2026-11-21 22:16:12'),
(29, 6, 'Chicken Pesto Pasta', 'Delicious pasta tossed in fresh basil pesto sauce with tender grilled chicken, Parmesan cheese, and garlic for a rich and refreshing flavor.', 'Pasta, Grilled Chicken, Basil Pesto, Parmesan Cheese, Garlic, Olive Oil, Pine Nuts, Black Pepper, Salt', 380.00, NULL, 'edc216d5f8ce7e5c776c.jpg', 4.5, 1, 0, 0, '2026-11-21 22:17:36', '2026-11-21 22:17:36'),
(30, 7, 'Grilled Chicken Steak', 'Juicy grilled chicken breast served with creamy mashed potatoes, fresh vegetables, and flavorful pepper sauce.', 'Chicken Breast, Garlic, Butter, Olive Oil, Black Pepper, Salt, Mashed Potatoes, Seasonal Vegetables, Pepper Sauce', 450.00, NULL, '6c6bdc648b2130f2e9eb.jpg', 4.5, 1, 0, 1, '2026-11-22 14:20:08', '2026-11-22 14:20:08'),
(31, 7, 'Chicken Parmesan', 'Crispy breaded chicken topped with rich tomato sauce and melted mozzarella and Parmesan cheese, served with pasta for a delicious Italian-style meal.', 'Chicken Breast, Breadcrumbs, Tomato Sauce, Mozzarella Cheese, Parmesan Cheese, Egg, Flour, Garlic, Oregano, Olive Oil, Salt, Black Pepper, Pasta', 500.00, 480.00, '05df9edb87e1272324a7.jpg', 4.5, 1, 0, 0, '2026-11-22 14:21:47', '2026-11-22 14:21:47'),
(32, 8, 'Caesar Salad', 'Fresh crunchy lettuce tossed with creamy Caesar dressing, crispy croutons, and Parmesan cheese for a refreshing and flavorful salad.', 'Romaine Lettuce, Caesar Dressing, Croutons, Parmesan Cheese, Garlic, Olive Oil, Lemon Juice, Black Pepper, Salt', 250.00, NULL, '47b7866e728bc7538051.jpg', 4.5, 1, 0, 0, '2026-11-22 14:23:07', '2026-11-22 14:23:07'),
(33, 8, 'Chicken Garden Salad', 'Fresh garden vegetables topped with juicy grilled chicken and a light, flavorful dressing for a healthy and satisfying meal.', 'Grilled Chicken, Lettuce, Cucumber, Tomato, Carrot, Bell Pepper, Red Onion, Olive Oil, Lemon Juice, Black Pepper, Salt', 300.00, 290.00, '9054d4adbbd50eb02234.jpg', 4.5, 1, 1, 1, '2026-11-22 14:25:07', '2026-11-22 14:25:07'),
(34, 8, 'Iced Coffee', 'Refreshing chilled coffee blended with creamy milk and served over ice for a smooth, rich, and energizing taste.', 'Coffee, Milk, Sugar, Ice Cubes, Chocolate Syrup', 180.00, NULL, '18f53facae454eed4092.jpg', 4.5, 1, 1, 1, '2026-11-22 14:26:29', '2026-11-22 14:26:29'),
(35, 9, 'Strawberry Milkshake', 'A creamy and refreshing milkshake blended with sweet strawberries and chilled milk, topped with whipped cream for a delightful fruity treat.', 'Fresh Strawberries, Milk, Vanilla Ice Cream, Sugar, Whipped Cream', 220.00, NULL, 'dc51d3260b10bd34f109.jpg', 4.5, 1, 0, 0, '2026-11-22 14:27:54', '2026-11-22 14:27:54'),
(36, 10, 'Chocolate Lava Cake', 'A rich chocolate cake with a warm, gooey molten center, served with creamy vanilla ice cream for an irresistible dessert.', 'Dark Chocolate, Butter, Eggs, Sugar, All-Purpose Flour, Cocoa Powder, Vanilla Extract, Vanilla Ice Cream', 450.00, NULL, '3110b1094316d7e3fd01.jpg', 4.5, 1, 1, 1, '2026-11-22 14:28:48', '2026-11-22 14:29:13'),
(37, 10, 'Strawberry Pudding', 'Smooth and creamy strawberry pudding with a sweet fruity flavor, topped with fresh strawberries for a delightful dessert.', 'Milk, Fresh Strawberries, Sugar, Custard Powder, Cornstarch, Vanilla Extract, Strawberry Syrup', 250.00, 200.00, '83c6b7fb96abb29d2121.jpg', 4.5, 1, 1, 1, '2026-11-22 14:30:22', '2026-11-22 14:30:22'),
(38, 5, 'Best Burger', '', '', 600.00, 550.00, NULL, 4.5, 1, 1, 1, '2026-11-23 04:44:58', '2026-11-23 04:44:58'),
(39, 1, 'Margherita Pizza', '', '', 500.00, 444.00, NULL, 4.5, 1, 1, 1, '2026-11-23 12:45:34', '2026-11-23 12:45:34'),
(40, 5, 'Best Burger', '', '', 500.00, 450.00, 'cc9d779adfde8e4b52b6.jpg', 4.5, 1, 1, 1, '2026-11-23 17:22:27', '2026-11-23 17:22:27');

-- --------------------------------------------------------

--
-- Table structure for table `product_variations`
--

CREATE TABLE `product_variations` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `label` varchar(60) NOT NULL,
  `extra_price` decimal(10,2) DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `recipe_ingredients`
--

CREATE TABLE `recipe_ingredients` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `ingredient_id` int(11) NOT NULL,
  `quantity` decimal(14,3) NOT NULL,
  `unit` enum('kg','g','l','ml','piece','packet') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `recipe_ingredients`
--

INSERT INTO `recipe_ingredients` (`id`, `product_id`, `ingredient_id`, `quantity`, `unit`) VALUES
(1, 10, 2, 2.000, 'g'),
(2, 10, 6, 0.500, 'piece'),
(3, 10, 3, 0.100, 'kg'),
(4, 10, 4, 0.100, 'kg');

-- --------------------------------------------------------

--
-- Table structure for table `reservation_notification_log`
--

CREATE TABLE `reservation_notification_log` (
  `id` int(11) NOT NULL,
  `reservation_id` int(11) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `event` varchar(40) NOT NULL DEFAULT 'cancellation',
  `channel` enum('email','sms','website') NOT NULL,
  `recipient` varchar(190) NOT NULL DEFAULT '',
  `status` enum('pending','sent','failed') NOT NULL DEFAULT 'pending',
  `attempts` int(11) NOT NULL DEFAULT 0,
  `failure_reason` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `sent_at` datetime DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `reservation_notification_log`
--

INSERT INTO `reservation_notification_log` (`id`, `reservation_id`, `customer_id`, `event`, `channel`, `recipient`, `status`, `attempts`, `failure_reason`, `created_at`, `sent_at`, `updated_at`) VALUES
(1, 5, 1, 'cancellation', 'website', 'Customer account', 'sent', 1, NULL, '2026-11-23 05:21:54', '2026-11-23 11:21:54', '2026-11-23 05:21:54');

-- --------------------------------------------------------

--
-- Table structure for table `reservation_settings`
--

CREATE TABLE `reservation_settings` (
  `setting_key` varchar(40) NOT NULL,
  `setting_value` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `reservation_settings`
--

INSERT INTO `reservation_settings` (`setting_key`, `setting_value`) VALUES
('advance_days', '1'),
('close_time', '12:00'),
('duration_minutes', '90'),
('max_party_size', '12'),
('max_seats_total', '30'),
('open_time', '06:00'),
('peak_duration_minutes', '60'),
('peak_end', '21:00'),
('peak_start', '19:00'),
('slot_minutes', '60');

-- --------------------------------------------------------

--
-- Table structure for table `restaurant_settings`
--

CREATE TABLE `restaurant_settings` (
  `setting_key` varchar(60) NOT NULL,
  `setting_value` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `restaurant_settings`
--

INSERT INTO `restaurant_settings` (`setting_key`, `setting_value`) VALUES
('address', 'House 12, Road 5, Dhaka'),
('delivery_charge', '80'),
('email', 'cravely09@gmail.com'),
('facebook', '#'),
('instagram', '#'),
('kds_late_min', '20'),
('kds_warn_min', '10'),
('kiosk_enabled', '0'),
('kiosk_key', '091e68e78162005dbead14c2'),
('logo', 'f7de160d3dd1a6b65b7f.jpg'),
('opening_hours', 'Daily 10:00 AM - 2:00 AM'),
('phone', '01739739221'),
('restaurant_name', 'Cravely');

-- --------------------------------------------------------

--
-- Table structure for table `restaurant_tables`
--

CREATE TABLE `restaurant_tables` (
  `id` int(11) NOT NULL,
  `table_no` varchar(20) NOT NULL,
  `area` varchar(60) NOT NULL DEFAULT 'Main hall',
  `capacity` tinyint(4) NOT NULL,
  `status` enum('available','reserved','occupied','cleaning','unavailable') NOT NULL DEFAULT 'available',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `restaurant_tables`
--

INSERT INTO `restaurant_tables` (`id`, `table_no`, `area`, `capacity`, `status`, `created_at`) VALUES
(1, 'T1', 'Main hall', 2, 'available', '2026-11-22 15:57:29'),
(2, 'T2', 'Main hall', 2, 'unavailable', '2026-11-22 15:57:29'),
(3, 'T3', 'Main hall', 4, 'available', '2026-11-22 15:57:29'),
(4, 'T4', 'Main hall', 4, 'available', '2026-11-22 15:57:29'),
(5, 'T5', 'Window', 2, 'available', '2026-11-22 15:57:29'),
(6, 'T6', 'Window', 4, 'available', '2026-11-22 15:57:29'),
(7, 'T7', 'Family area', 6, 'available', '2026-11-22 15:57:29'),
(8, 'T8', 'Family area', 8, 'available', '2026-11-22 15:57:29'),
(9, 'T9', 'Middle in the hall', 2, 'unavailable', '2026-11-22 16:39:14'),
(10, '10', 'Speical Corner', 2, 'available', '2026-11-22 16:39:44');

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `rating` tinyint(4) NOT NULL,
  `comment` text DEFAULT NULL,
  `is_approved` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `is_hidden` tinyint(1) NOT NULL DEFAULT 0,
  `admin_reply` text DEFAULT NULL,
  `replied_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`id`, `customer_id`, `product_id`, `name`, `rating`, `comment`, `is_approved`, `created_at`, `is_hidden`, `admin_reply`, `replied_at`) VALUES
(1, NULL, NULL, 'Nusrat J.', 5, 'The kacchi was fragrant and the meat fell off the bone. Delivery was still hot.', 1, '2026-11-21 18:50:02', 0, NULL, NULL),
(2, NULL, NULL, 'Tanvir A.', 5, 'Best tehari I have had in Dhaka. Portions are generous.', 1, '2026-11-21 18:50:02', 0, NULL, NULL),
(3, NULL, NULL, 'Mitu R.', 4, 'Lovely tikka and fresh rumali roti. Will order again.', 1, '2026-11-21 18:50:02', 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `review_analysis`
--

CREATE TABLE `review_analysis` (
  `review_id` int(11) NOT NULL,
  `sentiment` enum('positive','neutral','negative') NOT NULL,
  `score` decimal(5,2) NOT NULL DEFAULT 0.00,
  `topics` varchar(255) NOT NULL DEFAULT '',
  `positives` varchar(255) NOT NULL DEFAULT '',
  `analyzer` varchar(20) NOT NULL DEFAULT 'rules',
  `analyzed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `review_analysis`
--

INSERT INTO `review_analysis` (`review_id`, `sentiment`, `score`, `topics`, `positives`, `analyzer`, `analyzed_at`) VALUES
(1, 'positive', 3.00, '', 'temperature', 'rules', '2026-11-22 20:38:39'),
(2, 'positive', 4.00, '', 'portion,general', 'rules', '2026-11-22 20:38:39'),
(3, 'positive', 2.00, '', 'freshness', 'rules', '2026-11-22 20:38:39');

-- --------------------------------------------------------

--
-- Table structure for table `reward_rules`
--

CREATE TABLE `reward_rules` (
  `rule_key` varchar(40) NOT NULL,
  `rule_value` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `reward_rules`
--

INSERT INTO `reward_rules` (`rule_key`, `rule_value`) VALUES
('coupon_days', '30'),
('first_order_bonus', '20'),
('gold_bonus', '20'),
('gold_spent', '15000'),
('redeem_points', '100'),
('redeem_value', '50'),
('silver_bonus', '10'),
('silver_spent', '5000'),
('spend_per_point', '10'),
('vip_bonus', '30'),
('vip_spent', '40000');

-- --------------------------------------------------------

--
-- Table structure for table `stock_purchases`
--

CREATE TABLE `stock_purchases` (
  `id` int(11) NOT NULL,
  `ingredient_id` int(11) NOT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `quantity` decimal(14,3) NOT NULL,
  `unit_cost` decimal(12,4) NOT NULL,
  `total` decimal(12,2) NOT NULL,
  `note` varchar(255) DEFAULT NULL,
  `purchased_at` datetime NOT NULL,
  `created_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE `suppliers` (
  `id` int(11) NOT NULL,
  `name` varchar(120) NOT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`id`, `name`, `phone`, `created_at`) VALUES
(1, 'Local', '0987652345667', '2026-11-23 19:30:02'),
(2, 'Vegetable Supplier', '234567899', '2026-11-23 19:31:10'),
(3, 'Dairy Supplier', '56890234578', '2026-11-23 19:31:27'),
(4, 'Grocery Supplier', '234567881222', '2026-11-23 19:31:48'),
(5, 'Meat Supplier', '56890234578', '2026-11-23 19:33:05');

-- --------------------------------------------------------

--
-- Table structure for table `table_reservations`
--

CREATE TABLE `table_reservations` (
  `id` int(11) NOT NULL,
  `code` varchar(12) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  `phone` varchar(30) NOT NULL,
  `email` varchar(150) DEFAULT NULL,
  `res_date` date NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `guests` tinyint(4) NOT NULL,
  `table_id` int(11) DEFAULT NULL,
  `preferred_table_id` int(11) DEFAULT NULL,
  `notes` varchar(500) DEFAULT NULL,
  `status` enum('pending','confirmed','checked_in','completed','cancelled','rejected','no_show') NOT NULL DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `cancel_reason` enum('table_unavailable','fully_booked','restaurant_closure','other') DEFAULT NULL,
  `cancel_note` varchar(500) DEFAULT NULL,
  `cancelled_at` datetime DEFAULT NULL,
  `cancelled_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `table_reservations`
--

INSERT INTO `table_reservations` (`id`, `code`, `customer_id`, `name`, `phone`, `email`, `res_date`, `start_time`, `end_time`, `guests`, `table_id`, `preferred_table_id`, `notes`, `status`, `created_at`, `updated_at`, `cancel_reason`, `cancel_note`, `cancelled_at`, `cancelled_by`) VALUES
(1, 'RSV13AA39', NULL, 'Oishe', '01786542828', 'osh32@gmail.com', '2026-11-25', '15:30:00', '17:00:00', 2, 10, 10, 'he he pleace accept my request', 'cancelled', '2026-11-22 16:42:23', '2026-11-22 16:45:52', NULL, NULL, NULL, NULL),
(2, 'RSV23A40B', 1, 'alu', '0173456708', 'imim56634@gmail.com', '2026-11-25', '16:00:00', '17:30:00', 6, 7, 7, 'i need this .', 'rejected', '2026-11-22 16:45:10', '2026-11-22 16:46:19', NULL, NULL, NULL, NULL),
(3, 'RSV9ABF9E', 1, 'alu', '0173456708', 'imim56634@gmail.com', '2026-11-27', '18:30:00', '20:00:00', 4, 3, NULL, '', 'confirmed', '2026-11-23 04:48:24', '2026-11-23 04:49:32', NULL, NULL, NULL, NULL),
(4, 'RSV011EDA', 1, 'alu', '0173456708', 'imim56634@gmail.com', '2026-11-27', '18:30:00', '20:00:00', 4, 4, NULL, '', 'pending', '2026-11-23 04:49:54', '2026-11-23 04:49:54', NULL, NULL, NULL, NULL),
(5, 'RSV05CDA6', 1, 'alu', '017993897975', 'imim56634@gmail.com', '2026-11-28', '16:30:00', '18:00:00', 2, 4, 4, '', 'cancelled', '2026-11-23 05:20:52', '2026-11-23 05:21:54', 'table_unavailable', NULL, '2026-11-23 11:21:54', 1),
(6, 'RSV407D30', 1, 'alu', '017993897975', 'imim56634@gmail.com', '2026-11-28', '16:30:00', '18:00:00', 2, 4, 4, '', 'confirmed', '2026-11-23 05:22:00', '2026-11-23 05:22:37', NULL, NULL, NULL, NULL),
(7, 'RSVE99C34', 2, 'Mim', '0173456708', 'imim56634@gmail.com', '2026-11-24', '09:00:00', '10:30:00', 2, 1, 1, 'i need this seat so badly.', 'confirmed', '2026-11-23 19:05:21', '2026-11-23 19:08:33', NULL, NULL, NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `admin_notifications`
--
ALTER TABLE `admin_notifications`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uniq_event` (`type`,`related_id`),
  ADD KEY `created_at` (`created_at`);

--
-- Indexes for table `admin_notification_state`
--
ALTER TABLE `admin_notification_state`
  ADD PRIMARY KEY (`admin_id`,`notification_id`),
  ADD KEY `notification_id` (`notification_id`);

--
-- Indexes for table `carts`
--
ALTER TABLE `carts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `customer_id` (`customer_id`,`product_id`,`variation_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `slug` (`slug`);

--
-- Indexes for table `contact_messages`
--
ALTER TABLE `contact_messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `coupons`
--
ALTER TABLE `coupons`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `customer_addresses`
--
ALTER TABLE `customer_addresses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_addr_customer` (`customer_id`,`is_default`);

--
-- Indexes for table `customer_notifications`
--
ALTER TABLE `customer_notifications`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uniq_cust_event` (`type`,`reservation_id`),
  ADD UNIQUE KEY `uniq_cust_order_event` (`type`,`order_id`),
  ADD KEY `customer_id` (`customer_id`,`is_read`,`created_at`),
  ADD KEY `reservation_id` (`reservation_id`),
  ADD KEY `idx_cn_order` (`order_id`);

--
-- Indexes for table `ingredients`
--
ALTER TABLE `ingredients`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD KEY `supplier_id` (`supplier_id`);

--
-- Indexes for table `inventory_movements`
--
ALTER TABLE `inventory_movements`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uniq_order_move` (`order_id`,`ingredient_id`,`type`),
  ADD KEY `ingredient_id` (`ingredient_id`,`created_at`),
  ADD KEY `type` (`type`,`created_at`);

--
-- Indexes for table `login_attempts`
--
ALTER TABLE `login_attempts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_la_ident` (`scope`,`identifier`,`created_at`),
  ADD KEY `idx_la_ip` (`scope`,`ip`,`created_at`);

--
-- Indexes for table `loyalty_accounts`
--
ALTER TABLE `loyalty_accounts`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `loyalty_transactions`
--
ALTER TABLE `loyalty_transactions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uniq_order_reward` (`order_id`,`type`),
  ADD KEY `customer_id` (`customer_id`,`created_at`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `order_no` (`order_no`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`);

--
-- Indexes for table `order_refunds`
--
ALTER TABLE `order_refunds`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`);

--
-- Indexes for table `order_status_log`
--
ALTER TABLE `order_status_log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_osl_order` (`order_id`,`id`),
  ADD KEY `idx_osl_time` (`created_at`,`to_status`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_id` (`category_id`),
  ADD KEY `is_featured` (`is_featured`);

--
-- Indexes for table `product_variations`
--
ALTER TABLE `product_variations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `recipe_ingredients`
--
ALTER TABLE `recipe_ingredients`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uniq_recipe` (`product_id`,`ingredient_id`),
  ADD KEY `ingredient_id` (`ingredient_id`);

--
-- Indexes for table `reservation_notification_log`
--
ALTER TABLE `reservation_notification_log`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uniq_notice` (`reservation_id`,`event`,`channel`),
  ADD KEY `status` (`status`),
  ADD KEY `customer_id` (`customer_id`);

--
-- Indexes for table `reservation_settings`
--
ALTER TABLE `reservation_settings`
  ADD PRIMARY KEY (`setting_key`);

--
-- Indexes for table `restaurant_settings`
--
ALTER TABLE `restaurant_settings`
  ADD PRIMARY KEY (`setting_key`);

--
-- Indexes for table `restaurant_tables`
--
ALTER TABLE `restaurant_tables`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `table_no` (`table_no`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `review_analysis`
--
ALTER TABLE `review_analysis`
  ADD PRIMARY KEY (`review_id`),
  ADD KEY `sentiment` (`sentiment`);

--
-- Indexes for table `reward_rules`
--
ALTER TABLE `reward_rules`
  ADD PRIMARY KEY (`rule_key`);

--
-- Indexes for table `stock_purchases`
--
ALTER TABLE `stock_purchases`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ingredient_id` (`ingredient_id`),
  ADD KEY `supplier_id` (`supplier_id`);

--
-- Indexes for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `table_reservations`
--
ALTER TABLE `table_reservations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`),
  ADD KEY `table_id` (`table_id`,`res_date`),
  ADD KEY `res_date` (`res_date`,`status`),
  ADD KEY `idx_res_customer_date` (`customer_id`,`res_date`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `admin_notifications`
--
ALTER TABLE `admin_notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `carts`
--
ALTER TABLE `carts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `contact_messages`
--
ALTER TABLE `contact_messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `coupons`
--
ALTER TABLE `coupons`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `customer_addresses`
--
ALTER TABLE `customer_addresses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `customer_notifications`
--
ALTER TABLE `customer_notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `ingredients`
--
ALTER TABLE `ingredients`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `inventory_movements`
--
ALTER TABLE `inventory_movements`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `login_attempts`
--
ALTER TABLE `login_attempts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `loyalty_transactions`
--
ALTER TABLE `loyalty_transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `order_refunds`
--
ALTER TABLE `order_refunds`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `order_status_log`
--
ALTER TABLE `order_status_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT for table `product_variations`
--
ALTER TABLE `product_variations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `recipe_ingredients`
--
ALTER TABLE `recipe_ingredients`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `reservation_notification_log`
--
ALTER TABLE `reservation_notification_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `restaurant_tables`
--
ALTER TABLE `restaurant_tables`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `stock_purchases`
--
ALTER TABLE `stock_purchases`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `suppliers`
--
ALTER TABLE `suppliers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `table_reservations`
--
ALTER TABLE `table_reservations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `admin_notification_state`
--
ALTER TABLE `admin_notification_state`
  ADD CONSTRAINT `admin_notification_state_ibfk_1` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `admin_notification_state_ibfk_2` FOREIGN KEY (`notification_id`) REFERENCES `admin_notifications` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `carts`
--
ALTER TABLE `carts`
  ADD CONSTRAINT `carts_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `carts_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `customer_addresses`
--
ALTER TABLE `customer_addresses`
  ADD CONSTRAINT `fk_addr_customer` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `customer_notifications`
--
ALTER TABLE `customer_notifications`
  ADD CONSTRAINT `customer_notifications_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `customer_notifications_ibfk_2` FOREIGN KEY (`reservation_id`) REFERENCES `table_reservations` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_cn_order` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `ingredients`
--
ALTER TABLE `ingredients`
  ADD CONSTRAINT `ingredients_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `inventory_movements`
--
ALTER TABLE `inventory_movements`
  ADD CONSTRAINT `inventory_movements_ibfk_1` FOREIGN KEY (`ingredient_id`) REFERENCES `ingredients` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `loyalty_accounts`
--
ALTER TABLE `loyalty_accounts`
  ADD CONSTRAINT `loyalty_accounts_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `loyalty_transactions`
--
ALTER TABLE `loyalty_transactions`
  ADD CONSTRAINT `loyalty_transactions_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `order_refunds`
--
ALTER TABLE `order_refunds`
  ADD CONSTRAINT `order_refunds_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`);

--
-- Constraints for table `product_variations`
--
ALTER TABLE `product_variations`
  ADD CONSTRAINT `product_variations_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `recipe_ingredients`
--
ALTER TABLE `recipe_ingredients`
  ADD CONSTRAINT `recipe_ingredients_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `recipe_ingredients_ibfk_2` FOREIGN KEY (`ingredient_id`) REFERENCES `ingredients` (`id`);

--
-- Constraints for table `reservation_notification_log`
--
ALTER TABLE `reservation_notification_log`
  ADD CONSTRAINT `reservation_notification_log_ibfk_1` FOREIGN KEY (`reservation_id`) REFERENCES `table_reservations` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `reservation_notification_log_ibfk_2` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `review_analysis`
--
ALTER TABLE `review_analysis`
  ADD CONSTRAINT `review_analysis_ibfk_1` FOREIGN KEY (`review_id`) REFERENCES `reviews` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `stock_purchases`
--
ALTER TABLE `stock_purchases`
  ADD CONSTRAINT `stock_purchases_ibfk_1` FOREIGN KEY (`ingredient_id`) REFERENCES `ingredients` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `stock_purchases_ibfk_2` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `table_reservations`
--
ALTER TABLE `table_reservations`
  ADD CONSTRAINT `table_reservations_ibfk_1` FOREIGN KEY (`table_id`) REFERENCES `restaurant_tables` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `table_reservations_ibfk_2` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
