# Restaurant ordering website (PHP 8 + MySQL)

## 1. Install XAMPP
1. Download XAMPP (PHP 8.1 or newer) from apachefriends.org and install it.
2. Open the XAMPP Control Panel and start **Apache** and **MySQL**.

## 2. Put the project in place
Copy the `restaurant` folder to `C:\xampp\htdocs\restaurant` (macOS: `/Applications/XAMPP/htdocs/restaurant`).

## 3. Import the database
1. Open http://localhost/phpmyadmin
2. Click **Import**, choose `database/database.sql`, click **Import**.
3. Upgrading from an earlier part? Instead run `database/update_part4.sql` once in the **SQL** tab.
3b. Upgrading an existing database that already ran migrations 01-03? Run `database/migrations/04_bugfix_refunded_state.sql` once (adds a 'refunded' payment state; read the optional section inside it first).
4. If your MySQL root user has a password, edit `config/database.php`.

## 4. Run the site
- Website: http://localhost/restaurant/
- Admin: http://localhost/restaurant/admin/

## 5. Create the first admin
Open http://localhost/restaurant/admin/setup.php, enter name, email and a password of 10+ characters. The setup page closes itself once an admin exists. Then log in at /admin/ and use **Food items** to upload photos.

## 6. Online payment (SSLCommerz sandbox)
1. Register a free sandbox store at https://developer.sslcommerz.com/registration/ and note the Store ID and Store Password from the email.
2. Copy `config/payment.local.example.php` to `config/payment.local.php` and fill in `store_id` and `store_password`. Leave `sandbox` as `true`.
3. Make sure the `curl` extension is on (it is in default XAMPP). If you get "SSL certificate problem", download cacert.pem from curl.se, set `curl.cainfo` to it in `php.ini`, and restart Apache.
4. Checkout now shows **Online payment**. In the sandbox, use the test cards and mobile-banking accounts listed on the SSLCommerz payment page.
5. How it stays safe: an order is marked paid only after the server asks SSLCommerz's validation API and the transaction id, amount and currency all match. A browser redirect alone never marks an order paid.
6. IPN (server notifications) cannot reach `localhost`. Locally the success page does the verification. On a public server set `app_url` to your https address and add `payment-ipn.php` as the IPN URL in the SSLCommerz merchant panel.
7. Going live: use a live store, set `sandbox` to `false`, serve the site over HTTPS, and keep `payment.local.php` private.
If no credentials are set, online payment is hidden and Cash on Delivery works as normal.

## Test checklist
Register, log in, add to cart, apply a coupon, place a COD order, change its status in admin, add and edit a food item with an image, sandbox payment, log out and confirm /admin/ redirects to login.

## Sales & payment reports (Phase 4)
Admin > **Sales & Revenue** (charts, gross/discount/refund/net, best sellers, peak hours) and **Payment Reports** (reconciliation and refunds). No extra database step beyond migration 04. Charts load Chart.js from cdnjs, so they need an internet connection; every chart has its figures in a table too.

## Customer account (migration 07)
Run `database/migrations/07_customer_account.sql` once in phpMyAdmin (database `restaurant_db` > SQL tab > paste > Go). It adds `customers.gender`, the `customer_addresses` table, `customer_notifications.order_id` (with a duplicate-protection key) and two indexes. Nothing is deleted.
Customers then use **My Account** (`my-account.php`) from the profile menu in the header. Old pages `my-orders.php`, `my-notifications.php` and `loyalty.php` now redirect there.
