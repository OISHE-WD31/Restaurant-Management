<?php
require 'includes/sslcommerz.php'; require_login('my-account.php');
$st=db()->prepare("SELECT * FROM orders WHERE order_no=? AND customer_id=? AND payment_method='online' AND payment_status IN ('unpaid','failed','cancelled') AND status<>'cancelled'");
$st->execute([$_GET['no']??'',$_SESSION['customer_id']]); $o=$st->fetch();
if(!$o){ pay_page('Payment unavailable','This order cannot be paid online right now.',false); exit; }
if(!sslc_ready()){ pay_page('Online payment is not set up','The restaurant has not configured online payment yet. Your order is saved. Please choose Cash on Delivery or contact us.',false); exit; }
$url=sslc_init($o);
if($url){ db()->prepare("UPDATE orders SET payment_status='unpaid' WHERE id=? AND payment_status<>'paid'")->execute([$o['id']]); header('Location: '.$url); exit; }
pay_page('Could not start payment','The payment gateway did not respond. Please try again from My Orders.',false);
