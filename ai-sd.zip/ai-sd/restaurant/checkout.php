<?php
require 'includes/cart.php'; require 'includes/sslcommerz.php'; require_login('checkout.php'); $title='Checkout';
$items=cart_items(); if(!$items){ header('Location: cart.php'); exit; }
$t=cart_totals($items); $err=[];
$me=db()->prepare('SELECT * FROM customers WHERE id=?'); $me->execute([$_SESSION['customer_id']]); $me=$me->fetch();
$v=['full_name'=>$me['name'],'phone'=>$me['phone'],'email'=>$me['email'],'address'=>$me['address']??'','notes'=>''];
// Saved addresses from My Account (optional: if the migration is not run yet, this is simply empty).
$saved=[]; try{ $sa=db()->prepare('SELECT id,address_type,full_address,city,area,postal_code,instructions,is_default FROM customer_addresses WHERE customer_id=? ORDER BY is_default DESC,id DESC'); $sa->execute([$_SESSION['customer_id']]); $saved=$sa->fetchAll(); }catch(Throwable $e){}
$fmt=fn($a)=>trim($a['full_address'].($a['area']?', '.$a['area']:'').', '.$a['city'].($a['postal_code']?' '.$a['postal_code']:''),', ');
if($saved && trim((string)$v['address'])==='') $v['address']=$fmt($saved[0]);
if($_SERVER['REQUEST_METHOD']==='POST'){
  if(!csrf_check()) $err[]='Session expired. Reload and try again.';
  foreach($v as $k=>$_) $v[$k]=trim($_POST[$k]??'');
  if(mb_strlen($v['full_name'])<2) $err[]='Enter your full name.';
  if(!preg_match('/^\+?[0-9\- ]{7,20}$/',$v['phone'])) $err[]='Enter a valid phone number.';
  if($v['email']!=='' && !filter_var($v['email'],FILTER_VALIDATE_EMAIL)) $err[]='Enter a valid email address.';
  if(mb_strlen($v['address'])<8) $err[]='Enter your full delivery address.';
  $pay=$_POST['payment']??''; if(!in_array($pay,['cod','online'],true) || ($pay==='online' && !sslc_ready())) $err[]='Choose a payment method.';
  if(!$err){
    $pdo=db(); $orderNo='ORD'.date('ymd').strtoupper(bin2hex(random_bytes(3)));
    try{
      $pdo->beginTransaction();
      $pdo->prepare('INSERT INTO orders(order_no,customer_id,full_name,phone,email,address,notes,subtotal,delivery_charge,discount,total,coupon_id,payment_method) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)')
          ->execute([$orderNo,$_SESSION['customer_id'],$v['full_name'],$v['phone'],$v['email'],$v['address'],$v['notes'],$t['subtotal'],$t['delivery'],$t['discount'],$t['total'],$t['coupon']['id']??null,$pay]);
      $oid=$pdo->lastInsertId(); $ins=$pdo->prepare('INSERT INTO order_items(order_id,product_id,name,unit_price,quantity) VALUES(?,?,?,?,?)');
      foreach($items as $i) $ins->execute([$oid,$i['id'],$i['name'],$i['unit'],$i['qty']]);
      if(!empty($t['coupon']['id'])){ $u=$pdo->prepare('UPDATE coupons SET used_count=used_count+1 WHERE id=? AND (max_uses IS NULL OR used_count<max_uses)'); $u->execute([$t['coupon']['id']]); if($u->rowCount()===0) throw new RuntimeException('Coupon already used'); }
      $pdo->commit();
      notify('order','New order received','Order '.$orderNo.' placed by '.$v['full_name'].' · '.money($t['total']).' · '.($pay==='cod'?'Cash on Delivery':'Online payment'),(int)$oid,'orders.php?q='.$orderNo);
      unset($_SESSION['cart'],$_SESSION['coupon']);
      header('Location: '.($pay==='online'?'payment-start.php?no=':'my-account.php?section=orders&placed=').$orderNo); exit;
    }catch(Throwable $x){ if($pdo->inTransaction()) $pdo->rollBack(); error_log($x->getMessage()); $err[]='We could not place your order. Please try again.'; }
  }
}
require 'includes/header.php'; ?>
<section class="sec wrap"><h2>Checkout</h2>
<?php foreach($err as $m): ?><p class="alert"><?= e($m) ?></p><?php endforeach; ?>
<div class="cart-layout"><form method="post" class="form"><?= csrf_field() ?>
<label>Full name<input name="full_name" value="<?= e($v['full_name']) ?>" required></label>
<label>Phone<input name="phone" value="<?= e($v['phone']) ?>" required></label>
<label>Email<input type="email" name="email" value="<?= e($v['email']) ?>"></label>
<?php if($saved): ?><label>Saved addresses<select id="saved-addr"><option value="">Choose a saved address…</option><?php foreach($saved as $a): ?><option value="<?= e($fmt($a)) ?>" data-note="<?= e((string)$a['instructions']) ?>"><?= e(ucfirst($a['address_type']).($a['is_default']?' (default)':'').' – '.mb_strimwidth($a['full_address'],0,40,'…')) ?></option><?php endforeach; ?></select></label><?php else: ?><p class="hint">Tip: save addresses in <a href="my-account.php?section=addresses"><u>My Address</u></a> to fill this in faster next time.</p><?php endif; ?>
<label>Delivery address<textarea name="address" rows="3" required><?= e($v['address']) ?></textarea></label>
<label>Additional instructions<textarea name="notes" rows="2"><?= e($v['notes']) ?></textarea></label>
<fieldset><legend>Payment</legend>
<label class="radio"><input type="radio" name="payment" value="cod" checked> Cash on Delivery</label>
<?php if(sslc_ready()): ?><label class="radio"><input type="radio" name="payment" value="online"> Online payment (cards, bKash, Nagad and more)</label><?php else: ?><label class="radio off"><input type="radio" disabled> Online payment (not set up yet)</label><?php endif; ?></fieldset>
<button class="btn">Place order · <?= money($t['total']) ?></button></form>
<aside class="summary"><h3>Your order</h3>
<?php foreach($items as $i): ?><p><span><?= e($i['name']) ?> × <?= $i['qty'] ?></span><b><?= money($i['line']) ?></b></p><?php endforeach; ?>
<p><span>Discount</span><b>-<?= money($t['discount']) ?></b></p><p><span>Delivery</span><b><?= money($t['delivery']) ?></b></p>
<p class="grand"><span>Total</span><b><?= money($t['total']) ?></b></p></aside></div></section>
<script>document.getElementById('saved-addr')?.addEventListener('change',function(){if(!this.value)return;document.querySelector('[name=address]').value=this.value;const n=this.selectedOptions[0].dataset.note,t=document.querySelector('[name=notes]');if(n&&!t.value)t.value=n});</script>
<?php require 'includes/footer.php'; ?>
