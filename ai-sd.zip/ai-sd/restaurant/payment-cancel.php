<?php
require 'includes/sslcommerz.php';
if($_SERVER['REQUEST_METHOD']==='POST' && !empty($_POST['tran_id'])) sslc_mark((string)$_POST['tran_id'],'cancelled');
pay_page('Payment cancelled','You cancelled the payment. Your order is saved, and you can pay from My Orders or choose Cash on Delivery by contacting us.',false);
