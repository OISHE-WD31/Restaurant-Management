<?php
// Server-to-server notification from SSLCommerz. Needs a public URL; it cannot reach localhost.
require 'includes/sslcommerz.php';
if($_SERVER['REQUEST_METHOD']==='POST' && in_array($_POST['status']??'',['VALID','VALIDATED'],true)) sslc_settle($_POST);
http_response_code(200); echo 'OK';
