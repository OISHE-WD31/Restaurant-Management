<?php
// Small JSON endpoint used by the header/notification scripts (mark as read without reloading the page).
require_once 'includes/account-actions.php';
header('Content-Type: application/json'); header('Cache-Control: no-store');
function aa_out(array $a,int $c=200): void { http_response_code($c); echo json_encode($a); exit; }
$c=acct_customer(); if(!$c) aa_out(['ok'=>false,'msg'=>'Please log in.'],401);
if($_SERVER['REQUEST_METHOD']!=='POST'||!hash_equals($_SESSION['csrf']??'',$_SERVER['HTTP_X_CSRF']??'')) aa_out(['ok'=>false,'msg'=>'Invalid request.'],403);
$cid=(int)$c['id']; $act=(string)($_POST['act']??'');
if($act==='read') $r=acct_notif_read($cid,(int)($_POST['id']??0));
elseif($act==='read_all') $r=acct_notif_read_all($cid);
else aa_out(['ok'=>false,'msg'=>'Unknown action.'],400);
$r['unread']=acct_unread($cid); aa_out($r);
