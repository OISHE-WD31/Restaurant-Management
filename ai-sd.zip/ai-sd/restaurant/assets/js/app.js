const toast=(m)=>{const t=document.getElementById('toast');t.textContent=m;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2200)};
const burger=document.querySelector('.burger');
burger?.addEventListener('click',()=>{const o=document.getElementById('links').classList.toggle('open');burger.setAttribute('aria-expanded',o)});
document.addEventListener('click',async e=>{
  const b=e.target.closest('.btn-add'); if(!b) return;
  b.classList.add('loading');
  try{
    const r=await fetch('cart-action.php',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded','X-CSRF':document.querySelector('meta[name=csrf]').content},body:'id='+b.dataset.id+'&qty='+(b.closest('.detail')?document.getElementById('qty').value:1)});
    const j=await r.json(); toast(j.msg);
    if(j.ok){const c=document.getElementById('cart-count');c.textContent=j.count;c.classList.remove('pop');void c.offsetWidth;c.classList.add('pop')}
  }catch{toast('Something went wrong. Try again.')}
  b.classList.remove('loading');
});

/* ===== Customer account: header dropdown + notification helpers ===== */
(()=>{
  const btn=document.getElementById('acct-btn'),dd=document.getElementById('acct-dd');
  if(btn&&dd){
    const set=o=>{dd.hidden=!o;btn.setAttribute('aria-expanded',o)};
    btn.addEventListener('click',e=>{e.stopPropagation();set(dd.hidden)});
    document.addEventListener('click',e=>{if(!dd.hidden&&!dd.contains(e.target)&&!btn.contains(e.target))set(false)});
    document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!dd.hidden){set(false);btn.focus()}});
    dd.addEventListener('click',e=>{if(e.target.closest('a'))set(false)});   // close after choosing an item
  }
  // Opening a notification marks it read in the background (a POST with the CSRF token), then the page opens as normal.
  document.addEventListener('click',e=>{
    const a=e.target.closest('a[data-notif-id]'); if(!a) return;
    const t=document.querySelector('meta[name=csrf]'); if(!t) return;
    try{fetch('account-action.php',{method:'POST',keepalive:true,headers:{'Content-Type':'application/x-www-form-urlencoded','X-CSRF':t.content},body:'act=read&id='+encodeURIComponent(a.dataset.notifId)})}catch{}
  });
})();
