(()=>{
const $=id=>document.getElementById(id), btn=$('nb-btn'); if(!btn) return;
const panel=$('nb-panel'),badge=$('nb-badge'),list=$('nb-list'),mute=$('nb-mute'),readAll=$('nb-readall');
const csrf=document.querySelector('meta[name=csrf]').content, API='notifications-api.php', KEY='nbLastId';
let muted=localStorage.getItem('nbMuted')==='1', ctx=null, busy=false;
const AC=window.AudioContext||window.webkitAudioContext;
// Browsers block audio until the user interacts once, so unlock on the first click.
document.addEventListener('click',()=>{try{ctx=ctx||new AC();ctx.resume()}catch(e){}},{once:true});
function ping(){ if(muted||!ctx||ctx.state!=='running') return; const t=ctx.currentTime;
  [880,1175].forEach((f,i)=>{const o=ctx.createOscillator(),g=ctx.createGain();o.frequency.value=f;o.connect(g);g.connect(ctx.destination);
    g.gain.setValueAtTime(.0001,t+i*.15);g.gain.exponentialRampToValueAtTime(.15,t+i*.15+.02);g.gain.exponentialRampToValueAtTime(.0001,t+i*.15+.25);o.start(t+i*.15);o.stop(t+i*.15+.3)}); }
const ago=ts=>{const s=Math.max(0,Date.now()/1000-ts);return s<60?'just now':s<3600?Math.floor(s/60)+' min ago':s<86400?Math.floor(s/3600)+' h ago':Math.floor(s/86400)+' d ago'};
function mk(tag,cls,txt){const n=document.createElement(tag);if(cls)n.className=cls;if(txt!==undefined)n.textContent=txt;return n}
function render(d){
  badge.hidden=d.unread<1; badge.textContent=d.unread>99?'99+':d.unread;
  list.replaceChildren();
  if(!d.items.length){list.appendChild(mk('p','nb-empty','No notifications yet.'));return}
  d.items.forEach(n=>{
    const row=mk('div','nb-item'+(n.is_read?'':' unread')); row.tabIndex=0; row.setAttribute('role','link');
    const top=mk('div','nb-top'); top.append(mk('span','nb-type nb-'+n.type,n.type),mk('small','',n.at+' · '+ago(n.ts)));
    const x=mk('button','nb-x','×'); x.type='button'; x.title='Delete'; x.setAttribute('aria-label','Delete notification');
    x.onclick=e=>{e.stopPropagation();act('delete',n.id)};
    row.append(x,top,mk('b','',n.title),mk('p','',n.message));
    const go=async()=>{ if(!n.is_read) await act('read',n.id); if(n.link) location.href=n.link; };
    row.onclick=go; row.onkeydown=e=>{if(e.key==='Enter')go()};
    list.appendChild(row);
  });
}
function apply(d){
  if(!d||!d.ok) return; render(d);
  const last=localStorage.getItem(KEY);
  if(last!==null && d.latest_id>+last) ping();   // sound only for genuinely new items
  localStorage.setItem(KEY,String(d.latest_id));
}
async function call(opts){
  if(busy&&!opts) return; busy=true;
  try{ const r=await fetch(API,opts); if(r.status===401){clearInterval(timer);return} apply(await r.json()); }catch(e){} busy=false;
}
function act(action,id){ return call({method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded','X-CSRF':csrf},body:new URLSearchParams({action,id:id||0})}); }
const open=v=>{panel.classList.toggle('open',v);btn.setAttribute('aria-expanded',v)};
btn.onclick=e=>{e.stopPropagation();open(!panel.classList.contains('open'))};
document.addEventListener('click',e=>{if(!$('nb').contains(e.target))open(false)});
document.addEventListener('keydown',e=>{if(e.key==='Escape')open(false)});
readAll.onclick=()=>act('read_all');
const label=()=>mute.textContent=muted?'Sound off':'Sound on'; label();
mute.onclick=()=>{muted=!muted;localStorage.setItem('nbMuted',muted?'1':'0');label()};
const poll=()=>{if(!document.hidden)call()};
document.addEventListener('visibilitychange',poll);
poll(); const timer=setInterval(poll,5000);
})();
