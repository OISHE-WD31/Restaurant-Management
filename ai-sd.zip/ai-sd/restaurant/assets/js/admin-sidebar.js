(()=>{
const nav=document.querySelector('.side-nav'); if(!nav) return;
const groups=[...nav.querySelectorAll('.side-group')];
const set=(g,open)=>{g.classList.toggle('open',open);g.querySelector('.side-parent').setAttribute('aria-expanded',open?'true':'false')};
// Accordion: opening a group closes the others; clicking an open group collapses it.
groups.forEach(g=>g.querySelector('.side-parent').addEventListener('click',()=>{
  const open=!g.classList.contains('open');
  if(open) groups.forEach(o=>{if(o!==g) set(o,false)});
  set(g,open);
  if(open) setTimeout(()=>{const r=g.getBoundingClientRect(),n=nav.getBoundingClientRect(); if(r.bottom>n.bottom||r.top<n.top) nav.scrollTo({top:nav.scrollTop+(r.top-n.top)-8,behavior:'smooth'})},320);
}));
// Bring the active page into view inside the sidebar on load.
const on=nav.querySelector('a.on');
if(on){const r=on.getBoundingClientRect(),n=nav.getBoundingClientRect(); if(r.bottom>n.bottom||r.top<n.top) nav.scrollTop+=(r.top-n.top)-n.height/2}
// Mobile drawer: Esc closes it.
const sb=document.getElementById('sb');
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&sb&&sb.checked) sb.checked=false});
})();
