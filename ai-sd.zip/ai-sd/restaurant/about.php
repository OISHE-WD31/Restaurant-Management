<?php $title='About'; require 'includes/header.php'; ?>
<section class="sec wrap narrow2"><h2>About <?= e(setting('restaurant_name')) ?></h2>
<p>We started with one pot and one rule: cook it the slow way. Our biryani rice is aged for fragrance, our meat is marinated overnight, and our spices are ground in-house every morning.</p>
<p>Every order is cooked fresh, sealed hot and delivered the same hour. If something is not right, tell us and we will fix it.</p>
<h3>Opening hours</h3><p><?= e(setting('opening_hours')) ?></p><a class="btn dark" href="menu.php">See the menu</a></section>
<?php require 'includes/footer.php'; ?>
