<?php
// State-changing actions for the customer account. Every function takes the customer id from the session (never from the browser)
// and returns ['ok'=>bool,'msg'=>string]. CSRF is checked by the caller (my-account.php / account-action.php) before any of these run.
require_once __DIR__.'/functions.php';

function acct_profile_save(int $cid,array $in): array {
    $pdo=db();
    $name=trim((string)($in['name']??'')); $phone=trim((string)($in['phone']??'')); $email=trim((string)($in['email']??'')); $gender=(string)($in['gender']??'');
    $err=[];
    if(mb_strlen($name)<2||mb_strlen($name)>100) $err[]='Enter your name (2 to 100 characters).';
    if(!preg_match('/^\+?[0-9\- ]{7,20}$/',$phone)) $err[]='Enter a valid phone number.';
    if(!filter_var($email,FILTER_VALIDATE_EMAIL)||mb_strlen($email)>150) $err[]='Enter a valid email address.';
    if(!in_array($gender,['','male','female','other'],true)) $err[]='Choose a valid gender option.';
    if($err) return ['ok'=>false,'msg'=>implode(' ',$err)];
    $s=$pdo->prepare('SELECT * FROM customers WHERE id=?'); $s->execute([$cid]); $me=$s->fetch();
    if(!$me) return ['ok'=>false,'msg'=>'Account not found.'];
    if(strcasecmp($email,$me['email'])!==0){
        // Changing the email changes how the customer logs in, so we ask for the current password first.
        if(!password_verify((string)($in['current_password']??''),$me['password_hash'])) return ['ok'=>false,'msg'=>'To change your email address, enter your current password correctly.'];
        $d=$pdo->prepare('SELECT id FROM customers WHERE email=? AND id<>?'); $d->execute([$email,$cid]);
        if($d->fetch()) return ['ok'=>false,'msg'=>'That email address is already used by another account.'];
    }
    if($phone!==(string)$me['phone']){
        $d=$pdo->prepare('SELECT id FROM customers WHERE phone=? AND id<>?'); $d->execute([$phone,$cid]);
        if($d->fetch()) return ['ok'=>false,'msg'=>'That phone number is already used by another account.'];
    }
    try{
        $pdo->prepare('UPDATE customers SET name=?,phone=?,email=?,gender=? WHERE id=?')->execute([$name,$phone,$email,$gender!==''?$gender:null,$cid]);
    }catch(PDOException $e){
        if($e->getCode()==='23000') return ['ok'=>false,'msg'=>'That email address is already used by another account.'];
        error_log('profile_save: '.$e->getMessage()); return ['ok'=>false,'msg'=>'Could not save your profile. Please try again.'];
    }
    $_SESSION['customer_name']=$name;
    return ['ok'=>true,'msg'=>'Your profile was updated.'];
}

function acct_address_save(int $cid,array $in,int $id=0): array {
    [$v,$err]=acct_address_clean($in); if($err) return ['ok'=>false,'msg'=>implode(' ',$err)];
    $pdo=db();
    try{
        $pdo->beginTransaction();
        $pdo->prepare('SELECT id FROM customer_addresses WHERE customer_id=? FOR UPDATE')->execute([$cid]); // serialise changes for this customer
        $cnt=$pdo->prepare('SELECT COUNT(*) FROM customer_addresses WHERE customer_id=?'); $cnt->execute([$cid]); $n=(int)$cnt->fetchColumn();
        if($id>0){
            $u=$pdo->prepare('UPDATE customer_addresses SET address_type=?,full_address=?,city=?,area=?,postal_code=?,instructions=? WHERE id=? AND customer_id=?');
            $u->execute([$v['address_type'],$v['full_address'],$v['city'],$v['area']?:null,$v['postal_code']?:null,$v['instructions']?:null,$id,$cid]);
            $ex=$pdo->prepare('SELECT COUNT(*) FROM customer_addresses WHERE id=? AND customer_id=?'); $ex->execute([$id,$cid]);
            if(!(int)$ex->fetchColumn()){ $pdo->rollBack(); return ['ok'=>false,'msg'=>'Address not found.']; }
            $pdo->commit(); return ['ok'=>true,'msg'=>'Address updated.'];
        }
        if($n>=10){ $pdo->rollBack(); return ['ok'=>false,'msg'=>'You can save up to 10 addresses. Please delete one first.']; }
        $isDefault=$n===0||!empty($in['is_default']); if($isDefault) $pdo->prepare('UPDATE customer_addresses SET is_default=0 WHERE customer_id=?')->execute([$cid]);
        $pdo->prepare('INSERT INTO customer_addresses(customer_id,address_type,full_address,city,area,postal_code,instructions,is_default) VALUES(?,?,?,?,?,?,?,?)')
            ->execute([$cid,$v['address_type'],$v['full_address'],$v['city'],$v['area']?:null,$v['postal_code']?:null,$v['instructions']?:null,$isDefault?1:0]);
        $pdo->commit(); return ['ok'=>true,'msg'=>'Address added.'];
    }catch(Throwable $e){ if($pdo->inTransaction()) $pdo->rollBack(); error_log('address_save: '.$e->getMessage()); return ['ok'=>false,'msg'=>'Could not save the address. Please try again.']; }
}

function acct_address_default(int $cid,int $id): array {
    $pdo=db();
    try{
        $pdo->beginTransaction();
        $s=$pdo->prepare('SELECT id FROM customer_addresses WHERE id=? AND customer_id=? FOR UPDATE'); $s->execute([$id,$cid]);
        if(!$s->fetch()){ $pdo->rollBack(); return ['ok'=>false,'msg'=>'Address not found.']; }
        $pdo->prepare('UPDATE customer_addresses SET is_default=0 WHERE customer_id=?')->execute([$cid]);
        $pdo->prepare('UPDATE customer_addresses SET is_default=1 WHERE id=? AND customer_id=?')->execute([$id,$cid]);
        $pdo->commit(); return ['ok'=>true,'msg'=>'Default address updated.'];
    }catch(Throwable $e){ if($pdo->inTransaction()) $pdo->rollBack(); error_log('address_default: '.$e->getMessage()); return ['ok'=>false,'msg'=>'Could not change the default address.']; }
}

function acct_address_delete(int $cid,int $id): array {
    $pdo=db();
    try{
        $pdo->beginTransaction();
        $s=$pdo->prepare('SELECT id,is_default FROM customer_addresses WHERE id=? AND customer_id=? FOR UPDATE'); $s->execute([$id,$cid]); $a=$s->fetch();
        if(!$a){ $pdo->rollBack(); return ['ok'=>false,'msg'=>'Address not found.']; }
        $pdo->prepare('DELETE FROM customer_addresses WHERE id=? AND customer_id=?')->execute([$id,$cid]);
        if((int)$a['is_default']){ // the default was removed: promote the most recently added remaining address, if any
            $pdo->prepare('UPDATE customer_addresses SET is_default=1 WHERE customer_id=? ORDER BY id DESC LIMIT 1')->execute([$cid]);
        }
        $pdo->commit(); return ['ok'=>true,'msg'=>'Address deleted. Your past orders keep their delivery address.'];
    }catch(Throwable $e){ if($pdo->inTransaction()) $pdo->rollBack(); error_log('address_delete: '.$e->getMessage()); return ['ok'=>false,'msg'=>'Could not delete the address.']; }
}

function acct_notif_read(int $cid,int $id): array {
    $s=db()->prepare('UPDATE customer_notifications SET is_read=1 WHERE id=? AND customer_id=?'); $s->execute([$id,$cid]); return ['ok'=>true,'msg'=>'Marked as read.'];
}
function acct_notif_read_all(int $cid): array {
    $s=db()->prepare('UPDATE customer_notifications SET is_read=1 WHERE customer_id=? AND is_read=0'); $s->execute([$cid]); return ['ok'=>true,'msg'=>'All notifications marked as read.'];
}
