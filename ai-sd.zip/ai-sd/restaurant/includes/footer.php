</main>
<footer class="foot"><div class="wrap grid3">
<div><a class="logo" href="index.php"><i class="fa-solid fa-leaf"></i> <?= e(setting('restaurant_name')) ?></a><p><?= e(setting('address')) ?></p></div>
<div><h4>Quick links</h4><a href="menu.php">Menu</a><a href="about.php">About</a><a href="contact.php">Contact</a></div>
<div><h4>Opening hours</h4><p><?= e(setting('opening_hours')) ?></p>
<a href="<?= e(setting('facebook')) ?>" aria-label="Facebook"><i class="fa-brands fa-facebook"></i></a> <a href="<?= e(setting('instagram')) ?>" aria-label="Instagram"><i class="fa-brands fa-instagram"></i></a></div>
</div><p class="copy">© <?= date('Y') ?> <?= e(setting('restaurant_name')) ?></p></footer>
<script src="assets/js/app.js"></script></body></html>
