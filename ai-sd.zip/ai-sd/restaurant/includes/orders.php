<?php
/** Central order state machine. Every status change goes through here so side effects run exactly once. */
const ORDER_STATUSES=['pending','confirmed','preparing','ready','out_for_delivery','delivered','cancelled'];
/** The single definition of "counts as revenue": delivered AND payment verified as paid. Cancelled, unpaid, failed orders never count.
 *  COD orders become 'paid' automatically on delivery; online orders also need a matching verified gateway payment record. */
function rev_where(string $alias=''): string { $t=$alias!==''?$alias:'orders'; $a=$t.'.';
    return "{$a}status='delivered' AND {$a}payment_status='paid' AND ({$a}payment_method='cod' OR EXISTS(SELECT 1 FROM payments pv WHERE pv.order_id={$a}id AND pv.status IN ('validated','refunded') AND pv.val_id<>'' AND ABS(pv.amount-{$a}total)<0.01))"; }
function order_transition(int $orderId,string $new,int $adminId=0): array {
    if(!in_array($new,ORDER_STATUSES,true)) return ['ok'=>false,'msg'=>'Unknown status.'];
    $pdo=db();
    try{
        $pdo->beginTransaction();
        $st=$pdo->prepare('SELECT * FROM orders WHERE id=? FOR UPDATE'); $st->execute([$orderId]); $o=$st->fetch();
        if(!$o){ $pdo->rollBack(); return ['ok'=>false,'msg'=>'Order not found.']; }
        $old=$o['status'];
        if($old===$new){ $pdo->rollBack(); return ['ok'=>true,'msg'=>'Status unchanged.','changed'=>false]; }
        if(in_array($old,['delivered','cancelled'],true)){ $pdo->rollBack(); return ['ok'=>false,'msg'=>'This order is already closed and cannot be changed.']; }
        if($new==='delivered' && $o['payment_method']==='online' && $o['payment_status']!=='paid'){ $pdo->rollBack(); return ['ok'=>false,'msg'=>'This online order has no verified payment yet, so it cannot be marked delivered.']; }
        $set=['status=?']; $args=[$new];
        if($new==='confirmed') $set[]='confirmed_at=COALESCE(confirmed_at,NOW())';
        if($new==='ready') $set[]='ready_at=COALESCE(ready_at,NOW())';
        if($new==='delivered'){ $set[]='delivered_at=NOW()'; if($o['payment_method']==='cod') $set[]="payment_status='paid'"; }
        $args[]=$orderId;
        $pdo->prepare('UPDATE orders SET '.implode(',',$set).' WHERE id=?')->execute($args);
        // Later phases (stock, loyalty) define this hook; it runs inside the same transaction.
        if(function_exists('order_after_transition')) order_after_transition($pdo,$o,$old,$new,$adminId);
        $pdo->commit();
        // The status is saved. Tell the customer afterwards; this never throws, so it cannot undo the update.
        if(function_exists('cn_order_event')) cn_order_event($orderId,$new);
        return ['ok'=>true,'msg'=>'Order status updated.','changed'=>true];
    }catch(StockShortage $e){ if($pdo->inTransaction()) $pdo->rollBack(); return ['ok'=>false,'msg'=>$e->getMessage()];
    }catch(Throwable $e){ if($pdo->inTransaction()) $pdo->rollBack(); error_log('order_transition: '.$e->getMessage()); return ['ok'=>false,'msg'=>'Could not update the order. Nothing was changed.']; }
}
