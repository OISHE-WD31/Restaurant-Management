<?php
// Phase 7: login throttling. Slows down password guessing without locking real customers out for long.
// Needs database/migrations/08_login_attempts.sql. If that table does not exist yet, these functions do nothing (login keeps working as before).
const SEC_WINDOW=900;          // look at the last 15 minutes
const SEC_MAX_PER_ACCOUNT=5;   // wrong passwords allowed per email
const SEC_MAX_PER_IP=25;       // wrong passwords allowed per visitor address
function sec_ip(): string { return substr((string)($_SERVER['REMOTE_ADDR']??''),0,45); }
function sec_id(string $v): string { return mb_substr(mb_strtolower(trim($v)),0,190); }
function sec_blocked(string $scope,string $ident): bool {
    try{ $pdo=db(); $since=date('Y-m-d H:i:s',time()-SEC_WINDOW);
        $a=$pdo->prepare('SELECT COUNT(*) FROM login_attempts WHERE scope=? AND identifier=? AND created_at>=?'); $a->execute([$scope,sec_id($ident),$since]);
        if((int)$a->fetchColumn()>=SEC_MAX_PER_ACCOUNT) return true;
        $b=$pdo->prepare('SELECT COUNT(*) FROM login_attempts WHERE scope=? AND ip=? AND created_at>=?'); $b->execute([$scope,sec_ip(),$since]);
        return (int)$b->fetchColumn()>=SEC_MAX_PER_IP;
    }catch(Throwable $e){ return false; }
}
function sec_fail(string $scope,string $ident): void {
    try{ $pdo=db(); $pdo->prepare('INSERT INTO login_attempts(scope,identifier,ip,created_at) VALUES(?,?,?,?)')->execute([$scope,sec_id($ident),sec_ip(),date('Y-m-d H:i:s')]);
        if(random_int(1,50)===1) $pdo->prepare('DELETE FROM login_attempts WHERE created_at<?')->execute([date('Y-m-d H:i:s',time()-86400)]);
    }catch(Throwable $e){}
}
function sec_clear(string $scope,string $ident): void { try{ db()->prepare('DELETE FROM login_attempts WHERE scope=? AND identifier=?')->execute([$scope,sec_id($ident)]); }catch(Throwable $e){} }
const SEC_BLOCK_MSG='Too many wrong attempts. Please wait 15 minutes and try again.';
