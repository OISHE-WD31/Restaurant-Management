<?php
require_once __DIR__.'/../config/database.php';
if(session_status()===PHP_SESSION_NONE){
    ini_set('session.use_strict_mode','1');
    session_set_cookie_params(['httponly'=>true,'samesite'=>'Lax','secure'=>!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off']);
    session_start();
}
function e($v): string { return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8'); }
function csrf_token(): string { return $_SESSION['csrf']??=bin2hex(random_bytes(32)); }
function csrf_field(): string { return '<input type="hidden" name="csrf" value="'.csrf_token().'">'; }
function csrf_check(): bool { return isset($_POST['csrf'],$_SESSION['csrf']) && hash_equals($_SESSION['csrf'],$_POST['csrf']); }
function setting(string $k,string $d=''): string {
    static $all=null;
    if($all===null) $all=db()->query('SELECT setting_key,setting_value FROM restaurant_settings')->fetchAll(PDO::FETCH_KEY_PAIR);
    return $all[$k]??$d;
}
function require_login(string $next): void {
    if(empty($_SESSION['customer_id'])){ header('Location: login.php?next='.urlencode($next)); exit; }
}
function money($n): string { return '৳'.number_format((float)$n,0); }
function price_now(array $p): float { return $p['discount_price']!==null ? (float)$p['discount_price'] : (float)$p['price']; }
function product_img(?string $f): string { return $f ? 'uploads/products/'.e($f) : 'assets/images/placeholder.svg'; }
function cart_count(): int { return array_sum($_SESSION['cart']??[]); }
function stars(float $r): string {
    $o=''; for($i=1;$i<=5;$i++) $o.='<i class="fa-'.($i<=round($r)?'solid':'regular').' fa-star"></i>'; return $o;
}
function food_card(array $p, string $shape=''): void { ?>
  <article class="food-card <?= e($shape) ?>">
    <a class="food-img" href="food-details.php?id=<?= (int)$p['id'] ?>"><img src="<?= product_img($p['image']) ?>" alt="<?= e($p['name']) ?>" loading="lazy"></a>
    <div class="food-body">
      <h3><?= e($p['name']) ?></h3>
      <div class="stars"><?= stars((float)$p['rating']) ?></div>
      <p><?= e(mb_strimwidth($p['description'],0,70,'…')) ?></p>
      <div class="food-foot">
        <span class="price-tag"><?php if($p['discount_price']!==null): ?><s><?= money($p['price']) ?></s> <?php endif; ?><?= money(price_now($p)) ?></span>
        <?php if($p['is_available']): ?>
          <button class="btn-add" data-id="<?= (int)$p['id'] ?>">Add to cart</button>
        <?php else: ?><span class="sold-out">Sold out</span><?php endif; ?>
      </div>
    </div>
  </article>
<?php }

require_once __DIR__.'/notifications.php';
require_once __DIR__.'/orders.php';
require_once __DIR__.'/reservations.php';
require_once __DIR__.'/inventory.php';
require_once __DIR__.'/analytics.php';
require_once __DIR__.'/refunds.php';
require_once __DIR__.'/sentiment.php';
require_once __DIR__.'/loyalty.php';
require_once __DIR__.'/mailer.php';
require_once __DIR__.'/reservation-notify.php';
require_once __DIR__.'/customer-notify.php';
require_once __DIR__.'/account.php';
require_once __DIR__.'/security.php';
