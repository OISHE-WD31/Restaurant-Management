<?php
/** Refund recording. This only records the refund in the restaurant's books; it does NOT send money back through the gateway.
 *  For online payments, issue the actual refund in the SSLCommerz merchant panel as well.
 *  Rules:
 *   - only orders whose payment is verified 'paid' can be refunded
 *   - the total refunded can never exceed the order total (partial refunds are allowed)
 *   - a full refund marks the order payment (and its validated gateway payment) as 'refunded'
 *   - a full refund of an order that is not delivered yet also cancels it, which restores stock through the normal cancel path
 *   - a full refund of a delivered order does not restore stock, because the food was already served */
function refund_total(PDO $pdo,int $orderId): float {
    $s=$pdo->prepare('SELECT COALESCE(SUM(amount),0) FROM order_refunds WHERE order_id=?'); $s->execute([$orderId]); return (float)$s->fetchColumn();
}
function refund_order(int $orderId,float $amount,string $reason,int $adminId): array {
    $reason=trim($reason); $amount=round($amount,2);
    if($amount<=0) return ['ok'=>false,'msg'=>'Enter a refund amount above 0.'];
    if($reason===''||mb_strlen($reason)>255) return ['ok'=>false,'msg'=>'Enter a reason (up to 255 characters).'];
    $pdo=db(); $full=false; $status='';
    try{
        $pdo->beginTransaction();
        $st=$pdo->prepare('SELECT * FROM orders WHERE id=? FOR UPDATE'); $st->execute([$orderId]); $o=$st->fetch();
        if(!$o){ $pdo->rollBack(); return ['ok'=>false,'msg'=>'Order not found.']; }
        if($o['payment_status']!=='paid'){ $pdo->rollBack(); return ['ok'=>false,'msg'=>'Only orders with a verified payment can be refunded.']; }
        $left=round((float)$o['total']-refund_total($pdo,$orderId),2);
        if($amount>$left+0.0001){ $pdo->rollBack(); return ['ok'=>false,'msg'=>'You can refund at most '.money($left).' on this order.']; }
        $pdo->prepare('INSERT INTO order_refunds(order_id,amount,reason,created_by) VALUES(?,?,?,?)')->execute([$orderId,$amount,$reason,$adminId?:null]);
        $full=abs($left-$amount)<0.005; $status=$o['status'];
        if($full){
            $pdo->prepare("UPDATE orders SET payment_status='refunded' WHERE id=?")->execute([$orderId]);
            $pdo->prepare("UPDATE payments SET status='refunded' WHERE order_id=? AND status='validated'")->execute([$orderId]);
        }
        if(function_exists('loyalty_on_refund')) loyalty_on_refund($pdo,$o);
        $pdo->commit();
    }catch(Throwable $e){ if($pdo->inTransaction()) $pdo->rollBack(); error_log('refund_order: '.$e->getMessage()); return ['ok'=>false,'msg'=>'Could not record the refund. Nothing was changed. (Have you run database/migrations/04_bugfix_refunded_state.sql?)']; }
    $msg=$full?'Full refund recorded.':'Partial refund recorded.';
    if($full && !in_array($status,['delivered','cancelled'],true)){
        $r=order_transition($orderId,'cancelled',$adminId); $msg.=$r['ok']?' The order was cancelled and its stock restored.':' The refund is saved, but the order could not be cancelled automatically: '.$r['msg'];
    }
    return ['ok'=>true,'msg'=>$msg.' Remember to send the money back through the payment gateway or in cash.'];
}
