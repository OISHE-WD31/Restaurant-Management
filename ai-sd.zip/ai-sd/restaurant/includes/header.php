<?php require_once __DIR__.'/functions.php'; $page=basename($_SERVER['SCRIPT_NAME'],'.php'); ?>
<!doctype html><html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= e($title??setting('restaurant_name')) ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,700&family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<link rel="stylesheet" href="assets/css/style.css">
<meta name="csrf" content="<?= csrf_token() ?>">
</head><body>
<header class="nav"><a class="logo" href="index.php"><?php if(setting('logo')): ?><img class="logo-img" src="uploads/products/<?= e(setting('logo')) ?>" alt=""><?php else: ?><i class="fa-solid fa-leaf"></i><?php endif; ?> <?= e(setting('restaurant_name')) ?></a>
<button class="burger" aria-label="Menu" aria-expanded="false"><i class="fa-solid fa-bars"></i></button>
<nav id="links">
<?php foreach(['index'=>'Home','menu'=>'Menu','about'=>'About','contact'=>'Contact','reserve-table'=>'Reserve'] as $f=>$l): ?>
<a href="<?= $f ?>.php" class="<?= $page===$f?'on':'' ?>"><?= $l ?></a><?php endforeach; ?>
<a href="cart.php" class="cart-link" aria-label="Cart"><i class="fa-solid fa-basket-shopping"></i><b id="cart-count"><?= cart_count() ?></b></a>
<?php if(!empty($_SESSION['customer_id'])): $hn=(string)($_SESSION['customer_name']??'Account'); $hu=cust_unread_count(); ?>
<div class="acct-menu"><button type="button" class="acct-btn" id="acct-btn" aria-haspopup="true" aria-expanded="false" aria-controls="acct-dd" aria-label="My account menu">
<span class="avatar"><?= e(mb_strtoupper(mb_substr($hn,0,1))) ?></span><span class="acct-name"><?= e(mb_strimwidth($hn,0,14,'…')) ?></span><i class="fa-solid fa-chevron-down caret"></i><?php if($hu>0): ?><span class="alert-badge acct-badge" data-unread><?= (int)$hu ?></span><?php endif; ?></button>
<div class="acct-dd" id="acct-dd" hidden><div class="acct-dd-head"><b><?= e($hn) ?></b><small>Signed in</small></div>
<?php foreach(['overview'=>['My Account','fa-gauge'],'profile'=>['My Profile','fa-user'],'orders'=>['My Orders','fa-bag-shopping'],'reservations'=>['My Reservations','fa-calendar-check'],'addresses'=>['My Address','fa-location-dot'],'rewards'=>['My Rewards','fa-gift'],'notifications'=>['Notifications','fa-bell']] as $k=>[$l,$ic]): ?>
<a href="my-account.php?section=<?= $k ?>" role="menuitem"><i class="fa-solid <?= $ic ?>"></i><span><?= $l ?></span><?php if($k==='notifications'&&$hu>0): ?><span class="alert-badge" data-unread><?= (int)$hu ?></span><?php endif; ?></a><?php endforeach; ?>
<a href="logout.php" role="menuitem" class="out"><i class="fa-solid fa-right-from-bracket"></i><span>Logout</span></a></div></div>
<?php else: ?><a href="login.php" class="acct-login"><i class="fa-regular fa-circle-user"></i> Login / Sign Up</a><?php endif; ?>
<a class="btn" href="menu.php">Order now</a></nav></header>
<div id="toast" role="status"></div>
<main>
