<?php
require_once __DIR__.'/functions.php';
function cart_items(): array {
    $c=$_SESSION['cart']??[]; if(!$c) return [];
    $ids=array_keys($c);
    $st=db()->prepare('SELECT * FROM products WHERE is_available=1 AND id IN ('.implode(',',array_fill(0,count($ids),'?')).')');
    $st->execute($ids); $rows=[];
    foreach($st->fetchAll() as $p){ $p['qty']=(int)$c[$p['id']]; $p['unit']=price_now($p); $p['line']=$p['unit']*$p['qty']; $rows[]=$p; }
    return $rows;
}
function find_coupon(string $code): ?array {
    $st=db()->prepare('SELECT * FROM coupons WHERE code=? AND is_active=1 AND (expires_at IS NULL OR expires_at>=CURDATE()) AND (max_uses IS NULL OR used_count<max_uses) AND (customer_id IS NULL OR customer_id=?)');
    $st->execute([strtoupper(trim($code)),(int)($_SESSION['customer_id']??0)]); return $st->fetch()?:null;
}
function cart_totals(array $items): array {
    $sub=array_sum(array_column($items,'line')); $disc=0; $coupon=null;
    if(!empty($_SESSION['coupon'])) $coupon=find_coupon($_SESSION['coupon']);
    if($coupon) $disc=min($sub,$coupon['type']==='percent'?round($sub*$coupon['value']/100,2):(float)$coupon['value']);
    $del=$sub>0?(float)setting('delivery_charge','0'):0;
    return ['subtotal'=>$sub,'discount'=>$disc,'delivery'=>$del,'total'=>$sub-$disc+$del,'coupon'=>$coupon];
}
