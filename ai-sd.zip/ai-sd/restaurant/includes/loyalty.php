<?php
// Points move only through these server functions; customers cannot edit balances. One earn and one reverse per order (database-enforced).
function loy_rules(): array {
    static $r=null; if($r!==null) return $r;
    $d=['spend_per_point'=>'10','first_order_bonus'=>'20','silver_spent'=>'5000','gold_spent'=>'15000','vip_spent'=>'40000','silver_bonus'=>'10','gold_bonus'=>'20','vip_bonus'=>'30','redeem_points'=>'100','redeem_value'=>'50','coupon_days'=>'30'];
    try{ $d=array_merge($d,db()->query('SELECT rule_key,rule_value FROM reward_rules')->fetchAll(PDO::FETCH_KEY_PAIR)); }catch(Throwable $e){} return $r=$d;
}
function loy_tier(float $spent): string { $r=loy_rules(); return $spent>=$r['vip_spent']?'vip':($spent>=$r['gold_spent']?'gold':($spent>=$r['silver_spent']?'silver':'bronze')); }
function loy_spent(PDO $pdo,int $cid): float {
    $s=$pdo->prepare('SELECT COALESCE(SUM(o.total),0) FROM orders o WHERE o.customer_id=? AND '.rev_where('o')); $s->execute([$cid]);
    $r=$pdo->prepare('SELECT COALESCE(SUM(r.amount),0) FROM order_refunds r JOIN orders o ON o.id=r.order_id WHERE o.customer_id=? AND '.rev_where('o')); $r->execute([$cid]);
    return (float)$s->fetchColumn()-(float)$r->fetchColumn();
}
function loy_account(PDO $pdo,int $cid): array { $pdo->prepare('INSERT IGNORE INTO loyalty_accounts(customer_id) VALUES(?)')->execute([$cid]); $s=$pdo->prepare('SELECT * FROM loyalty_accounts WHERE customer_id=? FOR UPDATE'); $s->execute([$cid]); return $s->fetch(); }
function loy_refresh_tier(PDO $pdo,int $cid): void { $pdo->prepare('UPDATE loyalty_accounts SET tier=? WHERE customer_id=?')->execute([loy_tier(loy_spent($pdo,$cid)),$cid]); }
/** Returns false if this order/type was already recorded (duplicate protection). */
function loy_apply(PDO $pdo,int $cid,string $type,int $points,?int $orderId,string $note,int $adminId=0): bool {
    loy_account($pdo,$cid);
    $st=$pdo->prepare('INSERT IGNORE INTO loyalty_transactions(customer_id,type,points,order_id,note,created_by) VALUES(?,?,?,?,?,?)'); $st->execute([$cid,$type,$points,$orderId,mb_substr($note,0,255),$adminId?:null]);
    if($st->rowCount()===0) return false;
    if($type==='earn') $pdo->prepare('UPDATE loyalty_accounts SET points_balance=points_balance+?,lifetime_points=lifetime_points+? WHERE customer_id=?')->execute([$points,$points,$cid]);
    elseif($type==='reverse') $pdo->prepare('UPDATE loyalty_accounts SET points_balance=points_balance+?,lifetime_points=GREATEST(0,lifetime_points+?) WHERE customer_id=?')->execute([$points,$points,$cid]);
    else $pdo->prepare('UPDATE loyalty_accounts SET points_balance=points_balance+? WHERE customer_id=?')->execute([$points,$cid]);
    loy_refresh_tier($pdo,$cid); return true;
}
function loyalty_award(PDO $pdo,array $o): bool {
    $cid=(int)$o['customer_id']; if(!$cid) return false; $r=loy_rules(); $per=(float)$r['spend_per_point']; if($per<=0) return false;
    $acc=loy_account($pdo,$cid); $base=max(0,(float)$o['subtotal']-(float)$o['discount']); $pts=(int)floor($base/$per);
    $bonus=(int)($r[$acc['tier'].'_bonus']??0); if($bonus>0) $pts+=(int)floor($pts*$bonus/100);
    $f=$pdo->prepare("SELECT COUNT(*) FROM loyalty_transactions WHERE customer_id=? AND type='earn'"); $f->execute([$cid]); if((int)$f->fetchColumn()===0) $pts+=(int)$r['first_order_bonus'];
    if($pts<=0) return false; return loy_apply($pdo,$cid,'earn',$pts,(int)$o['id'],'Order '.$o['order_no']);
}
/** An order earns points only when it is delivered AND its payment is verified: cash on delivery / pay-at-counter, or an online order with a validated gateway payment for the full amount (same rule as revenue). */
function loy_eligible(PDO $pdo,array $o): bool {
    if(($o['payment_status']??'')!=='paid') return false;
    if(($o['payment_method']??'')==='cod') return true;
    $s=$pdo->prepare("SELECT COUNT(*) FROM payments WHERE order_id=? AND status IN ('validated','refunded') AND val_id<>'' AND ABS(amount-?)<0.01"); $s->execute([$o['id'],$o['total']]); return (int)$s->fetchColumn()>0;
}
function loyalty_on_transition(PDO $pdo,array $o,string $new): void {
    if($new!=='delivered'||empty($o['customer_id'])) return;
    if(!loy_eligible($pdo,$o)) return;
    try{ loyalty_award($pdo,$o); }catch(Throwable $e){ error_log('loyalty award: '.$e->getMessage()); }
}
/** Takes back points in proportion to the money refunded (a full refund takes back everything earned on that order).
 *  There is one "reverse" row per order (database rule), so it is updated to the new total instead of adding a second row. */
function loyalty_on_refund(PDO $pdo,array $o): void {
    if(empty($o['customer_id'])) return;
    try{ $cid=(int)$o['customer_id']; $oid=(int)$o['id'];
        $s=$pdo->prepare("SELECT points FROM loyalty_transactions WHERE order_id=? AND type='earn'"); $s->execute([$oid]); $earned=(int)$s->fetchColumn(); if($earned<=0) return;
        $t=(float)$o['total']; $ref=refund_total($pdo,$oid); $ratio=$t>0?min(1,$ref/$t):1;
        $target=abs($ref-$t)<0.005||$ratio>=1?$earned:(int)round($earned*$ratio);
        loy_account($pdo,$cid);
        $x=$pdo->prepare("SELECT id,points FROM loyalty_transactions WHERE order_id=? AND type='reverse'"); $x->execute([$oid]); $row=$x->fetch(); $old=$row?-(int)$row['points']:0; $delta=$target-$old;
        if($delta===0) return;
        if($row){ $pdo->prepare('UPDATE loyalty_transactions SET points=?,note=? WHERE id=?')->execute([-$target,mb_substr('Order '.$o['order_no'].' refunded',0,255),$row['id']]);
            $pdo->prepare('UPDATE loyalty_accounts SET points_balance=points_balance-?,lifetime_points=GREATEST(0,lifetime_points-?) WHERE customer_id=?')->execute([$delta,$delta,$cid]); loy_refresh_tier($pdo,$cid); }
        else loy_apply($pdo,$cid,'reverse',-$target,$oid,'Order '.$o['order_no'].' refunded');
    }catch(Throwable $e){ error_log('loyalty reverse: '.$e->getMessage()); }
}
function loyalty_backfill(): int {
    $pdo=db(); $rows=$pdo->query("SELECT o.* FROM orders o WHERE ".rev_where('o')." AND o.customer_id IS NOT NULL AND NOT EXISTS(SELECT 1 FROM loyalty_transactions t WHERE t.order_id=o.id AND t.type='earn') ORDER BY o.id")->fetchAll(); $n=0;
    foreach($rows as $o){ try{ $pdo->beginTransaction(); if(loyalty_award($pdo,$o)) $n++; $pdo->commit(); }catch(Throwable $e){ if($pdo->inTransaction()) $pdo->rollBack(); } } return $n;
}
function loyalty_redeem(int $cid): array {
    $pdo=db(); $r=loy_rules(); $cost=(int)$r['redeem_points'];
    try{ $pdo->beginTransaction(); $acc=loy_account($pdo,$cid);
        if($cost<=0||(int)$acc['points_balance']<$cost){ $pdo->rollBack(); return ['ok'=>false,'msg'=>'You need '.$cost.' points to redeem a coupon.']; }
        $code='RW'.strtoupper(bin2hex(random_bytes(4)));
        loy_apply($pdo,$cid,'redeem',-$cost,null,'Redeemed for coupon '.$code);
        $pdo->prepare("INSERT INTO coupons(code,type,value,expires_at,is_active,max_uses,used_count,customer_id) VALUES(?,'fixed',?,?,1,1,0,?)")->execute([$code,(float)$r['redeem_value'],date('Y-m-d',strtotime('+'.(int)$r['coupon_days'].' days')),$cid]);
        $pdo->commit(); return ['ok'=>true,'msg'=>'Your coupon is '.$code.'. It is worth '.money($r['redeem_value']).' and works once, only on your account.'];
    }catch(Throwable $e){ if($pdo->inTransaction()) $pdo->rollBack(); error_log('redeem: '.$e->getMessage()); return ['ok'=>false,'msg'=>'Could not redeem right now. Please try again.']; }
}
