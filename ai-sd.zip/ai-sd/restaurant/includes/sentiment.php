<?php
// Rule-based sentiment. To use an AI service later, change ONLY review_analyze(); send it the comment text and rating, never names or contact details.
const SENT_NEG=[
 'delivery_delay'=>['late','delay','delayed','took too long','long wait','waited','slow delivery','deri','দেরি','দেরী'],
 'food_quality'=>['stale','not fresh','raw','undercooked','burnt','spoiled','rotten','bad quality','poor quality','bad smell','insect','hair in','পচা','বাসি'],
 'taste'=>['tasteless','bland','not tasty','bad taste','awful taste','no taste','too sweet','too spicy','বিস্বাদ','স্বাদ নেই','বাজে স্বাদ'],
 'salt'=>['too salty','salty','extra salt','excess salt','oversalted','beshi nun','লবণ বেশি','নুন বেশি'],
 'packaging'=>['packaging','packing','spilled','spill','leaked','leak','damaged','crushed','messy','প্যাকেজিং'],
 'portion'=>['small portion','tiny portion','portion was small','less quantity','too little','not enough','very little','কম পরিমাণ'],
 'service'=>['rude','bad service','poor service','impolite','ignored','unprofessional','no response','worst service','খারাপ ব্যবহার'],
 'temperature'=>['cold','lukewarm','not hot','not warm','thanda','ঠান্ডা','ঠাণ্ডা'],
];
const SENT_POS=[
 'taste'=>['delicious','tasty','yummy','flavorful','flavourful','mouthwatering','so good','mojar','moja','সুস্বাদু','মজার','মজা'],
 'freshness'=>['fresh','freshly'],
 'delivery'=>['fast delivery','on time','quick','quickly','prompt','arrived early','দ্রুত'],
 'service'=>['friendly','polite','helpful','great service','excellent service','good service'],
 'portion'=>['generous','big portion','large portion','filling','value for money'],
 'temperature'=>['piping hot','served hot','still hot','hot and fresh'],
 'packaging'=>['well packed','nicely packed','good packaging','neat packaging'],
 'general'=>['great','excellent','amazing','love','loved','perfect','best','awesome','wonderful','recommend','khub bhalo','bhalo','ভালো','অসাধারণ','চমৎকার'],
];
const SENT_NEG_LABEL=['delivery_delay'=>'Delivery delay','food_quality'=>'Food quality','taste'=>'Food taste','salt'=>'Excess salt','packaging'=>'Packaging issues','portion'=>'Portion size','service'=>'Customer service','temperature'=>'Food temperature'];
const SENT_POS_LABEL=['taste'=>'Great taste','freshness'=>'Fresh food','delivery'=>'Fast delivery','service'=>'Friendly service','portion'=>'Good portions','temperature'=>'Served hot','packaging'=>'Good packaging','general'=>'General praise'];
function sent_scan(array $lex,string &$text): array {
    $hits=[]; $neg='/(?:\bnot|\bno|\bnever|n\'t|\bwithout|\bnahi)\s+(?:\S+\s+)?$/u';
    foreach($lex as $topic=>$terms){ usort($terms,fn($a,$b)=>strlen($b)<=>strlen($a));
        foreach($terms as $t){
            if(!preg_match_all('/(?<![\p{L}\p{M}])'.preg_quote($t,'/').'(?![\p{L}\p{M}])/u',$text,$m,PREG_OFFSET_CAPTURE)) continue;
            foreach($m[0] as [$w,$off]){ $pre=substr($text,max(0,$off-20),min(20,$off)); $hits[]=[$topic,(bool)@preg_match($neg,$pre)]; $text=substr_replace($text,str_repeat(' ',strlen($w)),$off,strlen($w)); }
        } }
    return $hits;
}
function sentiment_rules(string $comment,int $rating): array {
    $text=mb_strtolower(trim($comment)); $topics=[]; $pos=[]; $score=0;
    foreach(sent_scan(SENT_NEG,$text) as [$t,$negated]) if(!$negated){ $topics[$t]=1; $score--; }
    foreach(sent_scan(SENT_POS,$text) as [$t,$negated]){ if($negated) $score--; else{ $pos[$t]=1; $score++; } }
    $final=$score+($rating-3); $sent=$final>=1?'positive':($final<=-1?'negative':'neutral');
    return ['sentiment'=>$sent,'score'=>$final,'topics'=>array_keys($topics),'positives'=>array_keys($pos)];
}
function review_analyze(string $comment,int $rating): array { return sentiment_rules($comment,$rating); }
function review_store_analysis(int $id): void {
    try{ $s=db()->prepare('SELECT comment,rating FROM reviews WHERE id=?'); $s->execute([$id]); $r=$s->fetch(); if(!$r) return;
        $a=review_analyze((string)$r['comment'],(int)$r['rating']);
        db()->prepare('REPLACE INTO review_analysis(review_id,sentiment,score,topics,positives,analyzer) VALUES(?,?,?,?,?,"rules")')->execute([$id,$a['sentiment'],$a['score'],implode(',',$a['topics']),implode(',',$a['positives'])]);
    }catch(Throwable $e){ error_log('review analysis: '.$e->getMessage()); }
}
