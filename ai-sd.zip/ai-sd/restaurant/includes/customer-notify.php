<?php
// Customer notifications for order and reservation status changes.
// Included by includes/functions.php. These functions NEVER throw and are only called AFTER the status change was saved,
// so a notification problem can never undo an order or reservation update. Failures are written to the PHP error log.

/** Wording for each order status. 'pending' has no notification (the customer just placed the order). */
function cn_order_texts(): array {
    return [
        'confirmed'        =>['Order confirmed','Good news! We confirmed your order %s and will start preparing it soon.'],
        'preparing'        =>['Order is being prepared','Our kitchen is now preparing your order %s.'],
        'ready'            =>['Order is ready','Your order %s is ready.'],
        'out_for_delivery' =>['Order is on the way','Your order %s is out for delivery.'],
        'delivered'        =>['Order delivered','Your order %s was delivered. Enjoy your meal!'],
        'cancelled'        =>['Order cancelled','Your order %s was cancelled. Please contact us if you have any questions.'],
    ];
}
/** Wording for each reservation event. %s = reservation code, then date and time are added by the caller. */
function cn_reservation_texts(): array {
    return [
        'booked'    =>['Reservation received','We received your reservation request %s. We will confirm it shortly.'],
        'confirmed' =>['Reservation confirmed','Your reservation %s is confirmed. We look forward to seeing you!'],
        'rejected'  =>['Reservation not accepted','Sorry, we could not accept your reservation %s.'],
        'cancelled' =>['Reservation cancelled','Your reservation %s was cancelled.'],
        'checked_in'=>['Welcome! You are checked in','You are checked in for reservation %s. Enjoy your visit!'],
        'completed' =>['Thank you for visiting','Your reservation %s is completed. We hope to see you again soon.'],
        'no_show'   =>['Reservation marked as missed','Your reservation %s was marked as a no-show because we did not see you.'],
    ];
}
/** One insert, duplicates ignored by the database (unique keys). Returns true if a NEW row was created. */
function cn_insert(int $customerId,string $type,string $title,string $message,?int $orderId,?int $reservationId,?string $reason=null): bool {
    try{
        $st=db()->prepare('INSERT IGNORE INTO customer_notifications(customer_id,type,title,message,order_id,reservation_id,reason) VALUES(?,?,?,?,?,?,?)');
        $st->execute([$customerId,mb_substr($type,0,40),mb_substr($title,0,150),mb_substr($message,0,600),$orderId,$reservationId,$reason]);
        return $st->rowCount()>0;
    }catch(Throwable $e){ error_log('cn_insert: '.$e->getMessage()); return false; }
}
/** Call AFTER an order status change has been committed. Only the new status matters, so editing notes etc. never reaches here. */
function cn_order_event(int $orderId,string $newStatus): void {
    try{
        $t=cn_order_texts()[$newStatus]??null; if(!$t) return;
        $s=db()->prepare('SELECT id,order_no,customer_id,status FROM orders WHERE id=?'); $s->execute([$orderId]); $o=$s->fetch();
        if(!$o||empty($o['customer_id'])) return;                   // guest or kiosk order: nobody to notify
        if($o['status']!==$newStatus) return;                       // status moved on again; do not announce a stale one
        cn_insert((int)$o['customer_id'],'order_'.$newStatus,$t[0],sprintf($t[1],$o['order_no']),(int)$o['id'],null);
    }catch(Throwable $e){ error_log('cn_order_event: '.$e->getMessage()); }
}
/** Call AFTER a reservation status change (or a new booking) has been committed. Uses the customer linked to the reservation. */
function cn_reservation_event(int $reservationId,string $event): void {
    try{
        $t=cn_reservation_texts()[$event]??null; if(!$t) return;
        $s=db()->prepare('SELECT * FROM table_reservations WHERE id=?'); $s->execute([$reservationId]); $r=$s->fetch();
        if(!$r||empty($r['customer_id'])) return;                   // guest booking: no account to notify
        $msg=sprintf($t[1],$r['code']).' ('.date('d M Y',strtotime($r['res_date'])).' at '.date('g:i A',strtotime($r['start_time'])).', '.(int)$r['guests'].' guests)';
        $reason=null;
        if($event==='cancelled'){
            $reason=$r['cancel_reason']?:null;
            $label=defined('RES_CANCEL_REASONS')?(RES_CANCEL_REASONS[$r['cancel_reason']??'']??''):'';
            if($label!=='') $msg.=' Reason: '.$label.'.';
            if(trim((string)$r['cancel_note'])!=='') $msg.=' '.trim($r['cancel_note']);
        }
        cn_insert((int)$r['customer_id'],'reservation_'.$event,$t[0],$msg,null,(int)$r['id'],$reason);
    }catch(Throwable $e){ error_log('cn_reservation_event: '.$e->getMessage()); }
}
/** Where "View details" goes. Built from stored ids, never from user text. */
function cn_link(array $n): string {
    if(!empty($n['order_id'])) return 'my-account.php?section=orders&view='.(int)$n['order_id'];
    if(!empty($n['reservation_id'])) return 'my-account.php?section=reservations&view='.(int)$n['reservation_id'];
    return 'my-account.php?section=notifications';
}
