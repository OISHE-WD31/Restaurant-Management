<?php
// Email (SMTP) and SMS (BulkSMSBD) senders. Both return ['ok'=>bool,'error'=>string]. A channel that is not configured fails honestly; nothing pretends to send.
function mail_cfg(): array {
    static $c=null;
    if($c===null){ $c=['app_url'=>'http://localhost/restaurant','smtp'=>['host'=>'','port'=>587,'secure'=>'tls','username'=>'','password'=>'','from_email'=>'','from_name'=>'','verify_peer'=>true],'sms'=>['provider'=>'bulksmsbd','api_key'=>'','sender_id'=>'']];
        $f=__DIR__.'/../config/notifications.local.php';
        if(is_file($f)){ $l=(array)require $f; foreach(['smtp','sms'] as $k) if(isset($l[$k])) $c[$k]=array_merge($c[$k],(array)$l[$k]); if(!empty($l['app_url'])) $c['app_url']=(string)$l['app_url']; } }
    return $c;
}
function mail_ready(): bool { $s=mail_cfg()['smtp']; return $s['host']!=='' && $s['from_email']!=='' && filter_var($s['from_email'],FILTER_VALIDATE_EMAIL) && ($s['username']==='' || $s['password']!==''); }
function sms_ready(): bool { $s=mail_cfg()['sms']; return $s['provider']==='bulksmsbd' && $s['api_key']!=='' && $s['sender_id']!=='' && function_exists('curl_init'); }
function bd_phone(string $raw): ?string { $d=preg_replace('/\D/','',$raw); if(preg_match('/^8801[3-9]\d{8}$/',$d)) return $d; if(preg_match('/^01[3-9]\d{8}$/',$d)) return '88'.$d; return null; }
function mime_clean(string $s): string { return trim(preg_replace('/[\r\n]+/',' ',$s)); }
function mime_word(string $s): string { return '=?UTF-8?B?'.base64_encode(mime_clean($s)).'?='; }
function smtp_read($fp): array { $t=''; $code=0; while(($l=fgets($fp,515))!==false){ $t.=$l; if(strlen($l)<4||$l[3]===' '){ $code=(int)substr($l,0,3); break; } } return [$code,trim($t)]; }
function smtp_cmd($fp,string $cmd,array $ok): void {
    if($cmd!=='') fwrite($fp,$cmd."\r\n"); [$c,$t]=smtp_read($fp);
    if(!in_array($c,$ok,true)) throw new RuntimeException($c===0?'The mail server did not respond in time.':'Mail server said '.$c.': '.mb_substr($t,0,160));
}
function smtp_send(string $to,string $subject,string $text,string $html,?array $logo=null): array {
    $c=mail_cfg()['smtp']; $fp=null;
    try{
        if(!filter_var($to,FILTER_VALIDATE_EMAIL)) throw new RuntimeException('The customer email address is not valid.');
        $ctx=stream_context_create(['ssl'=>['verify_peer'=>(bool)$c['verify_peer'],'verify_peer_name'=>(bool)$c['verify_peer']]]);
        $fp=@stream_socket_client(($c['secure']==='ssl'?'ssl://':'tcp://').$c['host'].':'.(int)$c['port'],$en,$es,15,STREAM_CLIENT_CONNECT,$ctx);
        if(!$fp) throw new RuntimeException('Could not connect to the mail server: '.mb_substr((string)$es,0,120));
        stream_set_timeout($fp,20); $me=$_SERVER['SERVER_NAME']??'localhost';
        smtp_cmd($fp,'',[220]); smtp_cmd($fp,'EHLO '.$me,[250]);
        if($c['secure']==='tls'){ smtp_cmd($fp,'STARTTLS',[220]); if(!@stream_socket_enable_crypto($fp,true,STREAM_CRYPTO_METHOD_TLS_CLIENT)) throw new RuntimeException('Secure (TLS) connection to the mail server failed.'); smtp_cmd($fp,'EHLO '.$me,[250]); }
        if($c['username']!==''){ smtp_cmd($fp,'AUTH LOGIN',[334]); smtp_cmd($fp,base64_encode($c['username']),[334]); smtp_cmd($fp,base64_encode($c['password']),[235]); }
        $from=mime_clean($c['from_email']); smtp_cmd($fp,'MAIL FROM:<'.$from.'>',[250]); smtp_cmd($fp,'RCPT TO:<'.$to.'>',[250,251]); smtp_cmd($fp,'DATA',[354]);
        $name=mime_clean($c['from_name']!==''?$c['from_name']:setting('restaurant_name','Restaurant')); $b1='=_alt_'.bin2hex(random_bytes(8)); $b2='=_rel_'.bin2hex(random_bytes(8));
        $part=fn($type,$body)=>"Content-Type: $type; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n".chunk_split(base64_encode($body),76,"\r\n");
        $alt="--$b1\r\n".$part('text/plain',$text)."--$b1\r\n".$part('text/html',$html)."--$b1--\r\n";
        if($logo){ $ct="multipart/related; boundary=\"$b2\""; $body="--$b2\r\nContent-Type: multipart/alternative; boundary=\"$b1\"\r\n\r\n$alt--$b2\r\nContent-Type: {$logo['mime']}; name=\"logo.{$logo['ext']}\"\r\nContent-Transfer-Encoding: base64\r\nContent-ID: <logo@restaurant>\r\nContent-Disposition: inline; filename=\"logo.{$logo['ext']}\"\r\n\r\n".chunk_split(base64_encode($logo['data']),76,"\r\n")."--$b2--\r\n"; }
        else{ $ct="multipart/alternative; boundary=\"$b1\""; $body=$alt; }
        $msg="Date: ".date('r')."\r\nFrom: ".mime_word($name)." <$from>\r\nTo: <$to>\r\nSubject: ".mime_word($subject)."\r\nMessage-ID: <".bin2hex(random_bytes(12))."@".preg_replace('/[^a-z0-9.\-]/i','',$me).">\r\nMIME-Version: 1.0\r\nContent-Type: $ct\r\n\r\n".$body;
        $msg=preg_replace('/^\./m','..',$msg);
        fwrite($fp,$msg."\r\n.\r\n"); smtp_cmd($fp,'',[250]); @fwrite($fp,"QUIT\r\n"); fclose($fp);
        return ['ok'=>true,'error'=>''];
    }catch(Throwable $e){ if(is_resource($fp)) @fclose($fp); return ['ok'=>false,'error'=>mb_substr($e->getMessage(),0,240)]; }
}
const SMS_ERRORS=[1001=>'The phone number is invalid.',1002=>'The SMS Sender ID is incorrect or disabled.',1003=>'The SMS gateway reported missing fields.',1005=>'The SMS gateway had an internal error.',1007=>'SMS balance is too low.',1011=>'The SMS account was not found (check the API key).',1032=>'This server\'s IP address is not whitelisted at the SMS gateway.'];
function sms_send(string $phone,string $message): array {
    $c=mail_cfg()['sms']; $n=bd_phone($phone);
    if(!$n) return ['ok'=>false,'error'=>'The phone number is not a valid Bangladesh mobile number.'];
    if($c['provider']!=='bulksmsbd') return ['ok'=>false,'error'=>'Unsupported SMS provider.'];
    // The URL contains the API key, so it is never logged or shown in errors.
    $ch=curl_init('https://bulksmsbd.net/api/smsapi?'.http_build_query(['api_key'=>$c['api_key'],'type'=>'text','number'=>$n,'senderid'=>$c['sender_id'],'message'=>$message]));
    curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_TIMEOUT=>20,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2]);
    $r=curl_exec($ch); $http=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE); curl_close($ch);
    if($r===false) return ['ok'=>false,'error'=>'The SMS gateway could not be reached.'];
    $j=json_decode($r,true); $code=is_array($j)?(int)($j['response_code']??0):(is_numeric(trim($r))?(int)trim($r):0);
    if($code===202) return ['ok'=>true,'error'=>''];
    return ['ok'=>false,'error'=>SMS_ERRORS[$code]??('SMS gateway error'.($code?' '.$code:' (HTTP '.$http.')').'.')];
}
