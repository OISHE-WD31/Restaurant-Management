<?php
// Helpers for the customer account area (my-account.php and account-action.php).
// Rule used everywhere here: the customer id ALWAYS comes from the login session, never from the browser,
// and every lookup of a customer record also checks "AND customer_id = ?" so nobody can open someone else's data.

const ACCT_SECTIONS=['overview'=>['Dashboard','fa-gauge'],'profile'=>['My Profile','fa-user'],'addresses'=>['My Address','fa-location-dot'],'orders'=>['My Orders','fa-bag-shopping'],
    'reservations'=>['My Reservations','fa-calendar-check'],'rewards'=>['My Rewards','fa-gift'],'notifications'=>['Notifications','fa-bell']];
const ORDER_LABELS=['pending'=>'Pending','confirmed'=>'Confirmed','preparing'=>'Preparing','ready'=>'Ready','out_for_delivery'=>'Out for delivery','delivered'=>'Delivered','cancelled'=>'Cancelled'];
const RES_LABELS=['pending'=>'Pending','confirmed'=>'Confirmed','checked_in'=>'Checked in','completed'=>'Completed','cancelled'=>'Cancelled','rejected'=>'Not accepted','no_show'=>'No-show'];

/** Logged-in customer row, or null. If the account was deleted or disabled, the customer is logged out. */
function acct_customer(): ?array {
    if(empty($_SESSION['customer_id'])) return null;
    static $c=false; if($c!==false) return $c;
    $s=db()->prepare('SELECT id,name,email,phone,gender,is_active,created_at FROM customers WHERE id=?'); $s->execute([(int)$_SESSION['customer_id']]); $r=$s->fetch();
    if(!$r||!(int)$r['is_active']){ unset($_SESSION['customer_id'],$_SESSION['customer_name']); return $c=null; }
    return $c=$r;
}
/** Page guard: redirect to the existing login page when logged out. */
function acct_require(string $next='my-account.php'): array {
    $c=acct_customer(); if(!$c){ header('Location: login.php?next='.urlencode($next)); exit; } return $c;
}
function acct_flash(?string $msg=null,string $kind='ok'): ?array {
    if($msg!==null){ $_SESSION['acct_flash']=['msg'=>$msg,'kind'=>$kind]; return null; }
    $f=$_SESSION['acct_flash']??null; unset($_SESSION['acct_flash']); return $f;
}
function acct_url(string $section,array $q=[]): string { return 'my-account.php?'.http_build_query(['section'=>$section]+$q); }
function acct_unread(int $cid): int { $s=db()->prepare('SELECT COUNT(*) FROM customer_notifications WHERE customer_id=? AND is_read=0'); $s->execute([$cid]); return (int)$s->fetchColumn(); }
function acct_page(int $total,int $per): array {
    $pages=max(1,(int)ceil($total/$per)); $p=min($pages,max(1,(int)($_GET['page']??1))); return ['page'=>$p,'pages'=>$pages,'offset'=>($p-1)*$per,'per'=>$per];
}
function acct_pager(array $pg,string $section,array $q=[]): void {
    if($pg['pages']<2) return; ?>
    <nav class="pager" aria-label="Pages"><?php if($pg['page']>1): ?><a href="<?= e(acct_url($section,$q+['page'=>$pg['page']-1])) ?>">&laquo; Prev</a><?php endif; ?>
    <span>Page <?= $pg['page'] ?> of <?= $pg['pages'] ?></span>
    <?php if($pg['page']<$pg['pages']): ?><a href="<?= e(acct_url($section,$q+['page'=>$pg['page']+1])) ?>">Next &raquo;</a><?php endif; ?></nav>
<?php }
/** Attach the order lines to a list of orders with ONE query (no N+1). Only called with orders already filtered by customer. */
function acct_order_items(array $orderIds): array {
    if(!$orderIds) return [];
    $in=implode(',',array_fill(0,count($orderIds),'?'));
    $s=db()->prepare("SELECT order_id,name,variation,unit_price,quantity FROM order_items WHERE order_id IN ($in) ORDER BY id"); $s->execute(array_values($orderIds));
    $out=[]; foreach($s->fetchAll() as $r) $out[$r['order_id']][]=$r; return $out;
}
function acct_pay_label(array $o): string { return $o['payment_method']==='cod'?'Cash on Delivery':'Online payment'; }
function acct_status_badge(string $label,string $status): string { return '<span class="badge s-'.e($status).'">'.e($label).'</span>'; }
/** Address validation shared by add and edit. Returns [cleanValues, errors]. */
function acct_address_clean(array $in): array {
    $v=['address_type'=>(string)($in['address_type']??'home'),'full_address'=>trim((string)($in['full_address']??'')),'city'=>trim((string)($in['city']??'')),
        'area'=>trim((string)($in['area']??'')),'postal_code'=>trim((string)($in['postal_code']??'')),'instructions'=>trim((string)($in['instructions']??''))];
    $err=[];
    if(!in_array($v['address_type'],['home','work','other'],true)) $err[]='Choose Home, Work or Other.';
    if(mb_strlen($v['full_address'])<8||mb_strlen($v['full_address'])>255) $err[]='Full address must be 8 to 255 characters.';
    if(mb_strlen($v['city'])<2||mb_strlen($v['city'])>80) $err[]='Enter the city (2 to 80 characters).';
    if(mb_strlen($v['area'])>80) $err[]='Area can be at most 80 characters.';
    if($v['postal_code']!==''&&!preg_match('/^[A-Za-z0-9\- ]{3,20}$/',$v['postal_code'])) $err[]='Postal code can only have letters, numbers, spaces and dashes (3 to 20 characters).';
    if(mb_strlen($v['instructions'])>255) $err[]='Delivery instructions can be at most 255 characters.';
    return [$v,$err];
}
