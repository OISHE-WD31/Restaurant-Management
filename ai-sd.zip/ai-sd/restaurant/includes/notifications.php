<?php
// Notification helpers. Included by includes/functions.php. Never throws, so it cannot break orders or forms.
function notify(string $type,string $title,string $message,int $relatedId,string $link=''): void {
    try{
        db()->prepare('INSERT IGNORE INTO admin_notifications(type,title,message,related_id,link) VALUES(?,?,?,?,?)')
            ->execute([$type,mb_substr($title,0,150),mb_substr($message,0,500),$relatedId,$link]);
    }catch(Throwable $e){ error_log('notify: '.$e->getMessage()); }
}
function notif_safe_link(string $l): string { return preg_match('/^[a-z\-]+\.php(\?[\w=%&\-]*)?$/i',$l)?$l:''; }
function notif_list(int $aid,int $limit=15): array {
    $st=db()->prepare('SELECT n.id,n.type,n.title,n.message,n.link,n.created_at,COALESCE(s.is_read,0) is_read FROM admin_notifications n
        LEFT JOIN admin_notification_state s ON s.notification_id=n.id AND s.admin_id=? WHERE COALESCE(s.is_deleted,0)=0 ORDER BY n.id DESC LIMIT '.(int)$limit);
    $st->execute([$aid]); return $st->fetchAll();
}
function notif_unread(int $aid): int {
    $st=db()->prepare('SELECT COUNT(*) FROM admin_notifications n LEFT JOIN admin_notification_state s ON s.notification_id=n.id AND s.admin_id=?
        WHERE COALESCE(s.is_deleted,0)=0 AND COALESCE(s.is_read,0)=0'); $st->execute([$aid]); return (int)$st->fetchColumn();
}
function notif_action(int $aid,string $act,int $id=0): bool {
    try{
        $pdo=db();
        if($act==='read_all'){ $pdo->prepare('INSERT INTO admin_notification_state(admin_id,notification_id,is_read,is_deleted) SELECT ?,id,1,0 FROM admin_notifications ON DUPLICATE KEY UPDATE is_read=1')->execute([$aid]); return true; }
        if($id<=0) return false;
        if($act==='read') $pdo->prepare('INSERT INTO admin_notification_state(admin_id,notification_id,is_read,is_deleted) VALUES(?,?,1,0) ON DUPLICATE KEY UPDATE is_read=1')->execute([$aid,$id]);
        elseif($act==='delete') $pdo->prepare('INSERT INTO admin_notification_state(admin_id,notification_id,is_read,is_deleted) VALUES(?,?,1,1) ON DUPLICATE KEY UPDATE is_read=1,is_deleted=1')->execute([$aid,$id]);
        else return false;
        return true;
    }catch(Throwable $e){ return false; }
}
function notif_payload(int $aid): array {
    $items=array_map(fn($r)=>['id'=>(int)$r['id'],'type'=>$r['type'],'title'=>$r['title'],'message'=>$r['message'],'link'=>notif_safe_link($r['link']),
        'is_read'=>(int)$r['is_read'],'ts'=>strtotime($r['created_at']),'at'=>date('d M, H:i',strtotime($r['created_at']))],notif_list($aid,15));
    $latest=(int)db()->query('SELECT COALESCE(MAX(id),0) FROM admin_notifications')->fetchColumn();
    return ['ok'=>true,'unread'=>notif_unread($aid),'latest_id'=>$latest,'items'=>$items];
}
