<?php
class StockShortage extends RuntimeException {}
const UNIT_BASE=['kg'=>['m',1000],'g'=>['m',1],'l'=>['v',1000],'ml'=>['v',1],'piece'=>['p',1],'packet'=>['k',1]];
function unit_convert(float $q,string $from,string $to): ?float {
    if(!isset(UNIT_BASE[$from],UNIT_BASE[$to])||UNIT_BASE[$from][0]!==UNIT_BASE[$to][0]) return null;
    return $q*UNIT_BASE[$from][1]/UNIT_BASE[$to][1];
}
function fmt_qty($n): string { return rtrim(rtrim(number_format((float)$n,3,'.',''),'0'),'.')?:'0'; }
/** The ONLY place stock changes. Locks the row, blocks negative stock, writes history, raises low-stock alerts. */
function stock_apply(PDO $pdo,int $ing,float $delta,string $type,?int $orderId=null,string $note='',int $adminId=0,?float $cost=null): float {
    $s=$pdo->prepare('SELECT * FROM ingredients WHERE id=? FOR UPDATE'); $s->execute([$ing]); $i=$s->fetch();
    if(!$i) throw new RuntimeException('Ingredient not found.');
    $old=(float)$i['stock']; $new=round($old+$delta,3);
    if($new<0) throw new StockShortage($i['name'].' would go below zero (only '.fmt_qty($old).' '.$i['unit'].' in stock).');
    $pdo->prepare('UPDATE ingredients SET stock=? WHERE id=?')->execute([$new,$ing]);
    $pdo->prepare('INSERT INTO inventory_movements(ingredient_id,type,quantity,balance_after,order_id,note,unit_cost,created_by) VALUES(?,?,?,?,?,?,?,?)')
        ->execute([$ing,$type,$delta,$new,$orderId,mb_substr($note,0,255),$cost,$adminId?:null]);
    $mid=(int)$pdo->lastInsertId(); $min=(float)$i['min_stock'];
    if($delta<0 && (($old>$min && $new<=$min)||($old>0 && $new<=0)))
        notify('stock',$new<=0?'Out of stock: '.$i['name']:'Low stock: '.$i['name'],$i['name'].': '.fmt_qty($new).' '.$i['unit'].' left (minimum '.fmt_qty($min).')',$mid,'inventory.php');
    return $new;
}
function stock_requirements(PDO $pdo,int $orderId): array {
    $s=$pdo->prepare('SELECT oi.quantity oq,ri.ingredient_id,ri.quantity rq,ri.unit ru,i.unit iu FROM order_items oi JOIN recipe_ingredients ri ON ri.product_id=oi.product_id JOIN ingredients i ON i.id=ri.ingredient_id WHERE oi.order_id=?');
    $s->execute([$orderId]); $need=[];
    foreach($s->fetchAll() as $r){ $q=unit_convert((float)$r['rq'],$r['ru'],$r['iu']); if($q===null) continue; $need[$r['ingredient_id']]=($need[$r['ingredient_id']]??0)+$q*(int)$r['oq']; }
    ksort($need); return $need;
}
function stock_eligible(array $o): bool { return $o['payment_method']==='cod' || $o['payment_status']==='paid'; }
function stock_deduct(PDO $pdo,array $o): void {
    $need=stock_requirements($pdo,(int)$o['id']);
    if($need){
        $ids=array_keys($need); $in=implode(',',array_fill(0,count($ids),'?'));
        $s=$pdo->prepare("SELECT id,name,unit,stock FROM ingredients WHERE id IN ($in) ORDER BY id FOR UPDATE"); $s->execute($ids); $short=[];
        foreach($s->fetchAll() as $i) if((float)$i['stock']+1e-9<$need[$i['id']]) $short[]=$i['name'].' (needs '.fmt_qty($need[$i['id']]).' '.$i['unit'].', have '.fmt_qty($i['stock']).')';
        if($short) throw new StockShortage('Not enough stock: '.implode('; ',$short).'. Add stock or adjust the recipe first.');
        foreach($need as $id=>$q) stock_apply($pdo,(int)$id,-round($q,3),'order_deduction',(int)$o['id'],'Order '.$o['order_no']);
    }
    $pdo->prepare('UPDATE orders SET stock_deducted=1 WHERE id=?')->execute([$o['id']]);
}
function stock_restore(PDO $pdo,array $o): void {
    $s=$pdo->prepare("SELECT ingredient_id,quantity FROM inventory_movements WHERE order_id=? AND type='order_deduction' ORDER BY ingredient_id"); $s->execute([$o['id']]);
    foreach($s->fetchAll() as $m) stock_apply($pdo,(int)$m['ingredient_id'],abs((float)$m['quantity']),'order_restore',(int)$o['id'],'Order '.$o['order_no'].' cancelled');
    $pdo->prepare('UPDATE orders SET stock_deducted=0 WHERE id=?')->execute([$o['id']]);
}
/** Called by order_transition() inside its transaction. Stock moves once per order, never on plain status changes. */
function order_after_transition(PDO $pdo,array $o,string $old,string $new,int $adminId): void {
    if(function_exists('loyalty_on_transition')) loyalty_on_transition($pdo,$o,$new);
    if($new==='cancelled'){ if($o['stock_deducted']) stock_restore($pdo,$o); return; }
    if(in_array($new,['confirmed','preparing','ready','out_for_delivery','delivered'],true) && !$o['stock_deducted'] && stock_eligible($o)) stock_deduct($pdo,$o);
}
/** Online orders confirmed before payment arrived: deduct once the payment is verified. */
function stock_after_payment(int $orderId): void {
    $pdo=db(); $o=null;
    try{
        $pdo->beginTransaction(); $s=$pdo->prepare('SELECT * FROM orders WHERE id=? FOR UPDATE'); $s->execute([$orderId]); $o=$s->fetch();
        if($o && !$o['stock_deducted'] && $o['payment_status']==='paid' && in_array($o['status'],['confirmed','preparing','ready','out_for_delivery','delivered'],true)) stock_deduct($pdo,$o);
        $pdo->commit();
    }catch(Throwable $e){ if($pdo->inTransaction()) $pdo->rollBack(); if($o) notify('stock_order','Stock not deducted for '.$o['order_no'],$e->getMessage(),$orderId,'orders.php?q='.$o['order_no']); }
}
