<?php
/** Phase 4: sales and payment analytics.
 *  The SQL here is deliberately plain (simple SELECTs by date range). Grouping and all money rules live in PHP,
 *  so the meaning of "sale", "gross" and "net" is defined in exactly one place.
 *
 *  A SALE is an order that is delivered AND whose payment is verified (payment_status 'paid', or 'refunded' after a refund).
 *  Gross sales      = sum of item subtotals of sales (before discounts)
 *  Discounts        = coupon discounts on those sales
 *  Delivery charges = delivery fees on those sales
 *  Order total      = gross - discounts + delivery
 *  Refunds          = refunds recorded against those sales
 *  Net revenue      = order total - refunds
 *  Cancelled, unpaid, failed and pending orders are never sales. Dates are the order's created date.
 */
function an_today(PDO $pdo): string { try{ return (string)$pdo->query('SELECT CURDATE()')->fetchColumn(); }catch(Throwable $e){ return date('Y-m-d'); } }
function an_date(?string $d): ?string { if(!$d) return null; $x=DateTime::createFromFormat('!Y-m-d',$d); return ($x&&$x->format('Y-m-d')===$d)?$d:null; }
function an_add_days(string $d,int $n): string { return (new DateTime($d))->modify(($n>=0?'+':'').$n.' day')->format('Y-m-d'); }
function an_monday(string $d): string { $x=new DateTime($d); return $x->modify('-'.((int)$x->format('N')-1).' day')->format('Y-m-d'); }
function an_bounds(string $from,string $to): array { return [$from.' 00:00:00',an_add_days($to,1).' 00:00:00']; }

/** Reads ?range=today|7d|30d|month|12m|all or ?from=&to=. Defaults to the last 30 days. */
function an_range(PDO $pdo,array $q): array {
    $today=an_today($pdo); $preset=(string)($q['range']??''); $from=an_date($q['from']??null); $to=an_date($q['to']??null);
    if($preset==='today'){ $from=$to=$today; }
    elseif($preset==='7d'){ $to=$today; $from=an_add_days($today,-6); }
    elseif($preset==='30d'){ $to=$today; $from=an_add_days($today,-29); }
    elseif($preset==='month'){ $to=$today; $from=substr($today,0,8).'01'; }
    elseif($preset==='12m'){ $to=$today; $from=(new DateTime($today))->modify('first day of this month')->modify('-11 month')->format('Y-m-d'); }
    elseif($preset==='all'){ $to=$today; $m=$pdo->query('SELECT MIN(created_at) FROM orders')->fetchColumn(); $from=$m?substr((string)$m,0,10):$today; }
    else $preset='';
    if(!$from||!$to){ $to=$today; $from=an_add_days($today,-29); $preset='30d'; }
    if($from>$to) [$from,$to]=[$to,$from];
    if((new DateTime($from))->diff(new DateTime($to))->days>731) $from=an_add_days($to,-731);
    return ['from'=>$from,'to'=>$to,'preset'=>$preset,'today'=>$today];
}
function an_orders(PDO $pdo,string $from,string $to): array {
    [$a,$b]=an_bounds($from,$to);
    $s=$pdo->prepare('SELECT o.id,o.order_no,o.subtotal,o.delivery_charge,o.discount,o.total,o.payment_method,o.payment_status,o.status,o.created_at,o.delivered_at,
        (SELECT COUNT(*) FROM payments pv WHERE pv.order_id=o.id AND pv.status IN (\'validated\',\'refunded\') AND pv.val_id<>\'\' AND ABS(pv.amount-o.total)<0.01) verified
        FROM orders o WHERE o.created_at>=? AND o.created_at<? ORDER BY o.id');
    $s->execute([$a,$b]); return $s->fetchAll();
}
/** order_id => total refunded, for orders created in the range. */
function an_refunds(PDO $pdo,string $from,string $to): array {
    [$a,$b]=an_bounds($from,$to);
    $s=$pdo->prepare('SELECT r.order_id,SUM(r.amount) amt FROM order_refunds r JOIN orders o ON o.id=r.order_id WHERE o.created_at>=? AND o.created_at<? GROUP BY r.order_id');
    $s->execute([$a,$b]); $m=[]; foreach($s->fetchAll() as $r) $m[(int)$r['order_id']]=(float)$r['amt']; return $m;
}
/** Online orders count only with a matching verified gateway payment (verified > 0). COD orders count once delivered and marked paid. */
function an_is_sale(array $o): bool { return $o['status']==='delivered' && in_array($o['payment_status'],['paid','refunded'],true) && ($o['payment_method']==='cod' || (int)($o['verified']??0)>0); }

function an_summary(array $orders,array $refunds): array {
    $s=['orders'=>count($orders),'completed'=>0,'refunded_orders'=>0,'cancelled'=>0,'open'=>0,'gross'=>0.0,'discounts'=>0.0,'delivery'=>0.0,'order_total'=>0.0,'refunds'=>0.0,'net'=>0.0,'aov'=>0.0];
    foreach($orders as $o){
        if($o['status']==='cancelled'){ $s['cancelled']++; continue; }
        if(!an_is_sale($o)){ if($o['status']!=='delivered') $s['open']++; continue; }
        if($o['payment_status']==='paid') $s['completed']++; else $s['refunded_orders']++;
        $s['gross']+=(float)$o['subtotal']; $s['discounts']+=(float)$o['discount']; $s['delivery']+=(float)$o['delivery_charge']; $s['order_total']+=(float)$o['total'];
        $s['refunds']+=$refunds[(int)$o['id']]??0.0;
    }
    foreach(['gross','discounts','delivery','order_total','refunds'] as $k) $s[$k]=round($s[$k],2);
    $s['net']=round($s['order_total']-$s['refunds'],2);
    $s['aov']=$s['completed']>0?round($s['net']/$s['completed'],2):0.0;
    return $s;
}
/** Net revenue by day, ISO week (starting Monday) and month, with empty periods filled in with zero. */
function an_series(array $orders,array $refunds,string $from,string $to): array {
    $d=[]; for($x=$from;$x<=$to;$x=an_add_days($x,1)) $d[$x]=['net'=>0.0,'orders'=>0];
    $w=[]; for($x=an_monday($from);$x<=$to;$x=an_add_days($x,7)) $w[$x]=['net'=>0.0,'orders'=>0];
    $m=[]; for($x=substr($from,0,7).'-01';$x<=$to;$x=(new DateTime($x))->modify('+1 month')->format('Y-m-d')) $m[substr($x,0,7)]=['net'=>0.0,'orders'=>0];
    foreach($orders as $o){ if(!an_is_sale($o)) continue;
        $net=(float)$o['total']-($refunds[(int)$o['id']]??0.0); $day=substr($o['created_at'],0,10); $wk=an_monday($day); $mo=substr($day,0,7);
        if(isset($d[$day])){ $d[$day]['net']+=$net; $d[$day]['orders']++; }
        if(isset($w[$wk])){ $w[$wk]['net']+=$net; $w[$wk]['orders']++; }
        if(isset($m[$mo])){ $m[$mo]['net']+=$net; $m[$mo]['orders']++; }
    }
    foreach($d as &$v) $v['net']=round($v['net'],2); unset($v);
    foreach($w as &$v) $v['net']=round($v['net'],2); unset($v);
    foreach($m as &$v) $v['net']=round($v['net'],2); unset($v);
    return ['daily'=>$d,'weekly'=>$w,'monthly'=>$m];
}
function an_demand_level(int $n,int $max): string { if($n<=0||$max<=0) return 'none'; if($n>=0.7*$max) return 'high'; if($n<=0.3*$max) return 'low'; return 'normal'; }
/** Demand = every order placed (not cancelled), by hour of day and day of week. */
function an_peak(array $orders): array {
    $h=array_fill(0,24,0); $d=array_fill(1,7,0);
    foreach($orders as $o){ if($o['status']==='cancelled') continue; $h[(int)substr($o['created_at'],11,2)]++; $d[(int)(new DateTime(substr($o['created_at'],0,10)))->format('N')]++; }
    $mh=max($h); $md=max($d); $hl=[]; foreach($h as $k=>$n) $hl[$k]=an_demand_level($n,$mh); $dl=[]; foreach($d as $k=>$n) $dl[$k]=an_demand_level($n,$md);
    $ah=$h; arsort($ah); $ad=$d; arsort($ad);
    return ['hours'=>$h,'days'=>$d,'hour_level'=>$hl,'day_level'=>$dl,'top_hours'=>array_keys(array_filter($ah)),'top_days'=>array_keys(array_filter($ad)),'total'=>array_sum($h)];
}
/** Best sellers and category sales from completed, paid sales in the range. Values are item prices before discounts and refunds. */
function an_best(PDO $pdo,string $from,string $to): array {
    [$a,$b]=an_bounds($from,$to);
    $s=$pdo->prepare("SELECT oi.order_id,oi.name item,oi.quantity,oi.unit_price,c.name cat FROM order_items oi JOIN orders o ON o.id=oi.order_id
        LEFT JOIN products p ON p.id=oi.product_id LEFT JOIN categories c ON c.id=p.category_id
        WHERE o.created_at>=? AND o.created_at<? AND ".rev_where('o'));
    $s->execute([$a,$b]); $prod=[]; $cat=[];
    foreach($s->fetchAll() as $r){ $v=(float)$r['unit_price']*(int)$r['quantity']; $n=$r['item']; $c=$r['cat']??'Uncategorised';
        $prod[$n]??=['name'=>$n,'qty'=>0,'revenue'=>0.0,'orders'=>[]]; $prod[$n]['qty']+=(int)$r['quantity']; $prod[$n]['revenue']+=$v; $prod[$n]['orders'][$r['order_id']]=1;
        $cat[$c]??=['name'=>$c,'qty'=>0,'revenue'=>0.0]; $cat[$c]['qty']+=(int)$r['quantity']; $cat[$c]['revenue']+=$v; }
    foreach($prod as &$p){ $p['orders']=count($p['orders']); $p['revenue']=round($p['revenue'],2); } unset($p);
    foreach($cat as &$p) $p['revenue']=round($p['revenue'],2); unset($p);
    usort($prod,fn($x,$y)=>[$y['qty'],$y['revenue']]<=>[$x['qty'],$x['revenue']]); usort($cat,fn($x,$y)=>$y['revenue']<=>$x['revenue']);
    return ['products'=>$prod,'categories'=>$cat];
}
/** Revenue overview cards: fixed windows (all time, today, this week, this month), independent of the page's date filter. */
function an_overview(PDO $pdo): array {
    $today=an_today($pdo); $orders=an_orders($pdo,'2000-01-01',$today); $ref=an_refunds($pdo,'2000-01-01',$today);
    $in=fn($from)=>array_values(array_filter($orders,fn($o)=>substr($o['created_at'],0,10)>=$from));
    $all=an_summary($orders,$ref);
    return ['all'=>$all,'today'=>an_summary($in($today),$ref)['net'],'week'=>an_summary($in(an_monday($today)),$ref)['net'],'month'=>an_summary($in(substr($today,0,8).'01'),$ref)['net']];
}

/* ---------- Payment reconciliation ---------- */
const PAY_STATES=['paid'=>'Paid','pending'=>'Pending','failed'=>'Failed','cancelled'=>'Cancelled','refunded'=>'Refunded','unverified'=>'Unverified'];
/** Decides one order's payment state from the order, its gateway payment attempts, and refunds. Never treats an unverified online payment as paid. */
function an_pay_classify(array $o,array $pays,float $refunded): array {
    $flags=[]; $notes=[]; $total=(float)$o['total']; $ps=$o['payment_status']; $online=$o['payment_method']==='online';
    $valid=null; foreach($pays as $p) if(in_array($p['status'],['validated','refunded'],true) && trim((string)($p['val_id']??''))!==''){ $valid=$p; break; }
    $shown=$valid??($pays?end($pays):null);
    if($ps==='refunded'||($refunded>0&&$refunded>=$total-0.005)) $state='refunded';
    elseif($ps==='paid'){
        if($online && !$valid){ $state='unverified'; $flags[]='Marked paid, but there is no verified gateway payment'; }
        elseif($online && abs((float)$valid['amount']-$total)>=0.01){ $state='unverified'; $flags[]='Gateway amount differs from the order total'; }
        else $state='paid';
        if($o['status']==='cancelled') $flags[]='Order cancelled but payment not refunded';
        if($refunded>0) $notes[]='Partially refunded';
    }
    elseif($ps==='failed') $state='failed';
    elseif($ps==='cancelled') $state='cancelled';
    else{ $state=$o['status']==='cancelled'?'cancelled':'pending'; if($online&&$valid) $flags[]='Gateway payment verified, but the order is not marked paid'; }
    if($online) $date=$shown['created_at']??$o['created_at']; else $date=$o['delivered_at']?:$o['created_at'];
    return ['order'=>$o,'payment'=>$shown,'state'=>$state,'flags'=>$flags,'notes'=>$notes,'refunded'=>$refunded,'attempts'=>count($pays),'date'=>$date];
}
/** One row per order in the range, with filters for method and state. Returns rows plus totals (always computed on the filtered rows). */
function an_payments(PDO $pdo,string $from,string $to,string $method='',string $state=''): array {
    [$a,$b]=an_bounds($from,$to); $orders=an_orders($pdo,$from,$to); $ref=an_refunds($pdo,$from,$to);
    $s=$pdo->prepare('SELECT p.id,p.order_id,p.transaction_id,p.val_id,p.amount,p.status,p.created_at FROM payments p JOIN orders o ON o.id=p.order_id WHERE o.created_at>=? AND o.created_at<? ORDER BY p.id');
    $s->execute([$a,$b]); $by=[]; foreach($s->fetchAll() as $p) $by[(int)$p['order_id']][]=$p;
    $rows=[]; $t=['count'=>0,'paid'=>0.0,'pending'=>0.0,'unverified'=>0.0,'refunded'=>0.0,'n'=>array_fill_keys(array_keys(PAY_STATES),0),'attention'=>0];
    foreach(array_reverse($orders) as $o){
        if($method!==''&&$o['payment_method']!==$method) continue;
        $r=an_pay_classify($o,$by[(int)$o['id']]??[],$ref[(int)$o['id']]??0.0);
        if($state!==''&&$r['state']!==$state) continue;
        $rows[]=$r; $t['count']++; $t['n'][$r['state']]++; $t['refunded']+=$r['refunded']; if($r['flags']) $t['attention']++;
        if($r['state']==='paid') $t['paid']+=(float)$o['total']; elseif($r['state']==='pending') $t['pending']+=(float)$o['total']; elseif($r['state']==='unverified') $t['unverified']+=(float)$o['total'];
    }
    foreach(['paid','pending','unverified','refunded'] as $k) $t[$k]=round($t[$k],2);
    $t['refunded']=round($t['refunded'],2);
    return ['rows'=>$rows,'totals'=>$t];
}
