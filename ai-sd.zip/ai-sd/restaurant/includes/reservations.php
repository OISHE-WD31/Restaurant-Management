<?php
const RES_ACTIVE="'pending','confirmed','checked_in'";
function res_cfg(): array {
    static $c=null; if($c!==null) return $c;
    $d=['open_time'=>'12:00','close_time'=>'22:00','slot_minutes'=>'30','duration_minutes'=>'90','peak_start'=>'19:00','peak_end'=>'21:00','peak_duration_minutes'=>'75','max_party_size'=>'12','advance_days'=>'30','max_seats_total'=>'0'];
    try{ $d=array_merge($d,db()->query('SELECT setting_key,setting_value FROM reservation_settings')->fetchAll(PDO::FETCH_KEY_PAIR)); }catch(Throwable $e){}
    return $c=$d;
}
function res_mins(string $t): int { $p=explode(':',substr($t,0,5)); return (int)$p[0]*60+(int)($p[1]??0); }
function res_hm(int $m): string { return sprintf('%02d:%02d',intdiv($m,60),$m%60); }
function res_end(string $start): string { $c=res_cfg(); $s=res_mins($start); $peak=$s>=res_mins($c['peak_start'])&&$s<res_mins($c['peak_end']); return res_hm($s+(int)($peak?$c['peak_duration_minutes']:$c['duration_minutes'])); }
function res_slots(): array { $c=res_cfg(); $o=[]; for($m=res_mins($c['open_time']);res_mins(res_end(res_hm($m)))<=res_mins($c['close_time']);$m+=max(5,(int)$c['slot_minutes'])) $o[]=res_hm($m); return $o; }
function res_check_when(string $date,string $start,int $guests): ?string {
    $c=res_cfg(); $d=DateTime::createFromFormat('!Y-m-d',$date);
    if(!$d||$d->format('Y-m-d')!==$date) return 'Choose a valid date.';
    if(!in_array($start,res_slots(),true)) return 'Choose one of the available time slots.';
    if($guests<1||$guests>(int)$c['max_party_size']) return 'Parties can be 1 to '.(int)$c['max_party_size'].' guests. For larger groups, please call us.';
    $today=new DateTime('today');
    if($d<$today) return 'That date has already passed.';
    if($d>(clone $today)->modify('+'.(int)$c['advance_days'].' days')) return 'We take reservations up to '.(int)$c['advance_days'].' days ahead.';
    if($date===date('Y-m-d') && res_mins($start)<=res_mins(date('H:i'))) return 'That time has already passed today.';
    return null;
}
/** Returns a free table id for the window, or null. Uses date, time, duration, capacity and existing bookings. */
function res_find_table(string $date,string $start,int $guests,int $prefer=0,int $exclude=0): ?int {
    $end=res_end($start); $pdo=db(); $cap=(int)res_cfg()['max_seats_total'];
    if($cap>0){ $s=$pdo->prepare('SELECT COALESCE(SUM(guests),0) FROM table_reservations WHERE res_date=? AND status IN ('.RES_ACTIVE.') AND start_time<? AND end_time>? AND id<>?'); $s->execute([$date,$end,$start,$exclude]); if($s->fetchColumn()+$guests>$cap) return null; }
    $st=$pdo->prepare('SELECT t.id FROM restaurant_tables t WHERE t.status<>"unavailable" AND t.capacity>=? AND NOT EXISTS
        (SELECT 1 FROM table_reservations r WHERE r.table_id=t.id AND r.res_date=? AND r.status IN ('.RES_ACTIVE.') AND r.start_time<? AND r.end_time>? AND r.id<>?)
        ORDER BY (t.id=?) DESC,t.capacity,t.id LIMIT 1');
    $st->execute([$guests,$date,$end,$start,$exclude,$prefer]); $id=$st->fetchColumn(); return $id?(int)$id:null;
}
function res_free_slots(string $date,int $guests): array { return array_values(array_filter(res_slots(),fn($s)=>res_check_when($date,$s,$guests)===null && res_find_table($date,$s,$guests)!==null)); }
function res_create(array $d): array {
    $pdo=db();
    try{
        $pdo->beginTransaction();
        $pdo->query('SELECT id FROM restaurant_tables FOR UPDATE')->fetchAll(); // serialises bookings: no double booking
        $tid=res_find_table($d['date'],$d['start'],$d['guests'],$d['prefer']);
        if(!$tid){ $pdo->rollBack(); return ['ok'=>false,'msg'=>'Sorry, no table is free for '.$d['guests'].' guest(s) at that time.']; }
        $code='RSV'.strtoupper(bin2hex(random_bytes(3)));
        $pdo->prepare('INSERT INTO table_reservations(code,customer_id,name,phone,email,res_date,start_time,end_time,guests,table_id,preferred_table_id,notes) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)')
            ->execute([$code,$d['customer_id'],$d['name'],$d['phone'],$d['email'],$d['date'],$d['start'],res_end($d['start']),$d['guests'],$tid,$d['prefer']?:null,$d['notes']]);
        $rid=(int)$pdo->lastInsertId(); $pdo->commit();
        notify('reservation','New reservation request',$d['name'].' · '.$d['date'].' '.$d['start'].' · '.$d['guests'].' guests',$rid,'reservations.php?date='.$d['date']);
        if(function_exists('cn_reservation_event')) cn_reservation_event($rid,'booked');
        return ['ok'=>true,'code'=>$code];
    }catch(Throwable $e){ if($pdo->inTransaction()) $pdo->rollBack(); error_log('res_create: '.$e->getMessage()); return ['ok'=>false,'msg'=>'Could not save your reservation. Please try again.']; }
}
/** Admin: move a reservation to a new date/time/guest count/table (0 = auto-pick). */
function res_move(int $id,string $date,string $start,int $guests,int $table): array {
    $pdo=db();
    try{
        $err=res_check_when($date,$start,$guests); if($err) return ['ok'=>false,'msg'=>$err];
        $pdo->beginTransaction(); $pdo->query('SELECT id FROM restaurant_tables FOR UPDATE')->fetchAll();
        $end=res_end($start);
        if($table){ $c=$pdo->prepare('SELECT capacity,status FROM restaurant_tables WHERE id=?'); $c->execute([$table]); $t=$c->fetch();
            $f=$pdo->prepare('SELECT COUNT(*) FROM table_reservations WHERE table_id=? AND res_date=? AND status IN ('.RES_ACTIVE.') AND start_time<? AND end_time>? AND id<>?'); $f->execute([$table,$date,$end,$start,$id]);
            if(!$t||$t['status']==='unavailable'||$t['capacity']<$guests||$f->fetchColumn()>0){ $pdo->rollBack(); return ['ok'=>false,'msg'=>'That table is not free or too small for this time.']; } }
        else{ $table=res_find_table($date,$start,$guests,0,$id); if(!$table){ $pdo->rollBack(); return ['ok'=>false,'msg'=>'No table is free at that time.']; } }
        $pdo->prepare('UPDATE table_reservations SET res_date=?,start_time=?,end_time=?,guests=?,table_id=? WHERE id=?')->execute([$date,$start,$end,$guests,$table,$id]);
        $pdo->commit(); return ['ok'=>true,'msg'=>'Reservation updated.'];
    }catch(Throwable $e){ if($pdo->inTransaction()) $pdo->rollBack(); error_log('res_move: '.$e->getMessage()); return ['ok'=>false,'msg'=>'Could not update the reservation.']; }
}
function res_dashboard_stats(): array {
    try{ $q=fn($s)=>db()->query($s)->fetchColumn();
        return ['Reservations today'=>$q("SELECT COUNT(*) FROM table_reservations WHERE res_date=CURDATE() AND status IN ('pending','confirmed','checked_in')"),'No-shows (30 days)'=>$q("SELECT COUNT(*) FROM table_reservations WHERE status='no_show' AND res_date>=CURDATE()-INTERVAL 30 DAY")];
    }catch(Throwable $e){ return []; }
}

/** Admin status buttons: action => [allowed current statuses, new status]. */
const RES_ACTIONS=['confirm'=>[['pending'],'confirmed'],'reject'=>[['pending'],'rejected'],'check_in'=>[['confirmed'],'checked_in'],'complete'=>[['checked_in'],'completed'],'no_show'=>[['confirmed'],'no_show']];
/** Same rules as before, now in one place. The customer is notified only after the change is committed. */
function res_transition(int $id,string $act): array {
    if(!isset(RES_ACTIONS[$act])) return ['ok'=>false,'msg'=>'Unknown action.'];
    $pdo=db(); [$from,$to]=RES_ACTIONS[$act];
    try{
        $pdo->beginTransaction(); $s=$pdo->prepare('SELECT * FROM table_reservations WHERE id=? FOR UPDATE'); $s->execute([$id]); $r=$s->fetch();
        if(!$r||!in_array($r['status'],$from,true)){ $pdo->rollBack(); return ['ok'=>false,'msg'=>'That action is not available for this reservation.']; }
        $pdo->prepare('UPDATE table_reservations SET status=? WHERE id=?')->execute([$to,$id]);
        if($r['table_id'] && $act==='check_in') $pdo->prepare("UPDATE restaurant_tables SET status='occupied' WHERE id=?")->execute([$r['table_id']]);
        if($r['table_id'] && $act==='complete') $pdo->prepare("UPDATE restaurant_tables SET status='cleaning' WHERE id=?")->execute([$r['table_id']]);
        $pdo->commit();
    }catch(Throwable $e){ if($pdo->inTransaction()) $pdo->rollBack(); error_log('res_transition: '.$e->getMessage()); return ['ok'=>false,'msg'=>'Could not update the reservation. Nothing was changed.']; }
    cn_reservation_event($id,$to);
    return ['ok'=>true,'msg'=>'Reservation updated.'];
}
