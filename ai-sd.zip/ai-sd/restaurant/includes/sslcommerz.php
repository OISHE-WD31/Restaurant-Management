<?php
require_once __DIR__.'/functions.php';
function pay_cfg(): array {
    static $c=null;
    if($c===null){ $c=['store_id'=>'','store_password'=>'','sandbox'=>true,'app_url'=>'http://localhost/restaurant'];
        $f=__DIR__.'/../config/payment.local.php'; if(is_file($f)) $c=array_merge($c,(array)require $f); }
    return $c;
}
function sslc_ready(): bool { $c=pay_cfg(); return $c['store_id']!=='' && $c['store_password']!=='' && function_exists('curl_init'); }
function sslc_host(): string { return pay_cfg()['sandbox']?'https://sandbox.sslcommerz.com':'https://securepay.sslcommerz.com'; }
function sslc_http(string $url,?array $post=null): ?array {
    $ch=curl_init($url); curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_TIMEOUT=>30,CURLOPT_SSL_VERIFYPEER=>true,CURLOPT_SSL_VERIFYHOST=>2]);
    if($post!==null){ curl_setopt($ch,CURLOPT_POST,true); curl_setopt($ch,CURLOPT_POSTFIELDS,http_build_query($post)); }
    $r=curl_exec($ch); if($r===false) error_log('SSLCommerz curl error: '.curl_error($ch)); curl_close($ch);
    $j=$r?json_decode($r,true):null; return is_array($j)?$j:null;
}
/** Create a payment attempt for an order and return the hosted gateway URL (or null). */
function sslc_init(array $o): ?string {
    $c=pay_cfg(); $tran=$o['order_no'].'-'.bin2hex(random_bytes(3));
    db()->prepare('INSERT INTO payments(order_id,gateway,transaction_id,amount,status) VALUES(?,?,?,?,"initiated")')->execute([$o['id'],'sslcommerz',$tran,$o['total']]);
    $r=sslc_http(sslc_host().'/gwprocess/v4/api.php',[
        'store_id'=>$c['store_id'],'store_passwd'=>$c['store_password'],'total_amount'=>number_format((float)$o['total'],2,'.',''),'currency'=>'BDT','tran_id'=>$tran,
        'success_url'=>$c['app_url'].'/payment-success.php','fail_url'=>$c['app_url'].'/payment-fail.php','cancel_url'=>$c['app_url'].'/payment-cancel.php','ipn_url'=>$c['app_url'].'/payment-ipn.php',
        'cus_name'=>$o['full_name'],'cus_email'=>$o['email']?:'noreply@example.com','cus_add1'=>$o['address'],'cus_city'=>'Dhaka','cus_country'=>'Bangladesh','cus_phone'=>$o['phone'],
        'shipping_method'=>'NO','product_name'=>'Food order '.$o['order_no'],'product_category'=>'Food','product_profile'=>'general']);
    return ($r && ($r['status']??'')==='SUCCESS' && !empty($r['GatewayPageURL']))?$r['GatewayPageURL']:null;
}
/** Server-side verification. The browser redirect alone never marks an order as paid. */
function sslc_settle(array $p): array {
    $pdo=db(); $tran=(string)($p['tran_id']??''); $val=(string)($p['val_id']??'');
    $st=$pdo->prepare("SELECT o.* FROM payments py JOIN orders o ON o.id=py.order_id WHERE py.transaction_id=? AND o.payment_method='online'"); $st->execute([$tran]); $o=$st->fetch();
    if(!$o) return ['ok'=>false,'order_no'=>'','msg'=>'We could not find this payment.'];
    if($o['payment_status']==='refunded') return ['ok'=>false,'order_no'=>$o['order_no'],'msg'=>'This payment was refunded.'];
    if($o['payment_status']==='paid') return ['ok'=>true,'order_no'=>$o['order_no'],'msg'=>'Payment confirmed.'];
    if($val==='') return ['ok'=>false,'order_no'=>$o['order_no'],'msg'=>'Payment was not completed.'];
    $c=pay_cfg();
    $r=sslc_http(sslc_host().'/validator/api/validationserverAPI.php?'.http_build_query(['val_id'=>$val,'store_id'=>$c['store_id'],'store_passwd'=>$c['store_password'],'v'=>1,'format'=>'json']));
    $good=$r && in_array($r['status']??'',['VALID','VALIDATED'],true) && ($r['tran_id']??'')===$tran
        && ($r['currency_type']??$r['currency']??'')==='BDT' && abs((float)($r['amount']??0)-(float)$o['total'])<0.01;
    if(!$good) return ['ok'=>false,'order_no'=>$o['order_no'],'msg'=>'We could not verify this payment. If money was taken, contact us with your order number.'];
    $raw=json_encode($r);
    if((string)($r['risk_level']??'0')==='1'){ $pdo->prepare('UPDATE payments SET val_id=?,raw_response=? WHERE transaction_id=?')->execute([$val,$raw,$tran]);
        return ['ok'=>false,'order_no'=>$o['order_no'],'msg'=>'Your payment is on hold for a security review. We will confirm your order shortly.']; }
    $pdo->beginTransaction();
    $pdo->prepare("UPDATE orders SET payment_status='paid' WHERE id=? AND payment_status NOT IN ('paid','refunded')")->execute([$o['id']]);
    $pdo->prepare("UPDATE payments SET status='validated',val_id=?,raw_response=? WHERE transaction_id=?")->execute([$val,$raw,$tran]);
    $pdo->commit();
    stock_after_payment((int)$o['id']);
    return ['ok'=>true,'order_no'=>$o['order_no'],'msg'=>'Payment confirmed. Thank you!'];
}
function sslc_mark(string $tran,string $status): void {
    $pdo=db(); $st=$pdo->prepare('SELECT order_id FROM payments WHERE transaction_id=?'); $st->execute([$tran]); $oid=$st->fetchColumn(); if(!$oid) return;
    $pdo->prepare("UPDATE payments SET status=? WHERE transaction_id=? AND status='initiated'")->execute([$status,$tran]);
    $pdo->prepare("UPDATE orders SET payment_status=? WHERE id=? AND payment_status NOT IN ('paid','refunded')")->execute([$status,$oid]);
}
function pay_page(string $title,string $msg,bool $ok): void { $GLOBALS['title']=$title; require __DIR__.'/header.php'; ?>
<section class="sec wrap narrow"><h2><?= e($title) ?></h2><p class="<?= $ok?'ok':'alert' ?>"><?= e($msg) ?></p>
<a class="btn dark" href="my-orders.php">View my orders</a></section><?php require __DIR__.'/footer.php'; }
