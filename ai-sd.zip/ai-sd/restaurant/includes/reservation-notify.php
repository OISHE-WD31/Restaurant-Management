<?php
const RES_CANCEL_REASONS=['table_unavailable'=>'Table unavailable','fully_booked'=>'Restaurant fully booked','restaurant_closure'=>'Unexpected restaurant closure','other'=>'Other'];
const NOTIFY_CHANNELS=['email'=>'Email','sms'=>'SMS','website'=>'Website notification'];
function mail_logo(): ?array {
    $f=setting('logo'); if($f==='') return null; $p=__DIR__.'/../uploads/products/'.basename($f);
    if(!is_file($p)||filesize($p)>1500000) return null; $m=(new finfo(FILEINFO_MIME_TYPE))->file($p); $x=['image/png'=>'png','image/jpeg'=>'jpg','image/webp'=>'webp'][$m]??null;
    return $x?['data'=>file_get_contents($p),'mime'=>$m,'ext'=>$x]:null;
}
function res_cancel_content(array $r,bool $hasLogo=false): array {
    $name=setting('restaurant_name','Our restaurant'); $when=date('d M Y',strtotime($r['res_date'])); $time=date('g:i A',strtotime($r['start_time']));
    $reason=RES_CANCEL_REASONS[$r['cancel_reason']??'']??'Other'; $note=trim((string)($r['cancel_note']??'')); $phone=setting('phone'); $mail=setting('email'); $addr=setting('address');
    $url=rtrim(mail_cfg()['app_url'],'/').'/reserve-table.php'; $g=(int)$r['guests'];
    $subject=$name.': your reservation '.$r['code'].' has been cancelled';
    $text="Dear {$r['name']},\n\nWe are very sorry to tell you that your table reservation has been cancelled.\n\nReservation ID: {$r['code']}\nDate: $when\nTime: $time\nGuests: $g\nReason: $reason\n".($note!==''?"Details: $note\n":'')."\nWe apologise for the inconvenience. You are welcome to book another time: $url\n\nContact us: $phone | $mail\n$addr\n\nWith kind regards,\n$name";
    $sms=mb_substr($name.': Reservation '.$r['code'].' ('.$when.' '.$time.', '.$g.' guests) is cancelled - '.$reason.'. Sorry! New booking: '.$phone,0,300);
    $row=fn($l,$v)=>'<tr><td style="padding:8px 0;color:#7a6650;width:42%">'.e($l).'</td><td style="padding:8px 0;font-weight:bold">'.e($v).'</td></tr>';
    $brand=$hasLogo?'<img src="cid:logo@restaurant" alt="'.e($name).'" style="max-height:64px;max-width:220px;display:block;margin:0 auto 8px">':'';
    $html='<!doctype html><html><body style="margin:0;background:#FBF3E1;font-family:Arial,Helvetica,sans-serif;color:#4A2F18"><table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#FBF3E1;padding:24px 10px"><tr><td align="center">'
      .'<table role="presentation" width="560" cellpadding="0" cellspacing="0" style="max-width:560px;width:100%;background:#ffffff;border-radius:18px;overflow:hidden">'
      .'<tr><td align="center" style="background:#A9B98A;padding:24px">'.$brand.'<div style="font-size:22px;font-weight:bold;color:#4A2F18">'.e($name).'</div></td></tr>'
      .'<tr><td style="padding:28px"><h2 style="margin:0 0 12px;font-size:22px">Your reservation has been cancelled</h2><p style="line-height:1.6">Dear '.e($r['name']).',</p><p style="line-height:1.6">We are very sorry to tell you that your table reservation has been cancelled. Here are the details:</p>'
      .'<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="border-top:1px solid #eadfc8;border-bottom:1px solid #eadfc8;margin:14px 0">'.$row('Reservation ID',$r['code']).$row('Date',$when).$row('Time',$time).$row('Guests',(string)$g).$row('Reason',$reason).($note!==''?$row('Additional explanation',$note):'').'</table>'
      .'<p style="line-height:1.6">We sincerely apologise for the inconvenience. We would love to welcome you another time.</p>'
      .'<p style="text-align:center;margin:24px 0"><a href="'.e($url).'" style="background:#E8873F;color:#ffffff;text-decoration:none;font-weight:bold;padding:14px 28px;border-radius:999px;display:inline-block">Make a new reservation</a></p>'
      .'<p style="line-height:1.6;font-size:14px;color:#7a6650">Questions? Contact us:<br>Phone: '.e($phone).'<br>Email: '.e($mail).'<br>'.e($addr).'</p></td></tr>'
      .'<tr><td align="center" style="background:#F7DFC6;padding:14px;font-size:12px;color:#7a6650">This message was sent by '.e($name).' about your reservation '.e($r['code']).'.</td></tr></table></td></tr></table></body></html>';
    return ['subject'=>$subject,'text'=>$text,'html'=>$html,'sms'=>$sms,'when'=>$when,'time'=>$time,'reason'=>$reason,'note'=>$note];
}
function res_customer_id(array $r): int {
    if(!empty($r['customer_id'])) return (int)$r['customer_id'];
    if(trim((string)$r['email'])==='') return 0; $s=db()->prepare('SELECT id FROM customers WHERE email=?'); $s->execute([trim($r['email'])]); return (int)$s->fetchColumn();
}
/** One attempt on one channel. Updates the log row; never throws. A "sent" status means the provider accepted the message. */
function notify_attempt(array $log,array $r): array {
    $pdo=db(); $ok=false; $err='';
    try{
        $logo=$log['channel']==='email'?mail_logo():null; $c=res_cancel_content($r,(bool)$logo);
        if($log['channel']==='email'){
            $to=trim((string)$r['email']); if($to===''&&($cid=res_customer_id($r))){ $q=$pdo->prepare('SELECT email FROM customers WHERE id=?'); $q->execute([$cid]); $to=(string)$q->fetchColumn(); }
            if(!mail_ready()) $err='Email is not configured. Add your SMTP details in config/notifications.local.php.';
            elseif($to==='') $err='No email address is on file for this reservation.';
            else{ $x=smtp_send($to,$c['subject'],$c['text'],$c['html'],$logo); $ok=$x['ok']; $err=$x['error']; }
        }elseif($log['channel']==='sms'){
            if(!sms_ready()) $err='SMS is not configured. Add your gateway details in config/notifications.local.php.';
            else{ $x=sms_send((string)$r['phone'],$c['sms']); $ok=$x['ok']; $err=$x['error']; }
        }else{
            $cid=res_customer_id($r);
            if(!$cid) $err='No customer account is linked to this reservation, so there is no account to notify.';
            else{ $pdo->prepare('INSERT IGNORE INTO customer_notifications(customer_id,type,title,message,reservation_id,reason) VALUES(?,?,?,?,?,?)')
                ->execute([$cid,'reservation_cancelled','Reservation '.$r['code'].' was cancelled','Your reservation '.$r['code'].' for '.$c['when'].' at '.$c['time'].' ('.(int)$r['guests'].' guests) was cancelled. Reason: '.$c['reason'].($c['note']!==''?'. '.$c['note']:'.'),$r['id'],$r['cancel_reason']]); $ok=true; }
        }
    }catch(Throwable $e){ error_log('notify_attempt: '.$e->getMessage()); $err='Unexpected error while sending.'; }
    $pdo->prepare('UPDATE reservation_notification_log SET status=?,attempts=attempts+1,failure_reason=?,sent_at=IF(?=1,NOW(),sent_at) WHERE id=?')->execute([$ok?'sent':'failed',$ok?null:mb_substr($err,0,255),$ok?1:0,$log['id']]);
    return ['status'=>$ok?'sent':'failed','error'=>$err];
}
function notify_dispatch(array $r,string $channel): array {
    $pdo=db(); $recipient=$channel==='email'?(string)$r['email']:($channel==='sms'?(string)$r['phone']:'Customer account'); $cid=res_customer_id($r);
    $ins=$pdo->prepare("INSERT IGNORE INTO reservation_notification_log(reservation_id,customer_id,event,channel,recipient,status) VALUES(?,?,'cancellation',?,?,'pending')");
    $ins->execute([$r['id'],$cid?:null,$channel,mb_substr($recipient,0,190)]);
    $s=$pdo->prepare("SELECT * FROM reservation_notification_log WHERE reservation_id=? AND event='cancellation' AND channel=?"); $s->execute([$r['id'],$channel]); $log=$s->fetch();
    if($ins->rowCount()===0) return ['status'=>$log['status'],'error'=>'Already recorded, not sent again.']; // duplicate protection
    return notify_attempt($log,$r);
}
function reservation_cancel(int $id,string $reason,string $note,array $channels,int $adminId): array {
    $channels=array_values(array_intersect(array_keys(NOTIFY_CHANNELS),array_map('strval',$channels))); $note=trim($note);
    if(!isset(RES_CANCEL_REASONS[$reason])) return ['ok'=>false,'msg'=>'Choose a cancellation reason.'];
    if(mb_strlen($note)>500) return ['ok'=>false,'msg'=>'The explanation can be at most 500 characters.'];
    if(!$channels) return ['ok'=>false,'msg'=>'Choose at least one way to notify the customer.'];
    $pdo=db();
    try{
        $pdo->beginTransaction(); $s=$pdo->prepare('SELECT * FROM table_reservations WHERE id=? FOR UPDATE'); $s->execute([$id]); $r=$s->fetch();
        if(!$r||!in_array($r['status'],['pending','confirmed'],true)){ $pdo->rollBack(); return ['ok'=>false,'msg'=>'This reservation can no longer be cancelled, so nothing was changed and no messages were sent.']; }
        $pdo->prepare("UPDATE table_reservations SET status='cancelled',cancel_reason=?,cancel_note=?,cancelled_at=NOW(),cancelled_by=? WHERE id=?")->execute([$reason,$note!==''?$note:null,$adminId?:null,$id]);
        $pdo->commit();
    }catch(Throwable $e){ if($pdo->inTransaction()) $pdo->rollBack(); error_log('reservation_cancel: '.$e->getMessage()); return ['ok'=>false,'msg'=>'Could not cancel the reservation. Nothing was changed.']; }
    // The cancellation is saved. Notifications run afterwards, so a failed email can never undo it.
    cn_reservation_event($id,'cancelled'); // the customer's My Account notification is always created (duplicates are ignored)
    $s=$pdo->prepare('SELECT * FROM table_reservations WHERE id=?'); $s->execute([$id]); $r=$s->fetch(); $parts=[];
    foreach($channels as $ch){ $x=notify_dispatch($r,$ch); $parts[]=NOTIFY_CHANNELS[$ch].': '.($x['status']==='sent'?'sent':'FAILED ('.$x['error'].')'); }
    return ['ok'=>true,'msg'=>'Reservation '.$r['code'].' cancelled. '.implode('. ',$parts).'.'];
}
function notify_retry(int $logId): array {
    $pdo=db();
    $claim=$pdo->prepare("UPDATE reservation_notification_log SET status='pending',failure_reason=NULL WHERE id=? AND (status='failed' OR (status='pending' AND updated_at<NOW()-INTERVAL 2 MINUTE))"); $claim->execute([$logId]);
    if($claim->rowCount()===0) return ['ok'=>false,'msg'=>'This notification was already sent or is being sent right now.'];
    $l=$pdo->prepare('SELECT * FROM reservation_notification_log WHERE id=?'); $l->execute([$logId]); $log=$l->fetch();
    $s=$pdo->prepare('SELECT * FROM table_reservations WHERE id=?'); $s->execute([$log['reservation_id']]); $r=$s->fetch();
    if(!$r||$r['status']!=='cancelled'){ $pdo->prepare("UPDATE reservation_notification_log SET status='failed',failure_reason='The reservation is not cancelled any more.' WHERE id=?")->execute([$logId]); return ['ok'=>false,'msg'=>'The reservation is not cancelled any more, so no message was sent.']; }
    $x=notify_attempt($log,$r); return ['ok'=>$x['status']==='sent','msg'=>$x['status']==='sent'?'Sent.':'Failed again: '.$x['error']];
}
function cust_unread_count(): int {
    if(empty($_SESSION['customer_id'])) return 0;
    try{ $s=db()->prepare('SELECT COUNT(*) FROM customer_notifications WHERE customer_id=? AND is_read=0'); $s->execute([$_SESSION['customer_id']]); return (int)$s->fetchColumn(); }catch(Throwable $e){ return 0; }
}
