<?php
require 'includes/functions.php'; $pdo=db(); $id=(int)($_GET['id']??0);
$st=$pdo->prepare('SELECT p.*,c.name cat FROM products p JOIN categories c ON c.id=p.category_id WHERE p.id=?'); $st->execute([$id]); $p=$st->fetch();
if($p && $_SERVER['REQUEST_METHOD']==='POST'){
  if(empty($_SESSION['customer_id'])){ header('Location: login.php?next=menu.php'); exit; }
  $rate=(int)($_POST['rating']??0); $c=trim($_POST['comment']??'');
  if(csrf_check() && $rate>=1 && $rate<=5 && mb_strlen($c)<=500){
    $pdo->prepare('INSERT INTO reviews(customer_id,product_id,name,rating,comment,is_approved) VALUES(?,?,?,?,?,0)')->execute([$_SESSION['customer_id'],$id,$_SESSION['customer_name'],$rate,$c]);
    $rid=(int)$pdo->lastInsertId(); review_store_analysis($rid);
    notify('review','New review submitted',$_SESSION['customer_name'].' rated '.$p['name'].' '.$rate.'/5.',$rid,'reviews.php');
    header('Location: food-details.php?id='.$id.'&reviewed=1'); exit;
  }
  $bad=true;
}
if(!$p){ http_response_code(404); $title='Not found'; require 'includes/header.php'; echo '<section class="sec wrap"><h2>Dish not found</h2><p><a href="menu.php"><u>Back to the menu</u></a></p></section>'; require 'includes/footer.php'; exit; }
$title=$p['name'];
$rv=$pdo->prepare('SELECT name,rating,comment,admin_reply,created_at FROM reviews WHERE product_id=? AND is_approved=1 ORDER BY id DESC LIMIT 10'); $rv->execute([$id]); $reviews=$rv->fetchAll();
$avg=$reviews?array_sum(array_column($reviews,'rating'))/count($reviews):(float)$p['rating'];
$rel=$pdo->prepare('SELECT * FROM products WHERE category_id=? AND id<>? AND is_available=1 LIMIT 3'); $rel->execute([$p['category_id'],$id]);
require 'includes/header.php'; ?>
<section class="sec wrap detail">
<div class="detail-grid"><div class="detail-img"><img src="<?= product_img($p['image']) ?>" alt="<?= e($p['name']) ?>"></div>
<div><a href="menu.php?cat=<?= (int)$p['category_id'] ?>"><?= e($p['cat']) ?></a><h2><?= e($p['name']) ?></h2>
<div class="stars"><?= stars($avg) ?> <small>(<?= number_format($avg,1) ?>)</small></div>
<p class="big"><?php if($p['discount_price']!==null): ?><s><?= money($p['price']) ?></s> <?php endif; ?><b><?= money(price_now($p)) ?></b></p>
<p><?= nl2br(e($p['description'])) ?></p>
<?php if($p['ingredients']): ?><h3>Ingredients</h3><p><?= e($p['ingredients']) ?></p><?php endif; ?>
<?php if($p['is_available']): ?><div class="buy"><label>Quantity <input type="number" id="qty" value="1" min="1" max="20"></label><button class="btn-add" data-id="<?= $p['id'] ?>">Add to cart</button></div>
<?php else: ?><p class="sold-out">Currently unavailable</p><?php endif; ?></div></div>
<h3>Reviews</h3>
<?php if(isset($_GET['reviewed'])): ?><p class="ok">Thanks. Your review will appear once we approve it.</p><?php endif; ?>
<?php if(!empty($bad)): ?><p class="alert">Choose a rating from 1 to 5 and keep your comment under 500 characters.</p><?php endif; ?>
<?php foreach($reviews as $r): ?><blockquote class="quote"><div class="stars"><?= stars((float)$r['rating']) ?></div><p><?= e($r['comment']) ?></p><footer><?= e($r['name']) ?></footer><?php if($r['admin_reply']): ?><p><b>Restaurant reply:</b> <?= e($r['admin_reply']) ?></p><?php endif; ?></blockquote><?php endforeach; if(!$reviews) echo '<p>No reviews yet.</p>'; ?>
<?php if(!empty($_SESSION['customer_id'])): ?><form method="post" class="form narrow"><?= csrf_field() ?><label>Rating<select name="rating"><?php for($i=5;$i>=1;$i--) echo "<option>$i</option>"; ?></select></label><label>Your review<textarea name="comment" rows="3" maxlength="500"></textarea></label><button class="btn">Submit review</button></form>
<?php else: ?><p><a href="login.php"><u>Log in</u></a> to write a review.</p><?php endif; ?>
<?php $r=$rel->fetchAll(); if($r): ?><h3>You may also like</h3><div class="grid"><?php foreach($r as $x) food_card($x); ?></div><?php endif; ?>
</section>
<?php require 'includes/footer.php'; ?>
