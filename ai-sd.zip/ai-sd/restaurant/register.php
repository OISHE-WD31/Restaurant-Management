<?php
require 'includes/functions.php'; $title='Register'; $err=[]; $v=['name'=>'','email'=>'','phone'=>''];
if($_SERVER['REQUEST_METHOD']==='POST'){
  if(!csrf_check()) $err[]='Session expired. Reload and try again.';
  $v=['name'=>trim($_POST['name']??''),'email'=>trim($_POST['email']??''),'phone'=>trim($_POST['phone']??'')];
  $pw=$_POST['password']??'';
  if(mb_strlen($v['name'])<2) $err[]='Enter your full name.';
  if(!filter_var($v['email'],FILTER_VALIDATE_EMAIL)) $err[]='Enter a valid email address.';
  if(!preg_match('/^\+?[0-9\- ]{7,20}$/',$v['phone'])) $err[]='Enter a valid phone number.';
  if(strlen($pw)<8) $err[]='Password must be at least 8 characters.';
  if(!$err){
    $st=db()->prepare('SELECT id FROM customers WHERE email=?'); $st->execute([$v['email']]);
    if($st->fetch()) $err[]='This email is already registered. Log in instead.';
    else{
      db()->prepare('INSERT INTO customers(name,email,phone,password_hash) VALUES(?,?,?,?)')->execute([$v['name'],$v['email'],$v['phone'],password_hash($pw,PASSWORD_DEFAULT)]);
      session_regenerate_id(true); $_SESSION['customer_id']=(int)db()->lastInsertId(); $_SESSION['customer_name']=$v['name'];
      notify('customer','New customer registered',$v['name'].' ('.$v['email'].') created an account.',(int)$_SESSION['customer_id'],'customers.php?view='.(int)$_SESSION['customer_id']);
      header('Location: menu.php'); exit;
    }
  }
}
require 'includes/header.php'; ?>
<section class="sec wrap narrow"><h2>Create your account</h2>
<?php foreach($err as $m): ?><p class="alert"><?= e($m) ?></p><?php endforeach; ?>
<form method="post" class="form"><?= csrf_field() ?>
<label>Full name<input name="name" value="<?= e($v['name']) ?>" required></label>
<label>Email<input type="email" name="email" value="<?= e($v['email']) ?>" required></label>
<label>Phone<input name="phone" value="<?= e($v['phone']) ?>" required></label>
<label>Password (8+ characters)<input type="password" name="password" minlength="8" required></label>
<button class="btn">Create account</button></form>
<p>Already have an account? <a href="login.php"><u>Log in</u></a></p></section>
<?php require 'includes/footer.php'; ?>
