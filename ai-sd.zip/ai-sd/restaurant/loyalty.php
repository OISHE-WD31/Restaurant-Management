<?php
// Old address kept working: rewards now live inside My Account.
header('Location: my-account.php?section=rewards'); exit;
