<?php
// Edit for your XAMPP setup. Never commit real secrets.
const DB_HOST='localhost'; const DB_NAME='restaurant_db'; const DB_USER='root'; const DB_PASS='';
function db(): PDO {
    static $pdo=null;
    if(!$pdo){
        try{ $pdo=new PDO('mysql:host='.DB_HOST.';dbname='.DB_NAME.';charset=utf8mb4',DB_USER,DB_PASS,[
            PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,PDO::ATTR_EMULATE_PREPARES=>false]);
        }catch(PDOException $e){ error_log($e->getMessage()); http_response_code(500); exit('Database connection failed. Check config/database.php.'); }
    }
    return $pdo;
}
