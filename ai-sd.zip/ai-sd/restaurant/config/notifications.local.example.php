<?php
// Copy this file to config/notifications.local.php and fill in YOUR provider details.
// notifications.local.php holds secrets: never share it or commit it. Leave a section empty to switch that channel off.
return [
    'app_url' => 'http://localhost/restaurant',   // public address of the site, no trailing slash (used for the "make a new reservation" button)
    'smtp' => [                                    // any SMTP provider: Gmail (app password), Brevo, Mailgun, your hosting mail, Mailtrap for testing
        'host' => '',                              // e.g. smtp.gmail.com
        'port' => 587,                             // 587 with 'tls', or 465 with 'ssl'
        'secure' => 'tls',                         // 'tls' (STARTTLS), 'ssl', or 'none'
        'username' => '',
        'password' => '',                          // Gmail needs an App Password, not your normal password
        'from_email' => '',                        // must be allowed by your provider
        'from_name' => '',                         // leave empty to use the restaurant name
        'verify_peer' => true,                     // keep true. Only set false on a local test machine with certificate problems
    ],
    'sms' => [                                     // Bangladesh gateway: BulkSMSBD (bulksmsbd.net)
        'provider' => 'bulksmsbd',
        'api_key' => '',
        'sender_id' => '',                         // your approved Sender ID
    ],
];
