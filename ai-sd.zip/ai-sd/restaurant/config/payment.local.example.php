<?php
// Copy this file to config/payment.local.php and fill in your own sandbox values.
// payment.local.php must never be shared or committed.
return [
    'store_id'       => '',   // from your SSLCommerz sandbox registration email
    'store_password' => '',
    'sandbox'        => true, // set false only with a live store
    'app_url'        => 'http://localhost/restaurant', // no trailing slash; must be reachable by the gateway for IPN
];
