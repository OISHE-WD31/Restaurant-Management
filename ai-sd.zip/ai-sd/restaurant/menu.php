<?php
$title='Menu';
require 'includes/header.php';
$cat=(int)($_GET['cat']??0); $q=trim($_GET['q']??'');
$cats=db()->query('SELECT * FROM categories ORDER BY sort_order')->fetchAll();
$sql='SELECT * FROM products WHERE 1'; $args=[];
if($cat){$sql.=' AND category_id=?';$args[]=$cat;}
if($q!==''){$sql.=' AND (name LIKE ? OR description LIKE ?)';$args[]="%$q%";$args[]="%$q%";}
$st=db()->prepare($sql.' ORDER BY is_available DESC, name'); $st->execute($args); $items=$st->fetchAll();
?>
<section class="sec wrap"><h2>Our menu</h2>
<form class="filters" method="get">
  <a class="chip <?= !$cat?'on':'' ?>" href="menu.php">All</a>
  <?php foreach($cats as $c): ?><a class="chip <?= $cat===(int)$c['id']?'on':'' ?>" href="menu.php?cat=<?= (int)$c['id'] ?>"><?= e($c['name']) ?></a><?php endforeach; ?>
  <?php if($cat): ?><input type="hidden" name="cat" value="<?= $cat ?>"><?php endif; ?>
  <input type="search" name="q" value="<?= e($q) ?>" placeholder="Search dishes">
</form>
<?php if(!$items): ?><p>No dishes match your search. Try another word or category.</p><?php endif; ?>
<div class="grid"><?php foreach($items as $p) food_card($p); ?></div></section>
<?php require 'includes/footer.php'; ?>
