<?php
// Phase 7 tests. Run:  php tests/test_phase7.php   (no MySQL needed: uses an in-memory SQLite stand-in for db()).
class T extends PDO { function prepare($q,$o=[]): PDOStatement|false { return parent::prepare(str_ireplace([' FOR UPDATE','INSERT IGNORE','GREATEST('],['','INSERT OR IGNORE','MAX('],$q),$o); } }
$pdo=new T('sqlite::memory:'); $pdo->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION); $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE,PDO::FETCH_ASSOC);
function db(){ global $pdo; return $pdo; } function money($v){ return number_format((float)$v,2); }
$root=dirname(__DIR__); require $root.'/includes/orders.php'; require $root.'/includes/loyalty.php'; require $root.'/includes/refunds.php'; require $root.'/includes/security.php';
$pdo->exec("CREATE TABLE orders(id INTEGER PRIMARY KEY,order_no,customer_id INTEGER,subtotal REAL,discount REAL,total REAL,payment_method,payment_status,status);
CREATE TABLE payments(id INTEGER PRIMARY KEY,order_id INTEGER,val_id,amount REAL,status);
CREATE TABLE order_refunds(id INTEGER PRIMARY KEY,order_id INTEGER,amount REAL,reason,created_by INTEGER);
CREATE TABLE loyalty_accounts(customer_id INTEGER PRIMARY KEY,points_balance INTEGER DEFAULT 0,lifetime_points INTEGER DEFAULT 0,tier TEXT DEFAULT 'bronze');
CREATE TABLE loyalty_transactions(id INTEGER PRIMARY KEY,customer_id INTEGER,order_id INTEGER,type,points INTEGER,note,created_by INTEGER,created_at DEFAULT CURRENT_TIMESTAMP,UNIQUE(order_id,type));
INSERT INTO orders VALUES (1,'COD1',1,500,0,500,'cod','paid','delivered'),(2,'ON2',1,500,0,500,'online','paid','delivered'),(3,'ON3',1,500,0,500,'online','paid','delivered'),(4,'ON4',1,500,0,500,'online','paid','delivered'),(5,'COD5',1,500,0,500,'cod','unpaid','delivered');
INSERT INTO payments(order_id,val_id,amount,status) VALUES (2,'V2',500,'validated'),(4,'V4',300,'validated');");
$fail=0; function ok($c,$m){ global $fail; echo ($c?'PASS ':'FAIL ').$m."\n"; if(!$c) $fail++; }
function ord_($id){ return db()->query("SELECT * FROM orders WHERE id=$id")->fetch(); } function acc(){ return db()->query('SELECT * FROM loyalty_accounts WHERE customer_id=1')->fetch(); }

// ---- 1. Who may earn points ----
ok(loy_eligible($pdo,ord_(1)),'COD order, paid: eligible');
ok(loy_eligible($pdo,ord_(2)),'online order with validated gateway payment of the full amount: eligible');
ok(!loy_eligible($pdo,ord_(3)),'online order marked paid but NO gateway record: NOT eligible');
ok(!loy_eligible($pdo,ord_(4)),'online order whose gateway amount differs: NOT eligible');
ok(!loy_eligible($pdo,ord_(5)),'unpaid order: NOT eligible');
loyalty_on_transition($pdo,ord_(3),'delivered'); ok(!acc(),'unverified online order earned nothing');
loyalty_on_transition($pdo,ord_(1),'preparing'); ok(!acc(),'no points before the order is delivered');

// ---- 2. Earning once ----
loyalty_on_transition($pdo,ord_(1),'delivered'); $a=acc(); ok($a&&$a['points_balance']===70,'delivered COD order earns 50 points + 20 welcome bonus (balance '.($a['points_balance']??'none').')');
loyalty_on_transition($pdo,ord_(1),'delivered'); ok(acc()['points_balance']===70,'delivering again does not double-award');

// ---- 3. Refunds take back points in proportion ----
$pdo->exec("INSERT INTO order_refunds(order_id,amount,reason) VALUES (1,250,'x')"); loyalty_on_refund($pdo,ord_(1));
ok(acc()['points_balance']===35,'refund of 250 of 500 takes back half (balance '.acc()['points_balance'].')');
$pdo->exec("INSERT INTO order_refunds(order_id,amount,reason) VALUES (1,100,'x')"); loyalty_on_refund($pdo,ord_(1));
ok(acc()['points_balance']===21,'second partial refund (total 350/500 = 70%) leaves 21 points (balance '.acc()['points_balance'].')');
loyalty_on_refund($pdo,ord_(1)); ok(acc()['points_balance']===21,'running the same refund again changes nothing');
$pdo->exec("INSERT INTO order_refunds(order_id,amount,reason) VALUES (1,150,'x')"); loyalty_on_refund($pdo,ord_(1));
ok(acc()['points_balance']===0,'full refund takes back everything earned (balance '.acc()['points_balance'].')');
ok((int)db()->query("SELECT COUNT(*) FROM loyalty_transactions WHERE order_id=1 AND type='reverse'")->fetchColumn()===1,'still exactly one reverse row per order');
ok(acc()['points_balance']>=0&&acc()['lifetime_points']>=0,'balances never go negative');

// ---- 4. Manual adjustment goes through the ledger ----
loy_apply($pdo,1,'adjust',25,null,'goodwill',1); loy_apply($pdo,1,'adjust',-5,null,'fix',1);
ok(acc()['points_balance']===20,'two manual adjustments both recorded (balance '.acc()['points_balance'].')');

// ---- 5. Login throttling ----
$pdo->exec("CREATE TABLE login_attempts(id INTEGER PRIMARY KEY,scope,identifier,ip,created_at)"); $_SERVER['REMOTE_ADDR']='1.2.3.4';
ok(!sec_blocked('customer','a@x.com'),'fresh account is not blocked');
for($i=0;$i<4;$i++) sec_fail('customer','A@X.com '); ok(!sec_blocked('customer','a@x.com'),'4 wrong passwords: still allowed (case and spaces ignored)');
sec_fail('customer','a@x.com'); ok(sec_blocked('customer','a@x.com'),'5th wrong password: blocked');
ok(!sec_blocked('customer','other@x.com'),'a different email is not blocked');
ok(!sec_blocked('admin','a@x.com'),'customer and admin attempts are counted separately');
sec_clear('customer','a@x.com'); ok(!sec_blocked('customer','a@x.com'),'a correct login clears the counter');
$pdo->exec("INSERT INTO login_attempts(scope,identifier,ip,created_at) SELECT 'customer','old','1.2.3.4','2000-01-01 00:00:00' FROM orders"); ok(!sec_blocked('customer','old'),'attempts older than 15 minutes are ignored');
for($i=0;$i<25;$i++) sec_fail('customer','u'.$i.'@x.com'); ok(sec_blocked('customer','brand-new@x.com'),'25 failures from one address block that address');
$pdo->exec('DROP TABLE login_attempts'); ok(!sec_blocked('customer','a@x.com'),'if migration 08 is not run yet, login still works (fails open)'); sec_fail('customer','a@x.com'); sec_clear('customer','a@x.com'); ok(true,'no crash when the table is missing');
echo $fail?"\n$fail FAILED\n":"\nALL PASSED\n"; exit($fail?1:0);
