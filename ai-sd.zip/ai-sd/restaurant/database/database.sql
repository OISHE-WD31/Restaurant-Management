CREATE DATABASE IF NOT EXISTS restaurant_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE restaurant_db;
CREATE TABLE admins(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(100) NOT NULL,email VARCHAR(150) NOT NULL UNIQUE,password_hash VARCHAR(255) NOT NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE customers(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(100) NOT NULL,email VARCHAR(150) NOT NULL UNIQUE,phone VARCHAR(30),address TEXT,password_hash VARCHAR(255) NOT NULL,is_active TINYINT(1) DEFAULT 1,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE categories(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(100) NOT NULL,slug VARCHAR(120) NOT NULL UNIQUE,image VARCHAR(255),sort_order INT DEFAULT 0,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE products(id INT AUTO_INCREMENT PRIMARY KEY,category_id INT NOT NULL,name VARCHAR(150) NOT NULL,description TEXT,ingredients TEXT,price DECIMAL(10,2) NOT NULL,discount_price DECIMAL(10,2) NULL,image VARCHAR(255),rating DECIMAL(2,1) DEFAULT 4.5,is_available TINYINT(1) DEFAULT 1,is_featured TINYINT(1) DEFAULT 0,is_popular TINYINT(1) DEFAULT 0,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,INDEX(category_id),INDEX(is_featured),FOREIGN KEY(category_id) REFERENCES categories(id) ON DELETE RESTRICT);
CREATE TABLE product_variations(id INT AUTO_INCREMENT PRIMARY KEY,product_id INT NOT NULL,label VARCHAR(60) NOT NULL,extra_price DECIMAL(10,2) DEFAULT 0,FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE CASCADE);
CREATE TABLE carts(id INT AUTO_INCREMENT PRIMARY KEY,customer_id INT NOT NULL,product_id INT NOT NULL,variation_id INT NULL,quantity INT NOT NULL DEFAULT 1,updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,UNIQUE(customer_id,product_id,variation_id),FOREIGN KEY(customer_id) REFERENCES customers(id) ON DELETE CASCADE,FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE CASCADE);
CREATE TABLE coupons(id INT AUTO_INCREMENT PRIMARY KEY,code VARCHAR(40) NOT NULL UNIQUE,type ENUM('percent','fixed') NOT NULL,value DECIMAL(10,2) NOT NULL,expires_at DATE NULL,is_active TINYINT(1) DEFAULT 1);
CREATE TABLE orders(id INT AUTO_INCREMENT PRIMARY KEY,order_no VARCHAR(30) NOT NULL UNIQUE,customer_id INT NULL,full_name VARCHAR(100) NOT NULL,phone VARCHAR(30) NOT NULL,email VARCHAR(150),address TEXT NOT NULL,notes TEXT,subtotal DECIMAL(10,2) NOT NULL,delivery_charge DECIMAL(10,2) DEFAULT 0,discount DECIMAL(10,2) DEFAULT 0,total DECIMAL(10,2) NOT NULL,coupon_id INT NULL,payment_method ENUM('cod','online') NOT NULL,payment_status ENUM('unpaid','paid','failed','cancelled','refunded') DEFAULT 'unpaid',status ENUM('pending','confirmed','preparing','out_for_delivery','delivered','cancelled') DEFAULT 'pending',created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,INDEX(customer_id),INDEX(status),FOREIGN KEY(customer_id) REFERENCES customers(id) ON DELETE SET NULL);
CREATE TABLE order_items(id INT AUTO_INCREMENT PRIMARY KEY,order_id INT NOT NULL,product_id INT NULL,name VARCHAR(150) NOT NULL,variation VARCHAR(60),unit_price DECIMAL(10,2) NOT NULL,quantity INT NOT NULL,FOREIGN KEY(order_id) REFERENCES orders(id) ON DELETE CASCADE);
CREATE TABLE payments(id INT AUTO_INCREMENT PRIMARY KEY,order_id INT NOT NULL,gateway VARCHAR(30) NOT NULL,transaction_id VARCHAR(100),val_id VARCHAR(100),amount DECIMAL(10,2) NOT NULL,status ENUM('initiated','validated','failed','cancelled','refunded') DEFAULT 'initiated',raw_response TEXT,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(order_id) REFERENCES orders(id) ON DELETE CASCADE);
CREATE TABLE reviews(id INT AUTO_INCREMENT PRIMARY KEY,customer_id INT NULL,product_id INT NULL,name VARCHAR(100) NOT NULL,rating TINYINT NOT NULL,comment TEXT,is_approved TINYINT(1) DEFAULT 0,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE restaurant_settings(setting_key VARCHAR(60) PRIMARY KEY,setting_value TEXT);
INSERT INTO restaurant_settings VALUES('restaurant_name','Spice & Sage'),('phone','+880 1700-000000'),('email','hello@spiceandsage.test'),('address','House 12, Road 5, Dhaka'),('opening_hours','Daily 11:00 AM - 11:00 PM'),('delivery_charge','60'),('facebook','#'),('instagram','#');
INSERT INTO categories(name,slug,sort_order) VALUES('Biryani','biryani',1),('Rice & Curry','rice-curry',2),('Grill','grill',3),('Breads','breads',4);
INSERT INTO products(category_id,name,description,ingredients,price,discount_price,is_featured,is_popular) VALUES
(1,'Mutton Kacchi Biryani','Slow-cooked basmati and tender mutton, sealed and steamed with saffron.','Basmati, mutton, saffron, yogurt, spices',420,380,1,1),
(1,'Chicken Tehari','Mustard-oil scented rice with juicy chicken pieces.','Rice, chicken, mustard oil, green chili',280,NULL,1,1),
(3,'Charcoal Chicken Tikka','Smoky marinated chicken, served with mint chutney.','Chicken, yogurt, tandoori masala',320,NULL,1,0),
(4,'Rumali Roti & Dal','Paper-thin roti with creamy lentils.','Flour, lentils, ghee',140,NULL,0,1),
(2,'Beef Bhuna Plate','Dark, slow-fried beef with steamed rice.','Beef, onion, rice, spices',350,320,0,1);
CREATE TABLE IF NOT EXISTS contact_messages(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(100) NOT NULL,email VARCHAR(150) NOT NULL,message TEXT NOT NULL,is_read TINYINT(1) DEFAULT 0,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
INSERT INTO reviews(name,rating,comment,is_approved) VALUES
('Nusrat J.',5,'The kacchi was fragrant and the meat fell off the bone. Delivery was still hot.',1),
('Tanvir A.',5,'Best tehari I have had in Dhaka. Portions are generous.',1),
('Mitu R.',4,'Lovely tikka and fresh rumali roti. Will order again.',1);
CREATE TABLE IF NOT EXISTS admin_notifications(
  id INT AUTO_INCREMENT PRIMARY KEY,
  type VARCHAR(20) NOT NULL,
  title VARCHAR(150) NOT NULL,
  message VARCHAR(500) NOT NULL,
  related_id INT NOT NULL DEFAULT 0,
  link VARCHAR(255) NOT NULL DEFAULT '',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uniq_event(type,related_id),
  INDEX(created_at)
);
CREATE TABLE IF NOT EXISTS admin_notification_state(
  admin_id INT NOT NULL,
  notification_id INT NOT NULL,
  is_read TINYINT(1) NOT NULL DEFAULT 0,
  is_deleted TINYINT(1) NOT NULL DEFAULT 0,
  PRIMARY KEY(admin_id,notification_id),
  FOREIGN KEY(admin_id) REFERENCES admins(id) ON DELETE CASCADE,
  FOREIGN KEY(notification_id) REFERENCES admin_notifications(id) ON DELETE CASCADE
);
ALTER TABLE orders MODIFY status ENUM('pending','confirmed','preparing','ready','out_for_delivery','delivered','cancelled') NOT NULL DEFAULT 'pending';
ALTER TABLE orders
  ADD order_source ENUM('website','kiosk','admin') NOT NULL DEFAULT 'website',
  ADD order_type ENUM('delivery','takeaway','dine_in') NOT NULL DEFAULT 'delivery',
  ADD table_id INT NULL,
  ADD stock_deducted TINYINT(1) NOT NULL DEFAULT 0,
  ADD confirmed_at DATETIME NULL, ADD ready_at DATETIME NULL, ADD delivered_at DATETIME NULL;
UPDATE orders SET stock_deducted=1;
ALTER TABLE admins ADD role ENUM('owner','manager','kitchen') NOT NULL DEFAULT 'owner';
CREATE TABLE order_refunds(id INT AUTO_INCREMENT PRIMARY KEY,order_id INT NOT NULL,amount DECIMAL(10,2) NOT NULL,reason VARCHAR(255),created_by INT NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,INDEX(order_id),FOREIGN KEY(order_id) REFERENCES orders(id) ON DELETE CASCADE);
CREATE TABLE restaurant_tables(id INT AUTO_INCREMENT PRIMARY KEY,table_no VARCHAR(20) NOT NULL UNIQUE,area VARCHAR(60) NOT NULL DEFAULT 'Main hall',capacity TINYINT NOT NULL,status ENUM('available','reserved','occupied','cleaning','unavailable') NOT NULL DEFAULT 'available',created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE table_reservations(id INT AUTO_INCREMENT PRIMARY KEY,code VARCHAR(12) NOT NULL UNIQUE,customer_id INT NULL,name VARCHAR(100) NOT NULL,phone VARCHAR(30) NOT NULL,email VARCHAR(150),res_date DATE NOT NULL,start_time TIME NOT NULL,end_time TIME NOT NULL,guests TINYINT NOT NULL,table_id INT NULL,preferred_table_id INT NULL,notes VARCHAR(500),status ENUM('pending','confirmed','checked_in','completed','cancelled','rejected','no_show') NOT NULL DEFAULT 'pending',created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,INDEX(table_id,res_date),INDEX(res_date,status),FOREIGN KEY(table_id) REFERENCES restaurant_tables(id) ON DELETE SET NULL,FOREIGN KEY(customer_id) REFERENCES customers(id) ON DELETE SET NULL);
CREATE TABLE reservation_settings(setting_key VARCHAR(40) PRIMARY KEY,setting_value VARCHAR(40) NOT NULL);
INSERT INTO reservation_settings VALUES('open_time','12:00'),('close_time','22:00'),('slot_minutes','30'),('duration_minutes','90'),('peak_start','19:00'),('peak_end','21:00'),('peak_duration_minutes','75'),('max_party_size','12'),('advance_days','30'),('max_seats_total','0');
INSERT INTO restaurant_tables(table_no,area,capacity) VALUES('T1','Main hall',2),('T2','Main hall',2),('T3','Main hall',4),('T4','Main hall',4),('T5','Window',2),('T6','Window',4),('T7','Family area',6),('T8','Family area',8);
CREATE TABLE suppliers(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(120) NOT NULL UNIQUE,phone VARCHAR(30),created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE ingredients(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(120) NOT NULL UNIQUE,unit ENUM('kg','g','l','ml','piece','packet') NOT NULL,stock DECIMAL(14,3) NOT NULL DEFAULT 0,min_stock DECIMAL(14,3) NOT NULL DEFAULT 0,unit_cost DECIMAL(12,4) NOT NULL DEFAULT 0,supplier_id INT NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(supplier_id) REFERENCES suppliers(id) ON DELETE SET NULL);
CREATE TABLE recipe_ingredients(id INT AUTO_INCREMENT PRIMARY KEY,product_id INT NOT NULL,ingredient_id INT NOT NULL,quantity DECIMAL(14,3) NOT NULL,unit ENUM('kg','g','l','ml','piece','packet') NOT NULL,UNIQUE KEY uniq_recipe(product_id,ingredient_id),FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE CASCADE,FOREIGN KEY(ingredient_id) REFERENCES ingredients(id) ON DELETE RESTRICT);
CREATE TABLE inventory_movements(id INT AUTO_INCREMENT PRIMARY KEY,ingredient_id INT NOT NULL,type ENUM('purchase','order_deduction','order_restore','adjustment','wastage') NOT NULL,quantity DECIMAL(14,3) NOT NULL,balance_after DECIMAL(14,3) NOT NULL,order_id INT NULL,note VARCHAR(255),unit_cost DECIMAL(12,4) NULL,created_by INT NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,UNIQUE KEY uniq_order_move(order_id,ingredient_id,type),INDEX(ingredient_id,created_at),INDEX(type,created_at),FOREIGN KEY(ingredient_id) REFERENCES ingredients(id) ON DELETE CASCADE);
CREATE TABLE stock_purchases(id INT AUTO_INCREMENT PRIMARY KEY,ingredient_id INT NOT NULL,supplier_id INT NULL,quantity DECIMAL(14,3) NOT NULL,unit_cost DECIMAL(12,4) NOT NULL,total DECIMAL(12,2) NOT NULL,note VARCHAR(255),purchased_at DATETIME NOT NULL,created_by INT NULL,FOREIGN KEY(ingredient_id) REFERENCES ingredients(id) ON DELETE CASCADE,FOREIGN KEY(supplier_id) REFERENCES suppliers(id) ON DELETE SET NULL);
ALTER TABLE reviews ADD is_hidden TINYINT(1) NOT NULL DEFAULT 0, ADD admin_reply TEXT NULL, ADD replied_at DATETIME NULL;
CREATE TABLE review_analysis(review_id INT PRIMARY KEY,sentiment ENUM('positive','neutral','negative') NOT NULL,score DECIMAL(5,2) NOT NULL DEFAULT 0,topics VARCHAR(255) NOT NULL DEFAULT '',positives VARCHAR(255) NOT NULL DEFAULT '',analyzer VARCHAR(20) NOT NULL DEFAULT 'rules',analyzed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,INDEX(sentiment),FOREIGN KEY(review_id) REFERENCES reviews(id) ON DELETE CASCADE);
CREATE TABLE reward_rules(rule_key VARCHAR(40) PRIMARY KEY,rule_value VARCHAR(40) NOT NULL);
INSERT INTO reward_rules VALUES('spend_per_point','10'),('first_order_bonus','20'),('silver_spent','5000'),('gold_spent','15000'),('vip_spent','40000'),('silver_bonus','10'),('gold_bonus','20'),('vip_bonus','30'),('redeem_points','100'),('redeem_value','50'),('coupon_days','30');
CREATE TABLE loyalty_accounts(customer_id INT PRIMARY KEY,points_balance INT NOT NULL DEFAULT 0,lifetime_points INT NOT NULL DEFAULT 0,tier ENUM('bronze','silver','gold','vip') NOT NULL DEFAULT 'bronze',updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,FOREIGN KEY(customer_id) REFERENCES customers(id) ON DELETE CASCADE);
CREATE TABLE loyalty_transactions(id INT AUTO_INCREMENT PRIMARY KEY,customer_id INT NOT NULL,type ENUM('earn','reverse','redeem','adjust') NOT NULL,points INT NOT NULL,order_id INT NULL,note VARCHAR(255),created_by INT NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,UNIQUE KEY uniq_order_reward(order_id,type),INDEX(customer_id,created_at),FOREIGN KEY(customer_id) REFERENCES customers(id) ON DELETE CASCADE);
ALTER TABLE coupons ADD max_uses INT NULL, ADD used_count INT NOT NULL DEFAULT 0, ADD customer_id INT NULL;
ALTER TABLE table_reservations
  ADD cancel_reason ENUM('table_unavailable','fully_booked','restaurant_closure','other') NULL,
  ADD cancel_note VARCHAR(500) NULL,
  ADD cancelled_at DATETIME NULL,
  ADD cancelled_by INT NULL;
CREATE TABLE customer_notifications(id INT AUTO_INCREMENT PRIMARY KEY,customer_id INT NOT NULL,type VARCHAR(40) NOT NULL,title VARCHAR(150) NOT NULL,message VARCHAR(600) NOT NULL,reservation_id INT NULL,reason VARCHAR(40) NULL,is_read TINYINT(1) NOT NULL DEFAULT 0,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,UNIQUE KEY uniq_cust_event(type,reservation_id),INDEX(customer_id,is_read,created_at),FOREIGN KEY(customer_id) REFERENCES customers(id) ON DELETE CASCADE,FOREIGN KEY(reservation_id) REFERENCES table_reservations(id) ON DELETE SET NULL);
CREATE TABLE reservation_notification_log(id INT AUTO_INCREMENT PRIMARY KEY,reservation_id INT NOT NULL,customer_id INT NULL,event VARCHAR(40) NOT NULL DEFAULT 'cancellation',channel ENUM('email','sms','website') NOT NULL,recipient VARCHAR(190) NOT NULL DEFAULT '',status ENUM('pending','sent','failed') NOT NULL DEFAULT 'pending',attempts INT NOT NULL DEFAULT 0,failure_reason VARCHAR(255) NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,sent_at DATETIME NULL,updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,UNIQUE KEY uniq_notice(reservation_id,event,channel),INDEX(status),FOREIGN KEY(reservation_id) REFERENCES table_reservations(id) ON DELETE CASCADE,FOREIGN KEY(customer_id) REFERENCES customers(id) ON DELETE SET NULL);
