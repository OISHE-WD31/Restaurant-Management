-- Run once in phpMyAdmin: select restaurant_db > SQL tab > paste > Go.
USE restaurant_db;
CREATE TABLE IF NOT EXISTS admin_notifications(
  id INT AUTO_INCREMENT PRIMARY KEY,
  type VARCHAR(20) NOT NULL,
  title VARCHAR(150) NOT NULL,
  message VARCHAR(500) NOT NULL,
  related_id INT NOT NULL DEFAULT 0,
  link VARCHAR(255) NOT NULL DEFAULT '',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uniq_event(type,related_id),
  INDEX(created_at)
);
CREATE TABLE IF NOT EXISTS admin_notification_state(
  admin_id INT NOT NULL,
  notification_id INT NOT NULL,
  is_read TINYINT(1) NOT NULL DEFAULT 0,
  is_deleted TINYINT(1) NOT NULL DEFAULT 0,
  PRIMARY KEY(admin_id,notification_id),
  FOREIGN KEY(admin_id) REFERENCES admins(id) ON DELETE CASCADE,
  FOREIGN KEY(notification_id) REFERENCES admin_notifications(id) ON DELETE CASCADE
);
