-- Run this once in phpMyAdmin (database restaurant_db > SQL tab) if you already imported an earlier version.
USE restaurant_db;
CREATE TABLE IF NOT EXISTS contact_messages(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(100) NOT NULL,email VARCHAR(150) NOT NULL,message TEXT NOT NULL,is_read TINYINT(1) DEFAULT 0,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
INSERT INTO reviews(name,rating,comment,is_approved) VALUES
('Nusrat J.',5,'The kacchi was fragrant and the meat fell off the bone. Delivery was still hot.',1),
('Tanvir A.',5,'Best tehari I have had in Dhaka. Portions are generous.',1),
('Mitu R.',4,'Lovely tikka and fresh rumali roti. Will order again.',1);
