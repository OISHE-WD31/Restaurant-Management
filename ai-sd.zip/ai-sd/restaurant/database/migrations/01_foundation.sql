-- Phase 1. Run ONCE in phpMyAdmin: select restaurant_db > SQL tab > paste > Go.
ALTER TABLE orders MODIFY status ENUM('pending','confirmed','preparing','ready','out_for_delivery','delivered','cancelled') NOT NULL DEFAULT 'pending';
ALTER TABLE orders
  ADD order_source ENUM('website','kiosk','admin') NOT NULL DEFAULT 'website',
  ADD order_type ENUM('delivery','takeaway','dine_in') NOT NULL DEFAULT 'delivery',
  ADD table_id INT NULL,
  ADD stock_deducted TINYINT(1) NOT NULL DEFAULT 0,
  ADD confirmed_at DATETIME NULL, ADD ready_at DATETIME NULL, ADD delivered_at DATETIME NULL;
-- Existing orders must never deduct stock retroactively once inventory is added.
UPDATE orders SET stock_deducted=1;
ALTER TABLE admins ADD role ENUM('owner','manager','kitchen') NOT NULL DEFAULT 'owner';
CREATE TABLE order_refunds(id INT AUTO_INCREMENT PRIMARY KEY,order_id INT NOT NULL,amount DECIMAL(10,2) NOT NULL,reason VARCHAR(255),created_by INT NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,INDEX(order_id),FOREIGN KEY(order_id) REFERENCES orders(id) ON DELETE CASCADE);
