-- Migration 07: Customer Account System (profile gender, saved addresses, order notifications).
-- Run ONCE in phpMyAdmin: select restaurant_db > SQL tab > paste this whole file > Go.
-- Written for XAMPP's MariaDB. It is safe to run twice (it checks "IF NOT EXISTS").
-- It only ADDS things. No rows are deleted and no existing column is changed.
-- Run it AFTER migrations 01-06. Your uploaded export already contains 06.

-- 1) Profile: optional gender on the customer.
ALTER TABLE customers
  ADD COLUMN IF NOT EXISTS gender ENUM('male','female','other') NULL AFTER phone;

-- 2) Saved delivery addresses (many per customer, at most one default, enforced by the website code).
CREATE TABLE IF NOT EXISTS customer_addresses(
  id INT AUTO_INCREMENT PRIMARY KEY,
  customer_id INT NOT NULL,
  address_type ENUM('home','work','other') NOT NULL DEFAULT 'home',
  full_address VARCHAR(255) NOT NULL,
  city VARCHAR(80) NOT NULL DEFAULT '',
  area VARCHAR(80) NULL,
  postal_code VARCHAR(20) NULL,
  instructions VARCHAR(255) NULL,
  is_default TINYINT(1) NOT NULL DEFAULT 0,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_addr_customer(customer_id,is_default),
  CONSTRAINT fk_addr_customer FOREIGN KEY(customer_id) REFERENCES customers(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Copy the old single "address" text of a customer into their address book (only if they have no saved address yet).
INSERT INTO customer_addresses(customer_id,address_type,full_address,city,is_default)
SELECT c.id,'home',LEFT(TRIM(c.address),255),'',1 FROM customers c
WHERE c.address IS NOT NULL AND TRIM(c.address)<>''
  AND NOT EXISTS(SELECT 1 FROM customer_addresses a WHERE a.customer_id=c.id);

-- 3) Customer notifications: link them to orders and stop duplicates per order + status.
--    Existing rows (reservation notifications) are untouched.
ALTER TABLE customer_notifications
  ADD COLUMN IF NOT EXISTS order_id INT NULL AFTER reservation_id;
ALTER TABLE customer_notifications
  ADD UNIQUE KEY IF NOT EXISTS uniq_cust_order_event(type,order_id);
ALTER TABLE customer_notifications
  ADD INDEX IF NOT EXISTS idx_cn_order(order_id);
-- 4) Faster "my reservations" lookups.
ALTER TABLE table_reservations
  ADD INDEX IF NOT EXISTS idx_res_customer_date(customer_id,res_date);

-- 5) LAST STEP: link notifications to orders with a foreign key.
--    Keep this statement last. If you run the file a second time, only this line complains
--    ("Duplicate key on write or update" / "constraint already exists"). That is harmless.
ALTER TABLE customer_notifications
  ADD CONSTRAINT fk_cn_order FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE SET NULL;
