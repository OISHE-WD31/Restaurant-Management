-- Migration 08 (Phase 7): login throttling. Run ONCE in phpMyAdmin: restaurant_db > SQL tab > paste > Go.
-- Adds one NEW table. Nothing existing is changed or deleted. Safe to run twice.
-- Without it the website still works; login throttling is simply off.
CREATE TABLE IF NOT EXISTS login_attempts(
  id INT AUTO_INCREMENT PRIMARY KEY,
  scope ENUM('customer','admin') NOT NULL,
  identifier VARCHAR(190) NOT NULL,
  ip VARCHAR(45) NOT NULL DEFAULT '',
  created_at DATETIME NOT NULL,
  INDEX idx_la_ident(scope,identifier,created_at),
  INDEX idx_la_ip(scope,ip,created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
