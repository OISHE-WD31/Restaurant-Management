-- Bug-fix set 1. Run ONCE in phpMyAdmin (restaurant_db > SQL tab) after 01, 02 and 03.
-- Purely additive: it only ADDS a 'refunded' value to two existing status lists.
-- No rows are changed or deleted, and every existing value keeps working.
ALTER TABLE orders   MODIFY payment_status ENUM('unpaid','paid','failed','cancelled','refunded') DEFAULT 'unpaid';
ALTER TABLE payments MODIFY status         ENUM('initiated','validated','failed','cancelled','refunded') DEFAULT 'initiated';

-- OPTIONAL data fix (disabled by default; remove the leading "-- " to run it).
-- Migration 01 marked every order that existed at the time as "stock already deducted", including orders that were still
-- pending. Those pending orders would therefore never deduct stock when confirmed. This re-enables deduction ONLY for
-- orders that are still pending and have no stock-deduction history. Orders that are delivered or cancelled are not touched.
-- UPDATE orders SET stock_deducted=0
--  WHERE status='pending' AND stock_deducted=1
--    AND id NOT IN (SELECT order_id FROM inventory_movements WHERE type='order_deduction' AND order_id IS NOT NULL);
