<?php
require 'layout.php'; admin_require(); $pdo=db(); $pid=(int)($_GET['p']??$_POST['p']??0); $units=['kg','g','l','ml','piece','packet'];
$ings=$pdo->query('SELECT id,name,unit,unit_cost FROM ingredients ORDER BY name')->fetchAll(); $byId=array_column($ings,null,'id');
if($_SERVER['REQUEST_METHOD']==='POST' && csrf_check() && $pid){
  $act=$_POST['act']??''; $iid=(int)($_POST['ingredient_id']??0); $q=(float)($_POST['quantity']??0); $u=$_POST['unit']??'';
  if($act==='remove'){ $pdo->prepare('DELETE FROM recipe_ingredients WHERE product_id=? AND ingredient_id=?')->execute([$pid,$iid]); flash('Ingredient removed from recipe.'); }
  elseif(!isset($byId[$iid])||$q<=0||!in_array($u,$units,true)) flash('Choose an ingredient and enter a quantity above 0.');
  elseif(unit_convert(1,$u,$byId[$iid]['unit'])===null) flash('That unit cannot be converted to '.$byId[$iid]['name'].'\'s unit ('.$byId[$iid]['unit'].'). Use a matching kind of unit.');
  else{ $pdo->prepare('INSERT INTO recipe_ingredients(product_id,ingredient_id,quantity,unit) VALUES(?,?,?,?) ON DUPLICATE KEY UPDATE quantity=VALUES(quantity),unit=VALUES(unit)')->execute([$pid,$iid,$q,$u]); flash('Recipe saved.'); }
  header('Location: recipes.php?p='.$pid); exit;
}
$products=$pdo->query('SELECT p.id,p.name,p.price,p.discount_price,(SELECT COUNT(*) FROM recipe_ingredients r WHERE r.product_id=p.id) n FROM products p ORDER BY p.name')->fetchAll(); $cur=null; foreach($products as $p) if((int)$p['id']===$pid) $cur=$p;
$lines=[]; $cost=0; if($cur){ $s=$pdo->prepare('SELECT ri.*,i.name,i.unit iu,i.unit_cost FROM recipe_ingredients ri JOIN ingredients i ON i.id=ri.ingredient_id WHERE ri.product_id=? ORDER BY i.name'); $s->execute([$pid]); $lines=$s->fetchAll();
  foreach($lines as &$l){ $l['cost']=(unit_convert((float)$l['quantity'],$l['unit'],$l['iu'])??0)*(float)$l['unit_cost']; $cost+=$l['cost']; } unset($l); }
admin_head('Recipes'); ?>
<form class="card filters2"><select name="p" onchange="this.form.submit()"><option value="0">Choose a food item</option><?php foreach($products as $p): ?><option value="<?= $p['id'] ?>" <?= $pid===(int)$p['id']?'selected':'' ?>><?= e($p['name']) ?> <?= $p['n']?'('.$p['n'].' ingredients)':'(no recipe)' ?></option><?php endforeach; ?></select><noscript><button class="btn">Open</button></noscript></form>
<p>Food items with no recipe do not use up any stock. Quantities are per one serving.</p>
<?php if($cur): $price=price_now($cur); ?>
<div class="card scroll"><h3><?= e($cur['name']) ?></h3><table><tr><th>Ingredient</th><th>Per serving</th><th>Est. cost</th><th></th></tr><?php foreach($lines as $l): ?><tr><td><?= e($l['name']) ?></td><td><?= fmt_qty($l['quantity']) ?> <?= e($l['unit']) ?></td><td><?= money(round($l['cost'],2)) ?></td>
<td><form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="p" value="<?= $pid ?>"><input type="hidden" name="ingredient_id" value="<?= $l['ingredient_id'] ?>"><button class="link bad" name="act" value="remove">Remove</button></form></td></tr><?php endforeach; ?></table>
<p>Estimated cost per serving: <b><?= money(round($cost,2)) ?></b> · Selling price: <b><?= money($price) ?></b> · Margin: <b><?= money(round($price-$cost,2)) ?></b></p></div>
<?php if(!$ings): ?><p class="note">Add ingredients first.</p><?php else: ?><form method="post" class="card form"><h3>Add or change an ingredient</h3><?= csrf_field() ?><input type="hidden" name="p" value="<?= $pid ?>"><div class="cols">
<label>Ingredient<select name="ingredient_id"><?php foreach($ings as $i): ?><option value="<?= $i['id'] ?>"><?= e($i['name']) ?> (<?= e($i['unit']) ?>)</option><?php endforeach; ?></select></label>
<label>Quantity per serving<input type="number" step="0.001" min="0.001" name="quantity" required></label><label>Unit<select name="unit"><?php foreach($units as $u): ?><option><?= $u ?></option><?php endforeach; ?></select></label></div><div><button class="btn" name="act" value="save">Save</button></div></form><?php endif; endif; ?>
<?php admin_foot();
