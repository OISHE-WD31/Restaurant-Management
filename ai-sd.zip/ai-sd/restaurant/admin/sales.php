<?php
require 'layout.php'; admin_require(); $pdo=db();
$R=an_range($pdo,$_GET); $from=$R['from']; $to=$R['to'];
$orders=an_orders($pdo,$from,$to); $refunds=an_refunds($pdo,$from,$to);
$sum=an_summary($orders,$refunds); $series=an_series($orders,$refunds,$from,$to); $peak=an_peak($orders); $best=an_best($pdo,$from,$to); $ov=an_overview($pdo);
$m2=fn($n)=>'৳'.number_format((float)$n,2); $dn=['','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'];
$daily=[];  foreach($series['daily'] as $k=>$v)  $daily[]=[date('d M',strtotime($k)),$v['net']];
$weekly=[]; foreach($series['weekly'] as $k=>$v) $weekly[]=[date('d M',strtotime($k)),$v['net']];
$monthly=[];foreach($series['monthly'] as $k=>$v)$monthly[]=[date('M Y',strtotime($k.'-01')),$v['net']];
$top=array_slice($best['products'],0,8);
// payment method distribution, from completed sales
$pm=['cod'=>['Cash on Delivery',0,0.0],'online'=>['Online payment',0,0.0]];
foreach($orders as $o) if(an_is_sale($o)&&isset($pm[$o['payment_method']])){ $pm[$o['payment_method']][1]++; $pm[$o['payment_method']][2]+=(float)$o['total']-($refunds[(int)$o['id']]??0); }
$hours=[]; foreach($peak['hours'] as $h=>$n) $hours[]=[sprintf('%02d:00',$h),$n]; $days=[]; foreach($peak['days'] as $k=>$n) $days[]=[substr($dn[$k],0,3),$n];
$hr=fn($h)=>sprintf('%02d:00–%02d:59',$h,$h);
$chart=['daily'=>$daily,'weekly'=>$weekly,'monthly'=>$monthly,'best'=>array_map(fn($p)=>[$p['name'],$p['qty']],$top),'cats'=>array_map(fn($c)=>[$c['name'],$c['revenue']],$best['categories']),
  'hours'=>$hours,'days'=>$days,'pay'=>array_map(fn($p)=>[$p[0],round($p[2],2)],array_values($pm))];
function preset_link(string $k,string $l,string $cur): void { echo '<a href="?range='.$k.'" class="'.($cur===$k?'on':'').'">'.$l.'</a>'; }
admin_head('Sales & Revenue'); ?>
<p class="muted">Revenue counts only <b>delivered orders with a verified payment</b>. Cancelled, unpaid, failed and pending orders are never counted, and refunds are deducted. Dates are order dates.</p>
<h3>Overview (all time)</h3>
<div class="stats">
<div class="stat"><span>Total revenue (net)</span><b><?= e($m2($ov['all']['net'])) ?></b></div>
<div class="stat"><span>Today's revenue</span><b><?= e($m2($ov['today'])) ?></b></div>
<div class="stat"><span>This week (from Monday)</span><b><?= e($m2($ov['week'])) ?></b></div>
<div class="stat"><span>This month</span><b><?= e($m2($ov['month'])) ?></b></div>
<div class="stat"><span>Total orders</span><b><?= (int)$ov['all']['orders'] ?></b></div>
<div class="stat"><span>Average order value</span><b><?= e($m2($ov['all']['aov'])) ?></b></div>
<div class="stat"><span>Completed orders</span><b><?= (int)$ov['all']['completed'] ?></b></div>
<div class="stat"><span>Cancelled orders</span><b><?= (int)$ov['all']['cancelled'] ?></b></div></div>

<form class="card filters2" method="get"><label>From <input type="date" name="from" value="<?= e($from) ?>"></label><label>To <input type="date" name="to" value="<?= e($to) ?>"></label><button class="btn">Apply dates</button>
<span class="presets"><?php foreach(['today'=>'Today','7d'=>'7 days','30d'=>'30 days','month'=>'This month','12m'=>'12 months','all'=>'All time'] as $k=>$l) preset_link($k,$l,$R['preset']); ?></span></form>

<h3>Selected period: <?= e(date('d M Y',strtotime($from))) ?> – <?= e(date('d M Y',strtotime($to))) ?></h3>
<div class="stats sm">
<div class="stat"><span>Gross sales (before discounts)</span><b><?= e($m2($sum['gross'])) ?></b></div>
<div class="stat"><span>− Discounts</span><b><?= e($m2($sum['discounts'])) ?></b></div>
<div class="stat"><span>+ Delivery charges</span><b><?= e($m2($sum['delivery'])) ?></b></div>
<div class="stat"><span>− Refunds</span><b><?= e($m2($sum['refunds'])) ?></b></div>
<div class="stat"><span>= Net revenue</span><b><?= e($m2($sum['net'])) ?></b></div>
<div class="stat"><span>Completed / refunded / cancelled</span><b><?= (int)$sum['completed'] ?> / <?= (int)$sum['refunded_orders'] ?> / <?= (int)$sum['cancelled'] ?></b></div>
<div class="stat"><span>Still open (not delivered)</span><b><?= (int)$sum['open'] ?></b></div>
<div class="stat"><span>Average order value</span><b><?= e($m2($sum['aov'])) ?></b></div></div>
<?php if($sum['completed']+$sum['refunded_orders']===0): ?><p class="note">No completed, verified sales in this period yet. Charts below show zero until orders are delivered and paid.</p><?php endif; ?>

<div class="charts">
<section class="card"><h3>Daily sales</h3><div class="chart-box"><canvas id="c-daily"></canvas></div></section>
<section class="card"><h3>Weekly sales</h3><div class="chart-box"><canvas id="c-weekly"></canvas></div></section>
<section class="card"><h3>Monthly revenue</h3><div class="chart-box"><canvas id="c-monthly"></canvas></div></section>
<section class="card"><h3>Best-selling food (quantity)</h3><div class="chart-box"><canvas id="c-best"></canvas></div></section>
<section class="card"><h3>Sales by food category</h3><div class="chart-box"><canvas id="c-cats"></canvas></div></section>
<section class="card"><h3>Peak ordering hours</h3><div class="chart-box"><canvas id="c-hours"></canvas></div></section>
<section class="card"><h3>Busiest days</h3><div class="chart-box"><canvas id="c-days"></canvas></div></section>
<section class="card"><h3>Payment method distribution</h3><div class="chart-box"><canvas id="c-pay"></canvas></div></section></div>

<section class="card scroll"><h3>Best-selling products</h3><p class="muted">From delivered, paid orders in the period. Revenue is item price × quantity, before discounts and refunds.</p>
<table><tr><th>#</th><th>Product</th><th>Quantity sold</th><th>Revenue</th><th>Orders</th></tr>
<?php foreach(array_slice($best['products'],0,50) as $i=>$p): ?><tr><td><?= $i+1 ?></td><td><?= e($p['name']) ?></td><td><?= (int)$p['qty'] ?></td><td><?= e($m2($p['revenue'])) ?></td><td><?= (int)$p['orders'] ?></td></tr><?php endforeach; if(!$best['products']) echo '<tr><td colspan="5">No sales in this period.</td></tr>'; ?></table></section>

<div class="two"><section class="card scroll"><h3>Sales by category</h3><table><tr><th>Category</th><th>Quantity</th><th>Revenue</th></tr>
<?php foreach($best['categories'] as $c): ?><tr><td><?= e($c['name']) ?></td><td><?= (int)$c['qty'] ?></td><td><?= e($m2($c['revenue'])) ?></td></tr><?php endforeach; if(!$best['categories']) echo '<tr><td colspan="3">No sales in this period.</td></tr>'; ?></table></section>
<section class="card scroll"><h3>Payment methods</h3><table><tr><th>Method</th><th>Orders</th><th>Net revenue</th></tr>
<?php foreach($pm as $p): ?><tr><td><?= e($p[0]) ?></td><td><?= (int)$p[1] ?></td><td><?= e($m2($p[2])) ?></td></tr><?php endforeach; ?></table></section></div>

<section class="card scroll"><h3>Peak hour analysis</h3>
<p class="muted">Based on <?= (int)$peak['total'] ?> orders placed in the period (cancelled orders excluded). High demand = at least 70% of the busiest hour or day; low = 30% or less.</p>
<?php if($peak['total']): ?>
<p><b>Busiest hours:</b> <?= e(implode(', ',array_map($hr,array_slice($peak['top_hours'],0,3)))) ?> · <b>Busiest days:</b> <?= e(implode(', ',array_map(fn($k)=>$dn[$k],array_slice($peak['top_days'],0,3)))) ?><br>
<b>High-demand hours:</b> <?= e(implode(', ',array_map($hr,array_keys(array_filter($peak['hour_level'],fn($l)=>$l==='high'))))?:'none') ?><br>
<b>Low-demand hours (with some orders):</b> <?= e(implode(', ',array_map($hr,array_keys(array_filter($peak['hour_level'],fn($l)=>$l==='low'))))?:'none') ?></p>
<div class="two"><div><h3>By hour</h3><table><tr><th>Hour</th><th>Orders</th><th>Demand</th></tr>
<?php foreach($peak['hours'] as $h=>$n): if($n===0) continue; ?><tr><td><?= e($hr($h)) ?></td><td><?= (int)$n ?></td><td class="lvl-<?= e($peak['hour_level'][$h]) ?>"><?= e(ucfirst($peak['hour_level'][$h])) ?></td></tr><?php endforeach; ?></table></div>
<div><h3>By day of week</h3><table><tr><th>Day</th><th>Orders</th><th>Demand</th></tr>
<?php for($d=1;$d<=7;$d++): ?><tr><td><?= e($dn[$d]) ?></td><td><?= (int)$peak['days'][$d] ?></td><td class="lvl-<?= e($peak['day_level'][$d]) ?>"><?= e($peak['day_level'][$d]==='none'?'–':ucfirst($peak['day_level'][$d])) ?></td></tr><?php endfor; ?></table></div></div>
<?php else: ?><p>No orders in this period.</p><?php endif; ?></section>

<details class="card scroll"><summary><b>View daily, weekly and monthly figures as tables</b></summary>
<div class="two"><div><h3>Daily</h3><table><tr><th>Date</th><th>Orders</th><th>Net revenue</th></tr><?php foreach(array_reverse($series['daily'],true) as $k=>$v): ?><tr><td><?= e(date('d M Y',strtotime($k))) ?></td><td><?= (int)$v['orders'] ?></td><td><?= e($m2($v['net'])) ?></td></tr><?php endforeach; ?></table></div>
<div><h3>Weekly (from Monday)</h3><table><tr><th>Week of</th><th>Orders</th><th>Net</th></tr><?php foreach(array_reverse($series['weekly'],true) as $k=>$v): ?><tr><td><?= e(date('d M Y',strtotime($k))) ?></td><td><?= (int)$v['orders'] ?></td><td><?= e($m2($v['net'])) ?></td></tr><?php endforeach; ?></table>
<h3>Monthly</h3><table><tr><th>Month</th><th>Orders</th><th>Net</th></tr><?php foreach(array_reverse($series['monthly'],true) as $k=>$v): ?><tr><td><?= e(date('M Y',strtotime($k.'-01'))) ?></td><td><?= (int)$v['orders'] ?></td><td><?= e($m2($v['net'])) ?></td></tr><?php endforeach; ?></table></div></div></details>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>
<script>
const D=<?= json_encode($chart,JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_UNESCAPED_UNICODE) ?>;
const P=['#E8873F','#A9B98A','#4A2F18','#F2B880','#7E9060','#B5483A','#C9A24A','#8C7AB5'];
function fallback(){document.querySelectorAll('.chart-box').forEach(b=>{b.innerHTML='<p class="chart-off">The chart could not load (Chart.js needs an internet connection). The tables on this page show the same figures.</p>'})}
if(typeof Chart==='undefined'){fallback()}else{
 const taka=v=>'৳'+Number(v).toLocaleString(undefined,{maximumFractionDigits:2});
 const mk=(id,type,rows,label,color,money,opts)=>{const el=document.getElementById(id);if(!el)return;const colors=type==='doughnut'?rows.map((_,i)=>P[i%P.length]):color;
  new Chart(el,{type,data:{labels:rows.map(r=>r[0]),datasets:[{label,data:rows.map(r=>r[1]),backgroundColor:colors,borderColor:type==='line'?color:undefined,borderWidth:type==='line'?2:0,tension:.3,fill:false}]},
  options:Object.assign({responsive:true,maintainAspectRatio:false,plugins:{legend:{display:type==='doughnut'},tooltip:{callbacks:{label:c=>(c.label?c.label+': ':'')+(money?taka(c.parsed.y??c.parsed):c.parsed.y??c.parsed)}}},
   scales:type==='doughnut'?{}:{y:{beginAtZero:true,ticks:{callback:v=>money?taka(v):v}}}},opts||{})})};
 mk('c-daily','line',D.daily,'Net revenue','#E8873F',true); mk('c-weekly','bar',D.weekly,'Net revenue','#A9B98A',true); mk('c-monthly','bar',D.monthly,'Net revenue','#E8873F',true);
 mk('c-best','bar',D.best,'Quantity sold','#A9B98A',false,{indexAxis:'y',scales:{x:{beginAtZero:true,ticks:{precision:0}}}}); mk('c-cats','doughnut',D.cats,'Revenue','',true);
 mk('c-hours','bar',D.hours,'Orders','#E8873F',false,{scales:{y:{beginAtZero:true,ticks:{precision:0}}}}); mk('c-days','bar',D.days,'Orders','#A9B98A',false,{scales:{y:{beginAtZero:true,ticks:{precision:0}}}});
 mk('c-pay','doughnut',D.pay,'Net revenue','',true);
}
</script>
<?php admin_foot();
