<?php
require 'layout.php'; admin_require(); $pdo=db(); $err=[];
if($_SERVER['REQUEST_METHOD']==='POST' && csrf_check()){
  $id=(int)($_POST['id']??0);
  if(($_POST['act']??'')==='delete'){
    try{ $pdo->prepare('DELETE FROM categories WHERE id=?')->execute([$id]); flash('Category deleted.'); }
    catch(PDOException $e){ flash('This category still has food items. Move or delete them first.'); }
    header('Location: categories.php'); exit;
  }
  $name=trim($_POST['name']??''); $ord=(int)($_POST['sort_order']??0);
  if($name==='') $err[]='Enter a category name.';
  $old=null; if($id){ $o=$pdo->prepare('SELECT image FROM categories WHERE id=?'); $o->execute([$id]); $old=$o->fetchColumn()?:null; }
  $img=upload_image($_FILES['image']??null,$err,$old);
  if(!$err){
    $slug=trim(preg_replace('/[^a-z0-9]+/','-',strtolower($name)),'-')?:'cat'; 
    try{
      if($id) $pdo->prepare('UPDATE categories SET name=?,slug=?,sort_order=?,image=? WHERE id=?')->execute([$name,$slug,$ord,$img,$id]);
      else $pdo->prepare('INSERT INTO categories(name,slug,sort_order,image) VALUES(?,?,?,?)')->execute([$name,$slug,$ord,$img]);
      flash('Category saved.'); header('Location: categories.php'); exit;
    }catch(PDOException $e){ $err[]='A category with this name already exists.'; }
  }
}
$edit=null; if(isset($_GET['edit'])){ $s=$pdo->prepare('SELECT * FROM categories WHERE id=?'); $s->execute([(int)$_GET['edit']]); $edit=$s->fetch()?:null; }
$list=$pdo->query('SELECT * FROM categories ORDER BY sort_order,name')->fetchAll(); $x=$edit??[];
admin_head('Categories'); foreach($err as $m) echo '<p class="note bad">'.e($m).'</p>'; ?>
<form method="post" enctype="multipart/form-data" class="card form"><h3><?= $edit?'Edit category':'Add category' ?></h3><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)($x['id']??0) ?>">
<div class="cols"><label>Name<input name="name" value="<?= e($x['name']??'') ?>" required></label><label>Display order<input type="number" name="sort_order" value="<?= (int)($x['sort_order']??0) ?>"></label></div>
<label>Image<input type="file" name="image" accept="image/jpeg,image/png,image/webp"></label><div><button class="btn">Save category</button> <?php if($edit): ?><a href="categories.php">Cancel</a><?php endif; ?></div></form>
<div class="card scroll"><table><tr><th>Order</th><th>Name</th><th></th></tr><?php foreach($list as $c): ?><tr><td><?= (int)$c['sort_order'] ?></td><td><?= e($c['name']) ?></td>
<td><a href="?edit=<?= $c['id'] ?>">Edit</a><form method="post" class="inline" onsubmit="return confirm('Delete this category?')"><?= csrf_field() ?><input type="hidden" name="act" value="delete"><input type="hidden" name="id" value="<?= $c['id'] ?>"><button class="link bad">Delete</button></form></td></tr><?php endforeach; ?></table></div>
<?php admin_foot();
