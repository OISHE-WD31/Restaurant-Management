<?php
require 'layout.php'; admin_require(); $pdo=db();
if($_SERVER['REQUEST_METHOD']==='POST' && csrf_check()){
  $set=$pdo->prepare('INSERT INTO restaurant_settings(setting_key,setting_value) VALUES(?,?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)'); $a=$_POST['act']??'';
  if($a==='key'){ $set->execute(['kiosk_key',bin2hex(random_bytes(12))]); flash('New access key created. Kiosks using the old link are now signed out.'); }
  else{ $w=(int)($_POST['kds_warn_min']??0); $l=(int)($_POST['kds_late_min']??0);
    if($w<1||$l<=$w||$l>240) flash('Kitchen timers: warning must be at least 1, and "too long" must be larger than warning (up to 240 minutes).');
    else{ $set->execute(['kiosk_enabled',isset($_POST['kiosk_enabled'])?'1':'0']); $set->execute(['kds_warn_min',(string)$w]); $set->execute(['kds_late_min',(string)$l]); if(setting('kiosk_key')==='') $set->execute(['kiosk_key',bin2hex(random_bytes(12))]); flash('Saved.'); } }
  header('Location: kiosk-orders.php'); exit; }
$key=setting('kiosk_key'); $base=(isset($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off'?'https':'http').'://'.($_SERVER['HTTP_HOST']??'localhost').rtrim(dirname(dirname($_SERVER['SCRIPT_NAME'])),'/\\');
$rows=$pdo->query("SELECT o.order_no,o.order_type,o.full_name,o.total,o.status,o.payment_status,o.created_at,t.table_no FROM orders o LEFT JOIN restaurant_tables t ON t.id=o.table_id WHERE o.order_source='kiosk' ORDER BY o.id DESC LIMIT 100")->fetchAll();
admin_head('Kiosk orders'); ?>
<form method="post" class="card form"><h3>Kiosk and kitchen settings</h3><?= csrf_field() ?>
<label class="checks"><input type="checkbox" name="kiosk_enabled" <?= setting('kiosk_enabled')==='1'?'checked':'' ?>> Kiosk enabled</label>
<div class="cols"><label>Kitchen warning after (minutes)<input type="number" name="kds_warn_min" min="1" value="<?= e(setting('kds_warn_min','10')) ?>"></label><label>Kitchen "waiting too long" after (minutes)<input type="number" name="kds_late_min" min="2" value="<?= e(setting('kds_late_min','20')) ?>"></label></div>
<div><button class="btn">Save</button></div><?php if($key!==''): ?><p>Open this link once on the kiosk tablet. Keep it private:<br><code><?= e($base.'/kiosk.php?key='.$key) ?></code></p><?php else: ?><p>Save once to create the kiosk access key.</p><?php endif; ?></form>
<form method="post" class="card"><?= csrf_field() ?><p>Lost the link or worried it leaked? A new key signs out every kiosk.</p><button class="btn" name="act" value="key" onclick="return confirm('Create a new key? Kiosks must be set up again.')">Create new access key</button></form>
<div class="card scroll"><h3>Kiosk orders</h3><table><tr><th>Order</th><th>Name</th><th>Type</th><th>Table</th><th>Total</th><th>Status</th><th>Payment</th><th>Time</th></tr><?php foreach($rows as $r): ?><tr><td><?= e($r['order_no']) ?></td><td><?= e($r['full_name']) ?></td><td><?= e(str_replace('_',' ',$r['order_type'])) ?></td><td><?= e($r['table_no']??'-') ?></td><td><?= money($r['total']) ?></td><td><?= e($r['status']) ?></td><td><?= e($r['payment_status']) ?> (counter)</td><td><?= e(substr($r['created_at'],0,16)) ?></td></tr><?php endforeach; if(!$rows) echo '<tr><td colspan="8">No kiosk orders yet.</td></tr>'; ?></table></div>
<?php admin_foot();
