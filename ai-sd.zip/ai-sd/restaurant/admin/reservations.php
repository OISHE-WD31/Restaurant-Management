<?php
require 'layout.php'; admin_require(); $pdo=db();
$ACT=RES_ACTIONS;
if($_SERVER['REQUEST_METHOD']==='POST' && csrf_check()){
  $act=$_POST['act']??''; $id=(int)($_POST['id']??0); $back='reservations.php?'.http_build_query(['date'=>$_POST['date']??'','status'=>$_POST['fstatus']??'']);
  if(isset($ACT[$act])){
    $x=res_transition($id,$act); flash($x['msg']);
  }elseif($act==='cancel_notify'){ $x=reservation_cancel((int)$id,(string)($_POST['reason']??''),(string)($_POST['note']??''),(array)($_POST['channels']??[]),(int)$_SESSION['admin_id']); flash($x['msg']);
  }elseif($act==='move'){ $m=res_move($id,$_POST['res_date']??'',$_POST['start']??'',(int)($_POST['guests']??0),(int)($_POST['table']??0)); flash($m['msg']); }
  elseif($act==='settings'){
    $ok=true; $in=[]; foreach(['open_time','close_time','peak_start','peak_end'] as $k){ $in[$k]=$_POST[$k]??''; if(!preg_match('/^([01]\d|2[0-3]):[0-5]\d$/',$in[$k])) $ok=false; }
    foreach(['slot_minutes'=>[5,240],'duration_minutes'=>[15,480],'peak_duration_minutes'=>[15,480],'max_party_size'=>[1,50],'advance_days'=>[1,365],'max_seats_total'=>[0,1000]] as $k=>[$lo,$hi]){ $in[$k]=(int)($_POST[$k]??-1); if($in[$k]<$lo||$in[$k]>$hi) $ok=false; }
    if($ok && res_mins($in['open_time'])>=res_mins($in['close_time'])) $ok=false;
    if($ok){ $st=$pdo->prepare('INSERT INTO reservation_settings(setting_key,setting_value) VALUES(?,?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)'); foreach($in as $k=>$v) $st->execute([$k,(string)$v]); flash('Reservation settings saved.'); } else flash('Check the settings: times must be HH:MM and open before close, numbers within range.');
  }
  header('Location: '.$back); exit;
}
$date=preg_match('/^\d{4}-\d{2}-\d{2}$/',$_GET['date']??'')?$_GET['date']:''; $fs=$_GET['status']??''; $sql='SELECT r.*,t.table_no FROM table_reservations r LEFT JOIN restaurant_tables t ON t.id=r.table_id WHERE 1'; $a=[];
if($date){ $sql.=' AND r.res_date=?'; $a[]=$date; } if(in_array($fs,['pending','confirmed','checked_in','completed','cancelled','rejected','no_show'],true)){ $sql.=' AND r.status=?'; $a[]=$fs; }
$st=$pdo->prepare($sql.' ORDER BY r.res_date DESC,r.start_time LIMIT 150'); $st->execute($a); $rows=$st->fetchAll();
$stats=$pdo->query("SELECT status,COUNT(*) n FROM table_reservations WHERE res_date>=CURDATE()-INTERVAL 30 DAY GROUP BY status")->fetchAll(PDO::FETCH_KEY_PAIR);
$tables=$pdo->query('SELECT id,table_no,capacity FROM restaurant_tables ORDER BY table_no')->fetchAll(); $c=res_cfg(); $slots=res_slots();
admin_head('Reservations'); ?>
<div class="stats"><?php foreach(['pending'=>'Pending','confirmed'=>'Confirmed','checked_in'=>'Checked in','completed'=>'Completed','cancelled'=>'Cancelled','no_show'=>'No-shows'] as $k=>$l): ?><div class="stat"><span><?= $l ?> (30 days)</span><b><?= (int)($stats[$k]??0) ?></b></div><?php endforeach; ?></div>
<form class="card filters2"><input type="date" name="date" value="<?= e($date) ?>"><select name="status"><option value="">All statuses</option><?php foreach(['pending','confirmed','checked_in','completed','cancelled','rejected','no_show'] as $s): ?><option <?= $fs===$s?'selected':'' ?>><?= $s ?></option><?php endforeach; ?></select><button class="btn">Filter</button></form>
<?php foreach($rows as $r): ?><details class="card"><summary><b><?= e($r['code']) ?></b> · <?= e($r['res_date']) ?> <?= e(substr($r['start_time'],0,5)) ?>–<?= e(substr($r['end_time'],0,5)) ?> · <?= e($r['name']) ?> · <?= (int)$r['guests'] ?> guests · Table <?= e($r['table_no']??'none') ?> · <b><?= e($r['status']) ?></b></summary>
<p><?= e($r['phone']) ?> · <?= e($r['email']) ?><?= $r['notes']?'<br><i>'.e($r['notes']).'</i>':'' ?></p>
<form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $r['id'] ?>"><input type="hidden" name="date" value="<?= e($date) ?>"><input type="hidden" name="fstatus" value="<?= e($fs) ?>">
<?php foreach($ACT as $k=>[$from,$to]) if(in_array($r['status'],$from,true)): ?><button class="btn" name="act" value="<?= $k ?>"><?= ucwords(str_replace('_',' ',$k)) ?></button> <?php endif; ?></form>
<?php if(in_array($r['status'],['pending','confirmed'],true)): ?><button type="button" class="btn danger" data-cancel="<?= e(json_encode(['id'=>(int)$r['id'],'code'=>$r['code'],'name'=>$r['name'],'date'=>date('d M Y',strtotime($r['res_date'])),'time'=>date('g:i A',strtotime($r['start_time'])),'guests'=>(int)$r['guests']])) ?>">Cancel reservation</button><?php endif; ?>
<?php if(in_array($r['status'],['pending','confirmed'],true)): ?><form method="post" class="form cols" style="margin-top:12px"><?= csrf_field() ?><input type="hidden" name="act" value="move"><input type="hidden" name="id" value="<?= $r['id'] ?>">
<label>Date<input type="date" name="res_date" value="<?= e($r['res_date']) ?>"></label><label>Time<select name="start"><?php foreach($slots as $s): ?><option <?= substr($r['start_time'],0,5)===$s?'selected':'' ?>><?= e($s) ?></option><?php endforeach; ?></select></label>
<label>Guests<input type="number" name="guests" min="1" value="<?= (int)$r['guests'] ?>"></label><label>Table<select name="table"><option value="0">Auto-assign</option><?php foreach($tables as $t): ?><option value="<?= $t['id'] ?>" <?= (int)$r['table_id']===(int)$t['id']?'selected':'' ?>><?= e($t['table_no']) ?> (<?= (int)$t['capacity'] ?>)</option><?php endforeach; ?></select></label>
<div><button class="btn">Reschedule / reassign</button></div></form><?php endif; ?></details><?php endforeach; if(!$rows) echo '<p>No reservations match.</p>'; ?>
<details class="card"><summary><b>Time slot &amp; capacity settings</b></summary><form method="post" class="form cols" style="margin-top:12px"><?= csrf_field() ?><input type="hidden" name="act" value="settings">
<?php foreach(['open_time'=>'Opening time (HH:MM)','close_time'=>'Closing time (HH:MM)','peak_start'=>'Peak starts','peak_end'=>'Peak ends','slot_minutes'=>'Slot interval (min)','duration_minutes'=>'Normal duration (min)','peak_duration_minutes'=>'Peak duration (min)','max_party_size'=>'Max party size','advance_days'=>'Book up to (days ahead)','max_seats_total'=>'Max guests at once (0 = no limit)'] as $k=>$l): ?><label><?= $l ?><input name="<?= $k ?>" value="<?= e($c[$k]) ?>"></label><?php endforeach; ?><div><button class="btn">Save settings</button></div></form></details>
<div class="ov-modal" id="cm" hidden><form method="post" class="cm-box" role="dialog" aria-modal="true" aria-labelledby="cm-title"><?= csrf_field() ?><input type="hidden" name="act" value="cancel_notify"><input type="hidden" name="id" id="cm-id"><input type="hidden" name="date" value="<?= e($date) ?>"><input type="hidden" name="fstatus" value="<?= e($fs) ?>">
<h3 id="cm-title">Cancel this reservation?</h3>
<dl><dt>Reservation ID</dt><dd id="cm-code"></dd><dt>Customer</dt><dd id="cm-name"></dd><dt>Date</dt><dd id="cm-date"></dd><dt>Time</dt><dd id="cm-time"></dd><dt>Guests</dt><dd id="cm-guests"></dd></dl>
<label>Reason<select name="reason" required><option value="">Choose a reason</option><?php foreach(RES_CANCEL_REASONS as $k=>$l): ?><option value="<?= e($k) ?>"><?= e($l) ?></option><?php endforeach; ?></select></label>
<label>Additional explanation (optional)<textarea name="note" rows="3" maxlength="500"></textarea></label>
<fieldset><legend>Tell the customer by</legend><?php foreach(NOTIFY_CHANNELS as $k=>$l): ?><label><input type="checkbox" name="channels[]" value="<?= e($k) ?>" <?= $k==='email'?'checked':'' ?>> <?= e($l) ?><?php if($k==='email'&&!mail_ready()) echo ' (not configured)'; if($k==='sms'&&!sms_ready()) echo ' (not configured)'; if($k==='website') echo ' (needs a customer account)'; ?></label><?php endforeach; ?></fieldset>
<p><small>The reservation is cancelled first and kept in the history. If a message cannot be sent, the cancellation stays and you can retry from Reservation alerts.</small></p>
<div><button class="btn danger">Confirm cancellation</button> <button type="button" class="link" id="cm-close">Keep reservation</button></div></form></div>
<script>
(()=>{const m=document.getElementById('cm');if(!m)return;const set=(i,v)=>document.getElementById(i).textContent=v,close=()=>m.hidden=true;
document.addEventListener('click',e=>{const b=e.target.closest('[data-cancel]');if(b){e.preventDefault();const d=JSON.parse(b.dataset.cancel);document.getElementById('cm-id').value=d.id;set('cm-code',d.code);set('cm-name',d.name);set('cm-date',d.date);set('cm-time',d.time);set('cm-guests',d.guests);m.querySelector('[name=reason]').value='';m.querySelector('[name=note]').value='';m.hidden=false;m.querySelector('[name=reason]').focus();return}
if(e.target===m||e.target.id==='cm-close')close()});
document.addEventListener('keydown',e=>{if(e.key==='Escape')close()});
m.querySelector('form').addEventListener('submit',e=>{if(!m.querySelector('[name="channels[]"]:checked')){e.preventDefault();alert('Choose at least one way to notify the customer.')}});})();
</script>
<?php admin_foot();
