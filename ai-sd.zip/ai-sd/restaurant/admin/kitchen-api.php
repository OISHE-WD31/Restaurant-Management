<?php
require __DIR__.'/layout.php';
header('Content-Type: application/json'); header('Cache-Control: no-store');
function kout(array $a,int $c=200): void { http_response_code($c); echo json_encode($a); exit; }
if(empty($_SESSION['admin_id'])) kout(['ok'=>false,'error'=>'auth'],401);
if(!in_array(admin_role(),['owner','manager','kitchen'],true)) kout(['ok'=>false,'error'=>'role'],403);
$pdo=db(); $aid=(int)$_SESSION['admin_id']; $msg='';
if($_SERVER['REQUEST_METHOD']==='POST'){
    if(!hash_equals($_SESSION['csrf']??'',$_SERVER['HTTP_X_CSRF']??'')) kout(['ok'=>false,'error'=>'csrf'],403);
    $id=(int)($_POST['id']??0); $s=$pdo->prepare('SELECT status,order_type FROM orders WHERE id=?'); $s->execute([$id]); $o=$s->fetch();
    $flow=['pending'=>'confirmed','confirmed'=>'preparing','preparing'=>'ready'];
    if(!$o) $msg='Order not found.';
    elseif($o['status']!==($_POST['from']??'')) $msg='Someone else already changed this order. The board has been refreshed.';
    else{ $next=$flow[$o['status']]??($o['status']==='ready'?($o['order_type']==='delivery'?'out_for_delivery':'delivered'):null);
        if(!$next) $msg='This order cannot be moved forward.'; else{ $r=order_transition($id,$next,$aid); $msg=$r['msg']; } }
}
session_write_close();
// Only orders the kitchen may cook: COD / pay-at-counter, or online orders with verified payment.
$rows=$pdo->query("SELECT o.id,o.order_no,o.order_type,o.order_source,o.status,o.notes,t.table_no,UNIX_TIMESTAMP(NOW())-UNIX_TIMESTAMP(o.created_at) wait
  FROM orders o LEFT JOIN restaurant_tables t ON t.id=o.table_id WHERE o.status IN ('pending','confirmed','preparing','ready') AND (o.payment_method='cod' OR o.payment_status='paid') ORDER BY o.created_at,o.id")->fetchAll();
$items=[]; if($rows){ $ids=array_column($rows,'id'); $q=$pdo->prepare('SELECT order_id,name,quantity FROM order_items WHERE order_id IN ('.implode(',',array_fill(0,count($ids),'?')).') ORDER BY id'); $q->execute($ids); foreach($q->fetchAll() as $i) $items[$i['order_id']][]=['name'=>$i['name'],'qty'=>(int)$i['quantity']]; }
$out=array_map(fn($r)=>['id'=>(int)$r['id'],'no'=>$r['order_no'],'type'=>$r['order_type'],'source'=>$r['order_source'],'status'=>$r['status'],'notes'=>(string)$r['notes'],'table'=>$r['table_no'],'wait'=>max(0,(int)$r['wait']),'items'=>$items[$r['id']]??[]],$rows);
kout(['ok'=>true,'msg'=>$msg,'warn'=>(int)setting('kds_warn_min','10'),'late'=>(int)setting('kds_late_min','20'),'orders'=>$out]);
