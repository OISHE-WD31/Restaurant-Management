<?php
require __DIR__.'/../includes/functions.php'; $err='';
function admin_landing(): string { try{ $s=db()->prepare('SELECT role FROM admins WHERE id=?'); $s->execute([$_SESSION['admin_id']??0]); return $s->fetchColumn()==='kitchen'?'kitchen.php':'dashboard.php'; }catch(Throwable $e){ return 'dashboard.php'; } }
if(!empty($_SESSION['admin_id'])){ header('Location: '.admin_landing()); exit; }
if($_SERVER['REQUEST_METHOD']==='POST'){
  if(!csrf_check()) $err='Session expired. Reload and try again.';
  else{ $em=trim($_POST['email']??''); $st=db()->prepare('SELECT * FROM admins WHERE email=?'); $st->execute([$em]); $a=$st->fetch();
    if(sec_blocked('admin',$em)){ $err=SEC_BLOCK_MSG; }
    elseif($a && password_verify($_POST['password']??'',$a['password_hash'])){ sec_clear('admin',$em); session_regenerate_id(true); $_SESSION['admin_id']=(int)$a['id']; $_SESSION['admin_name']=$a['name']; header('Location: '.admin_landing()); exit; }
    else{ sec_fail('admin',$em); $err='Email or password is incorrect.'; } }
}
$none=(int)db()->query('SELECT COUNT(*) FROM admins')->fetchColumn()===0;
?><!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Admin login</title><link rel="stylesheet" href="../assets/css/admin.css"></head><body class="center">
<form method="post" class="card"><h1>Admin login</h1><?php if($none): ?><p class="note">No admin yet. <a href="setup.php">Create the first admin</a></p><?php endif; ?>
<?php if($err): ?><p class="note bad"><?= e($err) ?></p><?php endif; ?><?= csrf_field() ?>
<label>Email<input type="email" name="email" required></label><label>Password<input type="password" name="password" required></label><button class="btn">Log in</button></form></body></html>
