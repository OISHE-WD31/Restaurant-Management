<?php
require 'layout.php'; admin_require(); $pdo=db();
$statuses=['pending'=>'Pending','confirmed'=>'Confirmed','preparing'=>'Preparing','ready'=>'Ready','out_for_delivery'=>'Out for delivery','delivered'=>'Delivered','cancelled'=>'Cancelled'];
if($_SERVER['REQUEST_METHOD']==='POST' && csrf_check()){
  $s=$_POST['status']??''; $id=(int)($_POST['id']??0);
  if(isset($statuses[$s])){
    $r=order_transition($id,$s,(int)$_SESSION['admin_id']); flash($r['msg']);
  }
  header('Location: orders.php?'.http_build_query(['status'=>$_POST['f']??'','q'=>$_POST['fq']??''])); exit;
}
$f=$_GET['status']??''; $q=trim($_GET['q']??''); $sql='SELECT * FROM orders WHERE 1'; $a=[];
if(isset($statuses[$f])){ $sql.=' AND status=?'; $a[]=$f; }
if($q!==''){ $sql.=' AND (order_no LIKE ? OR full_name LIKE ? OR phone LIKE ?)'; array_push($a,"%$q%","%$q%","%$q%"); }
$st=$pdo->prepare($sql.' ORDER BY id DESC LIMIT 100'); $st->execute($a); $orders=$st->fetchAll(); $it=$pdo->prepare('SELECT * FROM order_items WHERE order_id=?');
admin_head('Orders'); ?>
<form class="card filters2"><select name="status"><option value="">All statuses</option><?php foreach($statuses as $k=>$l): ?><option value="<?= $k ?>" <?= $f===$k?'selected':'' ?>><?= $l ?></option><?php endforeach; ?></select>
<input name="q" value="<?= e($q) ?>" placeholder="Order no, name or phone"><button class="btn">Filter</button></form>
<?php if(!$orders) echo '<p>No orders match.</p>'; foreach($orders as $o): $it->execute([$o['id']]); ?>
<details class="card"<?= count($orders)===1?' open':'' ?>><summary><b><?= e($o['order_no']) ?></b> · <?= e($o['full_name']) ?> · <?= money($o['total']) ?> · <?= e($statuses[$o['status']]) ?> · <?= e(ucfirst($o['payment_status'])) ?> · <?= e(ucfirst($o['order_source'])) ?> / <?= e(str_replace('_',' ',$o['order_type'])) ?></summary>
<p><?= e($o['phone']) ?> · <?= e($o['email']) ?><br><?= e($o['address']) ?><?= $o['notes']?'<br><i>'.e($o['notes']).'</i>':'' ?><br>Payment: <?= $o['payment_method']==='cod'?'Cash on Delivery':'Online' ?></p>
<ul><?php foreach($it->fetchAll() as $l): ?><li><?= e($l['name']) ?> × <?= (int)$l['quantity'] ?> — <?= money($l['unit_price']*$l['quantity']) ?></li><?php endforeach; ?></ul>
<form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $o['id'] ?>"><input type="hidden" name="f" value="<?= e($f) ?>"><input type="hidden" name="fq" value="<?= e($q) ?>">
<select name="status"><?php foreach($statuses as $k=>$l): ?><option value="<?= $k ?>" <?= $o['status']===$k?'selected':'' ?>><?= $l ?></option><?php endforeach; ?></select> <button class="btn">Update status</button></form></details>
<?php endforeach; admin_foot();
