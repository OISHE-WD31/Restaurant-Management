<?php
require 'layout.php'; admin_require(); $pdo=db(); $err=[];
if($_SERVER['REQUEST_METHOD']==='POST' && csrf_check()){
  $act=$_POST['act']??''; $id=(int)($_POST['id']??0);
  if($act==='toggle') $pdo->prepare('UPDATE coupons SET is_active=1-is_active WHERE id=?')->execute([$id]);
  elseif($act==='delete') $pdo->prepare('DELETE FROM coupons WHERE id=?')->execute([$id]);
  else{
    $code=strtoupper(trim($_POST['code']??'')); $type=$_POST['type']??''; $val=(float)($_POST['value']??0); $exp=($_POST['expires_at']??'')?:null;
    if(!preg_match('/^[A-Z0-9]{3,20}$/',$code)) $err[]='Code must be 3 to 20 letters or digits.';
    if(!in_array($type,['percent','fixed'],true)) $err[]='Choose a discount type.';
    if($val<=0||($type==='percent'&&$val>100)) $err[]='Enter a valid value (percent cannot exceed 100).';
    if($exp && !strtotime($exp)) $err[]='Enter a valid expiry date.';
    if(!$err){ try{ $pdo->prepare('INSERT INTO coupons(code,type,value,expires_at) VALUES(?,?,?,?)')->execute([$code,$type,$val,$exp]); }catch(PDOException $e){ $err[]='This code already exists.'; } }
  }
  if(!$err){ flash('Coupons updated.'); header('Location: coupons.php'); exit; }
}
$list=$pdo->query('SELECT * FROM coupons ORDER BY id DESC')->fetchAll(); admin_head('Coupons & discounts'); foreach($err as $m) echo '<p class="note bad">'.e($m).'</p>'; ?>
<form method="post" class="card form"><h3>New coupon</h3><?= csrf_field() ?><div class="cols"><label>Code<input name="code" required></label>
<label>Type<select name="type"><option value="percent">Percentage</option><option value="fixed">Fixed amount (৳)</option></select></label><label>Value<input type="number" step="0.01" name="value" required></label><label>Expires (optional)<input type="date" name="expires_at"></label></div><div><button class="btn">Create coupon</button></div></form>
<div class="card scroll"><table><tr><th>Code</th><th>Discount</th><th>Expires</th><th>Status</th><th></th></tr><?php foreach($list as $c): ?><tr><td><?= e($c['code']) ?></td><td><?= $c['type']==='percent'?e($c['value']).'%':money($c['value']) ?></td><td><?= e($c['expires_at']??'Never') ?></td><td><?= $c['is_active']?'Active':'Inactive' ?></td>
<td><form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $c['id'] ?>"><button class="link" name="act" value="toggle"><?= $c['is_active']?'Deactivate':'Activate' ?></button><button class="link bad" name="act" value="delete" onclick="return confirm('Delete coupon?')">Delete</button></form></td></tr><?php endforeach; ?></table></div>
<?php admin_foot();
