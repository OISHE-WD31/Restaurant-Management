<?php
require 'layout.php'; admin_require(); $pdo=db();
$m=$_GET['method']??''; $s=$_GET['pstatus']??''; $sql='SELECT order_no,full_name,total,payment_method,payment_status,status,created_at FROM orders WHERE 1'; $a=[];
if(in_array($m,['cod','online'],true)){ $sql.=' AND payment_method=?'; $a[]=$m; } if(in_array($s,['unpaid','paid','failed','cancelled'],true)){ $sql.=' AND payment_status=?'; $a[]=$s; }
$st=$pdo->prepare($sql.' ORDER BY created_at DESC LIMIT 100'); $st->execute($a); $rows=$st->fetchAll();
$paid=$pdo->query("SELECT COALESCE(SUM(total),0) FROM orders WHERE payment_status='paid' AND status<>'cancelled'")->fetchColumn(); $due=$pdo->query("SELECT COALESCE(SUM(total),0) FROM orders WHERE payment_status='unpaid' AND status NOT IN ('cancelled')")->fetchColumn();
admin_head('Payments'); ?>
<div class="stats"><div class="stat"><span>Collected</span><b><?= money($paid) ?></b></div><div class="stat"><span>Still to collect</span><b><?= money($due) ?></b></div></div>
<form class="card filters2"><select name="method"><option value="">All methods</option><option value="cod" <?= $m==='cod'?'selected':'' ?>>Cash on Delivery</option><option value="online" <?= $m==='online'?'selected':'' ?>>Online</option></select>
<select name="pstatus"><option value="">All payment statuses</option><?php foreach(['unpaid','paid','failed','cancelled'] as $x): ?><option value="<?= $x ?>" <?= $s===$x?'selected':'' ?>><?= ucfirst($x) ?></option><?php endforeach; ?></select><button class="btn">Filter</button></form>
<div class="card scroll"><table><tr><th>Order</th><th>Customer</th><th>Amount</th><th>Method</th><th>Payment</th><th>Order status</th></tr><?php foreach($rows as $r): ?><tr><td><?= e($r['order_no']) ?></td><td><?= e($r['full_name']) ?></td><td><?= money($r['total']) ?></td><td><?= $r['payment_method']==='cod'?'COD':'Online' ?></td><td><?= e($r['payment_status']) ?></td><td><?= e($r['status']) ?></td></tr><?php endforeach; ?></table></div>
<?php admin_foot();
