<?php
require 'layout.php'; admin_require(); $err=[];
$keys=['restaurant_name'=>'Restaurant name','phone'=>'Phone','email'=>'Email','address'=>'Address','opening_hours'=>'Opening hours','delivery_charge'=>'Delivery charge (৳)','facebook'=>'Facebook link','instagram'=>'Instagram link'];
if($_SERVER['REQUEST_METHOD']==='POST' && csrf_check()){
  $v=[]; foreach($keys as $k=>$_) $v[$k]=trim($_POST[$k]??'');
  if($v['restaurant_name']==='') $err[]='Enter a restaurant name.';
  if($v['email']!=='' && !filter_var($v['email'],FILTER_VALIDATE_EMAIL)) $err[]='Enter a valid email.';
  if(!is_numeric($v['delivery_charge'])||$v['delivery_charge']<0) $err[]='Delivery charge must be 0 or more.';
  foreach(['facebook','instagram'] as $k) if($v[$k]!=='' && !preg_match('#^https?://#i',$v[$k])) $v[$k]='#';
  $logo=upload_image($_FILES['logo']??null,$err,setting('logo')?:null);
  if(!$err){
    $st=db()->prepare('INSERT INTO restaurant_settings(setting_key,setting_value) VALUES(?,?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)');
    foreach($v as $k=>$val) $st->execute([$k,$val]); if($logo) $st->execute(['logo',$logo]);
    flash('Settings saved.'); header('Location: settings.php'); exit;
  }
}
admin_head('Website settings'); foreach($err as $m) echo '<p class="note bad">'.e($m).'</p>'; ?>
<form method="post" enctype="multipart/form-data" class="card form"><?= csrf_field() ?><div class="cols"><?php foreach($keys as $k=>$l): ?><label><?= e($l) ?><input name="<?= $k ?>" value="<?= e(setting($k)) ?>"></label><?php endforeach; ?></div>
<label>Logo (JPG, PNG, WebP)<input type="file" name="logo" accept="image/jpeg,image/png,image/webp"></label><div><button class="btn">Save settings</button></div></form>
<?php admin_foot();
