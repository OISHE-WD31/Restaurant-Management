<?php
require 'layout.php'; admin_require(); $pdo=db();
if($_SERVER['REQUEST_METHOD']==='POST' && csrf_check()){ $id=(int)($_POST['id']??0); $a=$_POST['act']??'';
  if($a==='delete') $pdo->prepare('DELETE FROM reviews WHERE id=?')->execute([$id]);
  elseif($a==='approve') $pdo->prepare('UPDATE reviews SET is_approved=1,is_hidden=0 WHERE id=?')->execute([$id]);
  elseif($a==='hide') $pdo->prepare('UPDATE reviews SET is_approved=0,is_hidden=1 WHERE id=?')->execute([$id]);
  elseif($a==='reply'){ $t=trim($_POST['reply']??''); if(mb_strlen($t)>1000) $t=mb_substr($t,0,1000); $pdo->prepare('UPDATE reviews SET admin_reply=?,replied_at=IF(?="",NULL,NOW()) WHERE id=?')->execute([$t?:null,$t,$id]); }
  flash('Review updated.'); header('Location: reviews.php?'.http_build_query(array_intersect_key($_GET,array_flip(['rating','status','sentiment','q'])))); exit; }
$fr=(int)($_GET['rating']??0); $fs=$_GET['status']??''; $fm=$_GET['sentiment']??''; $q=trim($_GET['q']??'');
$sql='SELECT r.*,a.sentiment,a.topics,p.name pname FROM reviews r LEFT JOIN review_analysis a ON a.review_id=r.id LEFT JOIN products p ON p.id=r.product_id WHERE 1'; $args=[];
if($fr>=1&&$fr<=5){ $sql.=' AND r.rating=?'; $args[]=$fr; }
if($fs==='pending') $sql.=' AND r.is_approved=0 AND r.is_hidden=0'; elseif($fs==='approved') $sql.=' AND r.is_approved=1'; elseif($fs==='hidden') $sql.=' AND r.is_hidden=1';
if(in_array($fm,['positive','neutral','negative'],true)){ $sql.=' AND a.sentiment=?'; $args[]=$fm; }
if($q!==''){ $sql.=' AND (r.name LIKE ? OR r.comment LIKE ? OR p.name LIKE ?)'; array_push($args,"%$q%","%$q%","%$q%"); }
$st=$pdo->prepare($sql.' ORDER BY r.id DESC LIMIT 100'); $st->execute($args); $rows=$st->fetchAll(); admin_head('Customer reviews'); ?>
<form class="card filters2"><input name="q" value="<?= e($q) ?>" placeholder="Search name, feedback or food"><select name="rating"><option value="0">Any rating</option><?php for($i=5;$i>=1;$i--): ?><option value="<?= $i ?>" <?= $fr===$i?'selected':'' ?>><?= $i ?> stars</option><?php endfor; ?></select>
<select name="status"><option value="">Any status</option><?php foreach(['pending','approved','hidden'] as $s): ?><option <?= $fs===$s?'selected':'' ?>><?= $s ?></option><?php endforeach; ?></select><select name="sentiment"><option value="">Any sentiment</option><?php foreach(['positive','neutral','negative'] as $s): ?><option <?= $fm===$s?'selected':'' ?>><?= $s ?></option><?php endforeach; ?></select><button class="btn">Filter</button></form>
<?php foreach($rows as $r): $status=$r['is_hidden']?'Hidden':($r['is_approved']?'Approved':'Pending'); ?><div class="card"><b><?= e($r['name']) ?></b> · <?= (int)$r['rating'] ?>/5 · <?= e($r['pname']??'Restaurant') ?> · <?= e(substr($r['created_at'],0,10)) ?> · <b><?= $status ?></b>
<?php if($r['sentiment']): ?> · <?= e(ucfirst($r['sentiment'])) ?><?php foreach(array_filter(explode(',',(string)$r['topics'])) as $t) echo ' <span class="nb-type">'.e(SENT_NEG_LABEL[$t]??$t).'</span>'; endif; ?>
<p><?= e($r['comment']) ?></p><?php if($r['admin_reply']): ?><p><i>Your reply: <?= e($r['admin_reply']) ?></i></p><?php endif; ?>
<form method="post" class="form"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $r['id'] ?>"><textarea name="reply" rows="2" maxlength="1000" placeholder="Reply to this customer (shown publicly under the review; leave empty to remove)"><?= e($r['admin_reply']) ?></textarea>
<div><button class="btn" name="act" value="reply">Save reply</button> <?php if($status!=='Approved'): ?><button class="link" name="act" value="approve">Approve</button><?php endif; ?><?php if($status!=='Hidden'): ?><button class="link" name="act" value="hide">Hide</button><?php endif; ?><button class="link bad" name="act" value="delete" onclick="return confirm('Delete review?')">Delete</button></div></form></div><?php endforeach; if(!$rows) echo '<p>No reviews match.</p>'; admin_foot();
