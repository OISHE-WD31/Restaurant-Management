<?php
require 'layout.php'; admin_require(); $aid=(int)$_SESSION['admin_id'];
if($_SERVER['REQUEST_METHOD']==='POST' && csrf_check()){ notif_action($aid,(string)($_POST['act']??''),(int)($_POST['id']??0)); header('Location: notifications.php'); exit; }
$rows=notif_list($aid,200); admin_head('Notifications'); ?>
<form method="post" class="card"><?= csrf_field() ?><button class="btn" name="act" value="read_all">Mark all as read</button></form>
<?php foreach($rows as $n): $l=notif_safe_link($n['link']); ?>
<div class="card nb-row <?= $n['is_read']?'':'unread' ?>"><b><?= e($n['title']) ?></b> <small>· <?= e(ucfirst($n['type'])) ?> · <?= e(date('d M Y, H:i',strtotime($n['created_at']))) ?> · <?= $n['is_read']?'Read':'Unread' ?></small>
<p><?= e($n['message']) ?></p>
<form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$n['id'] ?>"><?php if($l): ?><a href="<?= e($l) ?>">Open</a> <?php endif; ?>
<?php if(!$n['is_read']): ?><button class="link" name="act" value="read">Mark read</button><?php endif; ?><button class="link bad" name="act" value="delete">Delete</button></form></div>
<?php endforeach; if(!$rows) echo '<p>No notifications yet.</p>'; admin_foot();
