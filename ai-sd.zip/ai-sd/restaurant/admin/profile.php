<?php
require 'layout.php'; admin_require(); $err=[];
$me=db()->prepare('SELECT * FROM admins WHERE id=?'); $me->execute([$_SESSION['admin_id']]); $me=$me->fetch();
if($_SERVER['REQUEST_METHOD']==='POST' && csrf_check()){
  $n=trim($_POST['name']??''); $new=$_POST['new_password']??'';
  if($n==='') $err[]='Enter a name.';
  if(!password_verify($_POST['current']??'',$me['password_hash'])) $err[]='Current password is incorrect.';
  if($new!=='' && strlen($new)<10) $err[]='New password must be at least 10 characters.';
  if(!$err){
    if($new!=='') db()->prepare('UPDATE admins SET name=?,password_hash=? WHERE id=?')->execute([$n,password_hash($new,PASSWORD_DEFAULT),$me['id']]);
    else db()->prepare('UPDATE admins SET name=? WHERE id=?')->execute([$n,$me['id']]);
    $_SESSION['admin_name']=$n; flash('Profile updated.'); header('Location: profile.php'); exit;
  }
}
admin_head('My profile'); foreach($err as $m) echo '<p class="note bad">'.e($m).'</p>'; ?>
<form method="post" class="card form" style="max-width:480px"><?= csrf_field() ?><label>Name<input name="name" value="<?= e($me['name']) ?>" required></label><label>Email<input value="<?= e($me['email']) ?>" disabled></label>
<label>New password (leave blank to keep)<input type="password" name="new_password"></label><label>Current password<input type="password" name="current" required></label><div><button class="btn">Save profile</button></div></form>
<?php admin_foot();
