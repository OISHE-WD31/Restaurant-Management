<?php
require 'layout.php'; admin_require(); $pdo=db(); $D=rev_where();
$r=$pdo->query("SELECT DATE(created_at) d,SUM(total) t FROM orders WHERE $D AND created_at>=CURDATE()-INTERVAL 13 DAY GROUP BY d")->fetchAll(PDO::FETCH_KEY_PAIR); $daily=[];
for($i=13;$i>=0;$i--){ $d=date('Y-m-d',strtotime("-$i day")); $daily[date('d M',strtotime($d))]=(float)($r[$d]??0); }
$weekly=$pdo->query("SELECT MIN(DATE(created_at)) w,COUNT(*) n,SUM(total) t FROM orders WHERE $D AND created_at>=CURDATE()-INTERVAL 8 WEEK GROUP BY YEARWEEK(created_at,1) ORDER BY w DESC")->fetchAll();
$monthly=$pdo->query("SELECT DATE_FORMAT(created_at,'%b %Y') m,COUNT(*) n,SUM(total) t FROM orders WHERE $D AND created_at>=CURDATE()-INTERVAL 6 MONTH GROUP BY YEAR(created_at),MONTH(created_at),m ORDER BY YEAR(created_at) DESC,MONTH(created_at) DESC")->fetchAll();
$best=$pdo->query("SELECT oi.name,SUM(oi.quantity) q,SUM(oi.quantity*oi.unit_price) t FROM order_items oi JOIN orders o ON o.id=oi.order_id WHERE ".rev_where('o')." GROUP BY oi.name ORDER BY q DESC LIMIT 8")->fetchAll();
$pay=$pdo->query("SELECT payment_method,COUNT(*) n,SUM(total) t FROM orders WHERE $D GROUP BY payment_method")->fetchAll();
$total=(int)$pdo->query('SELECT COUNT(*) FROM orders')->fetchColumn(); admin_head('Reports & analytics'); ?>
<p>Revenue figures count delivered orders with verified payment only (refunds are not deducted on this page; see <a href="sales.php">Sales &amp; Revenue</a> for gross, discount, refund and net figures). Total orders placed: <b><?= $total ?></b>.</p>
<section class="card"><h3>Daily sales, last 14 days</h3><?php bars($daily); ?></section>
<div class="two"><section class="card scroll"><h3>Weekly sales</h3><table><tr><th>Week from</th><th>Orders</th><th>Revenue</th></tr><?php foreach($weekly as $w): ?><tr><td><?= e($w['w']) ?></td><td><?= (int)$w['n'] ?></td><td><?= money($w['t']) ?></td></tr><?php endforeach; ?></table></section>
<section class="card scroll"><h3>Monthly revenue</h3><table><tr><th>Month</th><th>Orders</th><th>Revenue</th></tr><?php foreach($monthly as $w): ?><tr><td><?= e($w['m']) ?></td><td><?= (int)$w['n'] ?></td><td><?= money($w['t']) ?></td></tr><?php endforeach; ?></table></section></div>
<div class="two"><section class="card scroll"><h3>Best-selling food</h3><table><tr><th>Dish</th><th>Sold</th><th>Value</th></tr><?php foreach($best as $b): ?><tr><td><?= e($b['name']) ?></td><td><?= (int)$b['q'] ?></td><td><?= money($b['t']) ?></td></tr><?php endforeach; ?></table></section>
<section class="card scroll"><h3>Payment methods</h3><table><tr><th>Method</th><th>Orders</th><th>Value</th></tr><?php foreach($pay as $b): ?><tr><td><?= $b['payment_method']==='cod'?'Cash on Delivery':'Online' ?></td><td><?= (int)$b['n'] ?></td><td><?= money($b['t']) ?></td></tr><?php endforeach; ?></table></section></div>
<?php admin_foot();
