<?php
require 'layout.php'; admin_require(); $pdo=db();
$q=fn($s)=>$pdo->query($s)->fetchColumn();
$stats=['Revenue'=>money($q("SELECT COALESCE(SUM(total),0) FROM orders WHERE ".rev_where())-$q("SELECT COALESCE(SUM(r.amount),0) FROM order_refunds r JOIN orders o ON o.id=r.order_id WHERE ".rev_where('o'))),'Orders'=>$q('SELECT COUNT(*) FROM orders'),'Food items'=>$q('SELECT COUNT(*) FROM products'),
 'Customers'=>$q('SELECT COUNT(*) FROM customers'),'Pending'=>$q("SELECT COUNT(*) FROM orders WHERE status='pending'"),'Completed'=>$q("SELECT COUNT(*) FROM orders WHERE status='delivered'")];
$stats=array_merge($stats,res_dashboard_stats());
$recent=$pdo->query('SELECT order_no,full_name,total,status,created_at FROM orders ORDER BY id DESC LIMIT 6')->fetchAll();
$top=$pdo->query("SELECT oi.name,SUM(oi.quantity) q FROM order_items oi JOIN orders o ON o.id=oi.order_id WHERE ".rev_where('o')." GROUP BY oi.name ORDER BY q DESC LIMIT 5")->fetchAll();
admin_head('Overview'); ?>
<div class="stats"><?php foreach($stats as $l=>$v): ?><div class="stat"><span><?= e($l) ?></span><b><?= e($v) ?></b></div><?php endforeach; ?></div>
<?php $rows=$pdo->query("SELECT DATE(created_at) d,SUM(total) t FROM orders WHERE ".rev_where()." AND created_at>=CURDATE()-INTERVAL 6 DAY GROUP BY d")->fetchAll(PDO::FETCH_KEY_PAIR); $days=[]; for($i=6;$i>=0;$i--){ $d=date('Y-m-d',strtotime("-$i day")); $days[date('D',strtotime($d))]=(float)($rows[$d]??0); } ?>
<section class="card"><h3>Revenue, last 7 days</h3><?php bars($days); ?></section>
<div class="two"><section class="card"><h3>Recent orders</h3><table><tr><th>Order</th><th>Customer</th><th>Total</th><th>Status</th></tr>
<?php foreach($recent as $o): ?><tr><td><?= e($o['order_no']) ?></td><td><?= e($o['full_name']) ?></td><td><?= money($o['total']) ?></td><td><?= e($o['status']) ?></td></tr><?php endforeach; ?></table></section>
<section class="card"><h3>Popular food</h3><?php foreach($top as $t): ?><p><?= e($t['name']) ?> <b><?= (int)$t['q'] ?> sold</b></p><?php endforeach; if(!$top) echo '<p>No orders yet.</p>'; ?></section></div>
<?php admin_foot();
