<?php
require 'layout.php'; admin_require(); $pdo=db();
$qs=function(array $g){ return http_build_query(array_filter(array_intersect_key($g,array_flip(['from','to','range','method','state'])),fn($v)=>$v!=='')); };
if($_SERVER['REQUEST_METHOD']==='POST' && csrf_check() && ($_POST['act']??'')==='refund'){
  $r=refund_order((int)($_POST['order_id']??0),(float)($_POST['amount']??0),(string)($_POST['reason']??''),(int)$_SESSION['admin_id']);
  flash($r['msg']); header('Location: payment-reports.php?'.$qs($_POST)); exit;
}
$R=an_range($pdo,$_GET); $method=in_array($_GET['method']??'',['cod','online'],true)?$_GET['method']:''; $state=isset(PAY_STATES[$_GET['state']??''])?$_GET['state']:'';
$res=an_payments($pdo,$R['from'],$R['to'],$method,$state); $rows=array_slice($res['rows'],0,500); $t=$res['totals'];
$m2=fn($n)=>'৳'.number_format((float)$n,2); $keep=['from'=>$R['from'],'to'=>$R['to'],'method'=>$method,'state'=>$state];
admin_head('Payment Reports'); ?>
<p class="muted">One row per order. <b>Paid</b> means verified: online payments need a validated gateway record whose amount matches the order, and COD counts once the order is delivered and cash is marked collected. An online order marked paid without that record shows as <b>Unverified</b>, never as Paid.</p>
<form class="card filters2" method="get"><label>From <input type="date" name="from" value="<?= e($R['from']) ?>"></label><label>To <input type="date" name="to" value="<?= e($R['to']) ?>"></label>
<label>Method <select name="method"><option value="">All methods</option><option value="cod" <?= $method==='cod'?'selected':'' ?>>Cash on Delivery</option><option value="online" <?= $method==='online'?'selected':'' ?>>Online</option></select></label>
<label>Status <select name="state"><option value="">All statuses</option><?php foreach(PAY_STATES as $k=>$l): ?><option value="<?= $k ?>" <?= $state===$k?'selected':'' ?>><?= $l ?></option><?php endforeach; ?></select></label>
<button class="btn">Filter</button> <span class="presets"><?php foreach(['today'=>'Today','7d'=>'7 days','30d'=>'30 days','month'=>'This month','all'=>'All time'] as $k=>$l): ?><a href="?range=<?= $k ?>">&nbsp;<?= $l ?>&nbsp;</a><?php endforeach; ?></span></form>
<div class="stats sm">
<div class="stat"><span>Verified paid</span><b><?= e($m2($t['paid'])) ?></b></div>
<div class="stat"><span>Pending</span><b><?= e($m2($t['pending'])) ?></b></div>
<div class="stat"><span>Unverified</span><b><?= e($m2($t['unverified'])) ?></b></div>
<div class="stat"><span>Refunds issued</span><b><?= e($m2($t['refunded'])) ?></b></div>
<div class="stat"><span>Paid / pending</span><b><?= (int)$t['n']['paid'] ?> / <?= (int)$t['n']['pending'] ?></b></div>
<div class="stat"><span>Failed / cancelled</span><b><?= (int)$t['n']['failed'] ?> / <?= (int)$t['n']['cancelled'] ?></b></div>
<div class="stat"><span>Refunded / unverified</span><b><?= (int)$t['n']['refunded'] ?> / <?= (int)$t['n']['unverified'] ?></b></div>
<div class="stat"><span>Needs attention</span><b><?= (int)$t['attention'] ?></b></div></div>
<div class="card scroll"><table><tr><th>Order ID</th><th>Order</th><th>Payment ID</th><th>Method</th><th>Transaction reference</th><th>Amount</th><th>Payment status</th><th>Payment date</th><th>Order status</th><th></th></tr>
<?php foreach($rows as $r): $o=$r['order']; $p=$r['payment']; $left=round((float)$o['total']-$r['refunded'],2); ?>
<tr><td><?= (int)$o['id'] ?></td><td><?= e($o['order_no']) ?></td><td><?= $p?(int)$p['id']:'–' ?><?= $r['attempts']>1?' <small class="muted">('.$r['attempts'].' attempts)</small>':'' ?></td>
<td><?= $o['payment_method']==='cod'?'Cash on Delivery':'Online' ?></td>
<td><?= $o['payment_method']==='cod'?e($o['order_no']).' <small class="muted">(cash)</small>':e($p['transaction_id']??'–').(!empty($p['val_id'])?' <small class="muted">val '.e($p['val_id']).'</small>':'') ?></td>
<td><?= e($m2($o['total'])) ?></td><td><span class="pill <?= e($r['state']) ?>"><?= e(PAY_STATES[$r['state']]) ?></span><?php foreach($r['notes'] as $n) echo '<br><small class="muted">'.e($n).' ('.e($m2($r['refunded'])).')</small>'; foreach($r['flags'] as $f) echo '<br><small class="warn">⚠ '.e($f).'</small>'; ?></td>
<td><?= e(substr($r['date'],0,16)) ?></td><td><?= e($o['status']) ?></td>
<td><?php if($o['payment_status']==='paid' && $left>0): ?><details><summary class="link">Refund</summary>
<form method="post" class="form" onsubmit="return confirm('Record this refund? This cannot be undone.')"><?= csrf_field() ?><input type="hidden" name="act" value="refund"><input type="hidden" name="order_id" value="<?= (int)$o['id'] ?>">
<?php foreach($keep as $k=>$v): ?><input type="hidden" name="<?= e($k) ?>" value="<?= e($v) ?>"><?php endforeach; ?>
<label>Amount (max <?= e($m2($left)) ?>)<input type="number" name="amount" step="0.01" min="0.01" max="<?= e($left) ?>" value="<?= e($left) ?>" required></label>
<label>Reason<input name="reason" maxlength="255" required></label><button class="btn">Record refund</button></form></details><?php endif; ?></td></tr>
<?php endforeach; if(!$rows) echo '<tr><td colspan="10">No orders match these filters.</td></tr>'; ?></table>
<?php if(count($res['rows'])>500) echo '<p class="muted">Showing the 500 most recent of '.count($res['rows']).' rows. Narrow the dates to see the rest.</p>'; ?></div>
<p class="muted">Payment date: for online payments, the time the payment attempt was made (the gateway verification time is not stored); for cash on delivery, the delivery time. Recording a refund updates the restaurant's books only. For online payments, also return the money through the SSLCommerz merchant panel.</p>
<?php admin_foot();
