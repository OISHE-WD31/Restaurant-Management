<?php
require 'layout.php'; admin_require(); $pdo=db();
if($_SERVER['REQUEST_METHOD']==='POST' && csrf_check()){ $id=(int)$_POST['id'];
  if(($_POST['act']??'')==='delete') $pdo->prepare('DELETE FROM contact_messages WHERE id=?')->execute([$id]); else $pdo->prepare('UPDATE contact_messages SET is_read=1 WHERE id=?')->execute([$id]);
  header('Location: messages.php'); exit; }
$rows=$pdo->query('SELECT * FROM contact_messages ORDER BY is_read,id DESC LIMIT 100')->fetchAll(); admin_head('Messages'); ?>
<?php foreach($rows as $m): ?><div class="card"><b><?= e($m['name']) ?></b> · <a href="mailto:<?= e($m['email']) ?>"><?= e($m['email']) ?></a> · <?= e($m['created_at']) ?><?= $m['is_read']?'':' · <b>New</b>' ?><p><?= nl2br(e($m['message'])) ?></p>
<form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $m['id'] ?>"><?php if(!$m['is_read']): ?><button class="link" name="act" value="read">Mark as read</button><?php endif; ?><button class="link bad" name="act" value="delete" onclick="return confirm('Delete message?')">Delete</button></form></div><?php endforeach; if(!$rows) echo '<p>No messages yet.</p>'; admin_foot();
