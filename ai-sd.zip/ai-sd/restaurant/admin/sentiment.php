<?php
require 'layout.php'; admin_require(); $pdo=db(); $to=an_date($_GET['to']??null)?:an_today($pdo); $from=an_date($_GET['from']??null)?:an_add_days($to,-29); if($from>$to) [$from,$to]=[$to,$from];
if($_SERVER['REQUEST_METHOD']==='POST' && csrf_check()){ $ids=$pdo->query('SELECT id FROM reviews')->fetchAll(PDO::FETCH_COLUMN); foreach($ids as $i) review_store_analysis((int)$i); flash('Analysed '.count($ids).' reviews.'); header('Location: sentiment.php'); exit; }
$st=$pdo->prepare('SELECT r.rating,r.product_id,p.name pname,a.sentiment,a.topics,a.positives FROM reviews r LEFT JOIN review_analysis a ON a.review_id=r.id LEFT JOIN products p ON p.id=r.product_id WHERE r.is_hidden=0 AND DATE(r.created_at) BETWEEN ? AND ?'); $st->execute([$from,$to]); $rows=$st->fetchAll();
$n=count($rows); $cnt=['positive'=>0,'neutral'=>0,'negative'=>0]; $un=0; $sum=0; $dist=[1=>0,2=>0,3=>0,4=>0,5=>0]; $neg=[]; $pos=[]; $prod=[];
foreach($rows as $r){ $sum+=$r['rating']; $dist[(int)$r['rating']]++; if(!$r['sentiment']){ $un++; continue; } $cnt[$r['sentiment']]++;
  foreach(array_filter(explode(',',(string)$r['topics'])) as $t){ $neg[$t]=($neg[$t]??0)+1; if($r['pname']){ $prod[$r['pname']]['t'][$t]=($prod[$r['pname']]['t'][$t]??0)+1; } }
  foreach(array_filter(explode(',',(string)$r['positives'])) as $t) $pos[$t]=($pos[$t]??0)+1;
  if($r['pname']){ $prod[$r['pname']]['n']=($prod[$r['pname']]['n']??0)+1; if($r['sentiment']==='negative') $prod[$r['pname']]['neg']=($prod[$r['pname']]['neg']??0)+1; } }
arsort($neg); arsort($pos); uasort($prod,fn($a,$b)=>($b['neg']??0)<=>($a['neg']??0)); $J=fn($x)=>json_encode($x,JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT);
admin_head('Sentiment analytics'); ?>
<form class="card filters2"><label>From <input type="date" name="from" value="<?= e($from) ?>"></label><label>To <input type="date" name="to" value="<?= e($to) ?>"></label><button class="btn">Apply</button></form>
<p>Sentiment is worked out with simple keyword rules (English and common Bangla words) plus the star rating. It is a guide, not a verdict. Hidden reviews are excluded.</p>
<div class="stats"><div class="stat"><span>Total reviews</span><b><?= $n ?></b></div><div class="stat"><span>Positive</span><b><?= $cnt['positive'] ?></b></div><div class="stat"><span>Neutral</span><b><?= $cnt['neutral'] ?></b></div><div class="stat"><span>Negative</span><b><?= $cnt['negative'] ?></b></div><div class="stat"><span>Average rating</span><b><?= $n?number_format($sum/$n,1):'-' ?></b></div></div>
<?php if($un): ?><form method="post" class="card"><?= csrf_field() ?><p><?= $un ?> review(s) have not been analysed yet.</p><button class="btn">Analyse all reviews now</button></form><?php endif; ?>
<?php foreach($neg as $t=>$c) if($c>=3||($n>=5&&$c/$n>=.2)) echo '<p class="note bad">Recurring issue: <b>'.e(SENT_NEG_LABEL[$t]??$t).'</b> appears in '.$c.' review(s) in this period.</p>'; ?>
<div class="two"><div class="card"><h3>Sentiment</h3><div class="chartbox"><canvas id="c1"></canvas></div></div><div class="card"><h3>Rating distribution</h3><div class="chartbox"><canvas id="c2"></canvas></div></div></div>
<div class="two"><div class="card"><h3>Common complaints</h3><div class="chartbox"><canvas id="c3"></canvas></div></div><div class="card"><h3>Frequently praised</h3><div class="chartbox"><canvas id="c4"></canvas></div></div></div>
<div class="card scroll"><h3>Most complained-about food</h3><table><tr><th>Food</th><th>Reviews</th><th>Negative</th><th>Main complaints</th></tr><?php $k=0; foreach($prod as $name=>$x){ if(empty($x['neg'])&&empty($x['t'])) continue; if(++$k>10) break; $tt=$x['t']??[]; arsort($tt); ?><tr><td><?= e($name) ?></td><td><?= (int)$x['n'] ?></td><td><?= (int)($x['neg']??0) ?></td><td><?= e(implode(', ',array_map(fn($t)=>SENT_NEG_LABEL[$t]??$t,array_slice(array_keys($tt),0,3)))) ?></td></tr><?php } if(!$k) echo '<tr><td colspan="4">No complaints found.</td></tr>'; ?></table></div>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.js"></script><script src="../assets/js/admin-charts.js"></script>
<script>
mk('c1','doughnut',['Positive','Neutral','Negative'],<?= $J(array_values($cnt)) ?>,'Reviews',null,['#A9B98A','#E6C98F','#E8873F']);
mk('c2','bar',['1★','2★','3★','4★','5★'],<?= $J(array_values($dist)) ?>,'Reviews');
mk('c3','bar',<?= $J(array_map(fn($t)=>SENT_NEG_LABEL[$t]??$t,array_keys($neg))) ?>,<?= $J(array_values($neg)) ?>,'Mentions',{indexAxis:'y'});
mk('c4','bar',<?= $J(array_map(fn($t)=>SENT_POS_LABEL[$t]??$t,array_keys($pos))) ?>,<?= $J(array_values($pos)) ?>,'Mentions',{indexAxis:'y'});
</script>
<?php admin_foot();
