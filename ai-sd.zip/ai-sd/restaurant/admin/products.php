<?php
require 'layout.php'; admin_require(); $pdo=db(); $err=[];
$cats=$pdo->query('SELECT id,name FROM categories ORDER BY sort_order')->fetchAll();
if($_SERVER['REQUEST_METHOD']==='POST' && csrf_check()){
  $id=(int)($_POST['id']??0);
  if(($_POST['act']??'')==='delete'){
    $old=$pdo->prepare('SELECT image FROM products WHERE id=?'); $old->execute([$id]); $img=$old->fetchColumn();
    $pdo->prepare('DELETE FROM products WHERE id=?')->execute([$id]); if($img) @unlink(__DIR__.'/../uploads/products/'.basename($img));
    flash('Food item deleted.'); header('Location: products.php'); exit;
  }
  $d=['name'=>trim($_POST['name']??''),'cat'=>(int)($_POST['category_id']??0),'desc'=>trim($_POST['description']??''),'ing'=>trim($_POST['ingredients']??''),
      'price'=>(float)($_POST['price']??0),'disc'=>($_POST['discount_price']??'')===''?null:(float)$_POST['discount_price']];
  if($d['name']==='') $err[]='Enter a name.'; if($d['price']<=0) $err[]='Enter a price above 0.';
  if($d['disc']!==null && ($d['disc']<=0||$d['disc']>=$d['price'])) $err[]='Discount price must be above 0 and below the price.';
  if(!in_array($d['cat'],array_column($cats,'id'))) $err[]='Choose a category.';
  $old=null; if($id){ $o=$pdo->prepare('SELECT image FROM products WHERE id=?'); $o->execute([$id]); $old=$o->fetchColumn()?:null; }
  $img=upload_image($_FILES['image']??null,$err,$old);
  if(!$err){
    $f=[isset($_POST['is_available'])?1:0,isset($_POST['is_featured'])?1:0,isset($_POST['is_popular'])?1:0];
    $vals=[$d['cat'],$d['name'],$d['desc'],$d['ing'],$d['price'],$d['disc'],$img,...$f];
    if($id) $pdo->prepare('UPDATE products SET category_id=?,name=?,description=?,ingredients=?,price=?,discount_price=?,image=?,is_available=?,is_featured=?,is_popular=? WHERE id=?')->execute([...$vals,$id]);
    else $pdo->prepare('INSERT INTO products(category_id,name,description,ingredients,price,discount_price,image,is_available,is_featured,is_popular) VALUES(?,?,?,?,?,?,?,?,?,?)')->execute($vals);
    flash($id?'Food item updated.':'Food item added.'); header('Location: products.php'); exit;
  }
}
$edit=null; if(isset($_GET['edit'])){ $s=$pdo->prepare('SELECT * FROM products WHERE id=?'); $s->execute([(int)$_GET['edit']]); $edit=$s->fetch()?:null; }
$list=$pdo->query('SELECT p.*,c.name cat FROM products p JOIN categories c ON c.id=p.category_id ORDER BY p.id DESC')->fetchAll();
$x=$edit??[]; admin_head('Food items'); foreach($err as $m) echo '<p class="note bad">'.e($m).'</p>'; ?>
<form method="post" enctype="multipart/form-data" class="card form"><h3><?= $edit?'Edit food item':'Add food item' ?></h3><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)($x['id']??0) ?>">
<div class="cols"><label>Name<input name="name" value="<?= e($x['name']??'') ?>" required></label>
<label>Category<select name="category_id"><?php foreach($cats as $c): ?><option value="<?= $c['id'] ?>" <?= ($x['category_id']??0)==$c['id']?'selected':'' ?>><?= e($c['name']) ?></option><?php endforeach; ?></select></label>
<label>Price (৳)<input type="number" step="0.01" name="price" value="<?= e($x['price']??'') ?>" required></label>
<label>Discount price (optional)<input type="number" step="0.01" name="discount_price" value="<?= e($x['discount_price']??'') ?>"></label></div>
<label>Description<textarea name="description" rows="2"><?= e($x['description']??'') ?></textarea></label>
<label>Ingredients<textarea name="ingredients" rows="2"><?= e($x['ingredients']??'') ?></textarea></label>
<label>Image (JPG, PNG, WebP, max 3 MB)<input type="file" name="image" accept="image/jpeg,image/png,image/webp"></label>
<div class="checks"><label><input type="checkbox" name="is_available" <?= ($x['is_available']??1)?'checked':'' ?>> Available</label><label><input type="checkbox" name="is_featured" <?= !empty($x['is_featured'])?'checked':'' ?>> Featured</label><label><input type="checkbox" name="is_popular" <?= !empty($x['is_popular'])?'checked':'' ?>> Popular</label></div>
<div><button class="btn">Save food item</button> <?php if($edit): ?><a href="products.php">Cancel</a><?php endif; ?></div></form>
<div class="card scroll"><table><tr><th></th><th>Name</th><th>Category</th><th>Price</th><th>Status</th><th></th></tr>
<?php foreach($list as $p): ?><tr><td><img class="thumb" src="../<?= product_img($p['image']) ?>" alt=""></td><td><?= e($p['name']) ?></td><td><?= e($p['cat']) ?></td>
<td><?= money(price_now($p)) ?></td><td><?= $p['is_available']?'Available':'Unavailable' ?><?= $p['is_featured']?' · Featured':'' ?></td>
<td><a href="?edit=<?= $p['id'] ?>">Edit</a><form method="post" class="inline" onsubmit="return confirm('Delete this food item?')"><?= csrf_field() ?><input type="hidden" name="act" value="delete"><input type="hidden" name="id" value="<?= $p['id'] ?>"><button class="link bad">Delete</button></form></td></tr><?php endforeach; ?></table></div>
<?php admin_foot();
