<div class="topbar" id="nb">
  <button class="nb-btn" id="nb-btn" type="button" aria-label="Notifications" aria-expanded="false" aria-controls="nb-panel">
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.7 21a2 2 0 0 1-3.4 0"/></svg>
    <span class="nb-badge" id="nb-badge" hidden>0</span>
  </button>
  <div class="nb-panel" id="nb-panel" role="dialog" aria-label="Notifications">
    <div class="nb-head"><b>Notifications</b><span><button class="link" id="nb-mute" type="button">Sound on</button> <button class="link" id="nb-readall" type="button">Mark all read</button></span></div>
    <div class="nb-list" id="nb-list"></div>
    <a class="nb-foot" href="notifications.php">View all notifications</a>
  </div>
</div>
