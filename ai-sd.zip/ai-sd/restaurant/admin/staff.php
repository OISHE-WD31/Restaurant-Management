<?php
require 'layout.php'; admin_require(['owner']); $pdo=db(); $me=(int)$_SESSION['admin_id']; $err=[]; $roles=['owner'=>'Owner','manager'=>'Manager','kitchen'=>'Kitchen'];
if($_SERVER['REQUEST_METHOD']==='POST' && csrf_check()){
  $act=$_POST['act']??''; $id=(int)($_POST['id']??0);
  if($act==='add'){ $n=trim($_POST['name']??''); $em=trim($_POST['email']??''); $pw=$_POST['password']??''; $ro=$_POST['role']??'';
    if($n==='') $err[]='Enter a name.'; if(!filter_var($em,FILTER_VALIDATE_EMAIL)) $err[]='Enter a valid email.'; if(strlen($pw)<10) $err[]='Password must be at least 10 characters.'; if(!isset($roles[$ro])) $err[]='Choose a role.';
    if(!$err){ try{ $pdo->prepare('INSERT INTO admins(name,email,password_hash,role) VALUES(?,?,?,?)')->execute([$n,$em,password_hash($pw,PASSWORD_DEFAULT),$ro]); flash('Staff account created.'); }catch(PDOException $e){ $err[]='That email is already used.'; } } }
  elseif($act==='role' && $id!==$me && isset($roles[$_POST['role']??''])){ $pdo->prepare('UPDATE admins SET role=? WHERE id=?')->execute([$_POST['role'],$id]); flash('Role updated. It applies at their next login.'); }
  elseif($act==='delete' && $id!==$me){ $pdo->prepare('DELETE FROM admins WHERE id=?')->execute([$id]); flash('Account removed.'); }
  if(!$err){ header('Location: staff.php'); exit; }
}
$list=$pdo->query('SELECT id,name,email,role,created_at FROM admins ORDER BY id')->fetchAll(); admin_head('Staff & roles'); foreach($err as $m) echo '<p class="note bad">'.e($m).'</p>'; ?>
<p>Owner: everything. Manager: everything except staff. Kitchen: kitchen display only (available in a later phase).</p>
<form method="post" class="card form"><h3>Add staff</h3><?= csrf_field() ?><input type="hidden" name="act" value="add"><div class="cols"><label>Name<input name="name" required></label><label>Email<input type="email" name="email" required></label><label>Password (10+)<input type="password" name="password" minlength="10" required></label>
<label>Role<select name="role"><?php foreach($roles as $k=>$l): ?><option value="<?= $k ?>"><?= $l ?></option><?php endforeach; ?></select></label></div><div><button class="btn">Create account</button></div></form>
<div class="card scroll"><table><tr><th>Name</th><th>Email</th><th>Role</th><th></th></tr><?php foreach($list as $a): ?><tr><td><?= e($a['name']) ?></td><td><?= e($a['email']) ?></td><td><?= e($roles[$a['role']]??$a['role']) ?></td><td>
<?php if((int)$a['id']!==$me): ?><form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $a['id'] ?>"><select name="role"><?php foreach($roles as $k=>$l): ?><option value="<?= $k ?>" <?= $a['role']===$k?'selected':'' ?>><?= $l ?></option><?php endforeach; ?></select> <button class="link" name="act" value="role">Change</button><button class="link bad" name="act" value="delete" onclick="return confirm('Remove this account?')">Remove</button></form><?php else: ?>You<?php endif; ?></td></tr><?php endforeach; ?></table></div>
<?php admin_foot();
