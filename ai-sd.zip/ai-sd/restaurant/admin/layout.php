<?php
require_once __DIR__.'/../includes/functions.php';
function admin_role(): string {
    if(empty($_SESSION['admin_role'])){ try{ $s=db()->prepare('SELECT role FROM admins WHERE id=?'); $s->execute([$_SESSION['admin_id']??0]); $_SESSION['admin_role']=$s->fetchColumn()?:'owner'; }catch(Throwable $e){ return 'owner'; } }
    return $_SESSION['admin_role'];
}
function admin_require(array $roles=['owner','manager']): void {
    if(empty($_SESSION['admin_id'])){ header('Location: index.php'); exit; }
    if(!in_array(admin_role(),$roles,true)){ http_response_code(403); exit('<!doctype html><meta charset="utf-8"><body style="font-family:sans-serif;padding:40px"><h2>No access</h2><p>'.(admin_role()==='kitchen'?'Your kitchen account can only open the kitchen display. Please ask the owner or manager if you need anything else.':'Your account role cannot open this page.').'</p><a href="logout.php">Log out</a></body>'); }
}
function flash(?string $m=null): ?string { if($m!==null){ $_SESSION['flash']=$m; return null; } $f=$_SESSION['flash']??null; unset($_SESSION['flash']); return $f; }
function upload_image(?array $f, array &$err, ?string $old=null): ?string {
    if(!$f || $f['error']===UPLOAD_ERR_NO_FILE) return $old;
    if($f['error']!==UPLOAD_ERR_OK || $f['size']>3*1024*1024){ $err[]='Image upload failed or is larger than 3 MB.'; return $old; }
    $mime=(new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
    $ext=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'][$mime]??null;
    if(!$ext){ $err[]='Only JPG, PNG or WebP images are allowed.'; return $old; }
    $name=bin2hex(random_bytes(10)).'.'.$ext;
    if(!move_uploaded_file($f['tmp_name'],__DIR__.'/../uploads/products/'.$name)){ $err[]='Could not save the image. Check folder permissions.'; return $old; }
    if($old) @unlink(__DIR__.'/../uploads/products/'.basename($old));
    return $name;
}
function bars(array $data): void { $max=max($data?:[0])?:1; echo '<div class="bars">';
    foreach($data as $l=>$v) echo '<div class="bar"><div class="col"><i style="height:'.max(1,round($v/$max*100)).'%"></i></div><span>'.e($l).'</span><b>'.e(money($v)).'</b></div>'; echo '</div>'; }
function admin_icon(string $k): string {
    static $i=[
        'overview'=>'<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/>',
        'menu'=>'<path d="M4 4h12a4 4 0 0 1 4 4v12H8a4 4 0 0 1-4-4z"/><path d="M8 9h8M8 13h6"/>',
        'orders'=>'<path d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><path d="M3 6h18"/><path d="M16 10a4 4 0 0 1-8 0"/>',
        'reservations'=>'<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>',
        'inventory'=>'<path d="M21 8 12 3 3 8v8l9 5 9-5z"/><path d="m3 8 9 5 9-5M12 13v8"/>',
        'customers'=>'<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8"/>',
        'finance'=>'<path d="M3 3v18h18"/><path d="m7 15 4-4 3 3 5-6"/>',
        'admin'=>'<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>',
        'site'=>'<path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><path d="M15 3h6v6M10 14 21 3"/>',
        'logout'=>'<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="m16 17 5-5-5-5M21 12H9"/>',
        'chev'=>'<path d="m6 9 6 6 6-6"/>',
    ];
    return '<svg class="ico" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">'.($i[$k]??'').'</svg>';
}
/* Single source of truth for the admin sidebar. Visibility rules are identical to the previous flat menu:
   Staff & roles is owner-only, and the kitchen role only ever sees the kitchen display link. */
function admin_menu(): array {
    $role=admin_role();
    $groups=[
        ['key'=>'overview','label'=>'Overview','items'=>[['dashboard','Overview']]],
        ['key'=>'menu','label'=>'Menu Management','items'=>[['products','Food items'],['categories','Categories'],['coupons','Coupons']]],
        ['key'=>'orders','label'=>'Order Management','items'=>[['orders','Orders'],['kiosk-orders','Kiosk orders'],['kitchen','Kitchen display (KDS)'],['kitchen-activity','Kitchen activity']]],
        ['key'=>'reservations','label'=>'Reservation & Tables','items'=>[['reservations','Reservations'],['reservation-notifications','Reservation alerts'],['tables','Table management']]],
        ['key'=>'inventory','label'=>'Inventory & Kitchen','items'=>[['inventory','Inventory'],['ingredients','Ingredients'],['recipes','Recipes']]],
        ['key'=>'customers','label'=>'Customer Management','items'=>[['customers','Customers'],['loyalty','Customer loyalty'],['reviews','Reviews'],['sentiment','Sentiment analytics'],['messages','Messages']]],
        ['key'=>'finance','label'=>'Finance & Reports','items'=>[['payments','Payments'],['payment-reports','Payment Reports'],['sales','Sales & Revenue'],['reports','Reports']]],
        ['key'=>'admin','label'=>'Administration','items'=>[['staff','Staff & roles'],['notifications','Notifications'],['settings','Website settings'],['profile','My profile']]],
    ];
    $out=[];
    foreach($groups as $g){
        $g['items']=array_values(array_filter($g['items'],function($it) use($role){
            [$f]=$it;
            if($f==='staff'&&$role!=='owner') return false;
            if($role==='kitchen'&&$f!=='kitchen') return false;
            return true;
        }));
        if($g['items']) $out[]=$g;
    }
    return $out;
}
function admin_sidebar(string $p): void {
    echo '<nav class="side-nav" aria-label="Admin navigation">';
    foreach(admin_menu() as $g){
        if($g['key']==='overview'){   // a one-item group is a plain link, not a collapsible
            $f=$g['items'][0][0];
            echo '<a href="'.e($f).'.php" class="side-top'.($p===$f?' on':'').'"'.($p===$f?' aria-current="page"':'').'>'.admin_icon('overview').'<span>'.e($g['items'][0][1]).'</span></a>';
            continue;
        }
        $active=false; foreach($g['items'] as $it) if($it[0]===$p) $active=true;
        $id='sg-'.$g['key'];
        echo '<div class="side-group'.($active?' open has-active':'').'">'
            .'<button type="button" class="side-parent" aria-expanded="'.($active?'true':'false').'" aria-controls="'.$id.'">'.admin_icon($g['key']).'<span>'.e($g['label']).'</span>'.str_replace('class="ico"','class="chev"',admin_icon('chev')).'</button>'
            .'<div class="side-sub" id="'.$id.'"><ul>';
        foreach($g['items'] as [$f,$l]) echo '<li><a href="'.e($f).'.php" class="'.($p===$f?'on':'').'"'.($p===$f?' aria-current="page"':'').'>'.e($l).'</a></li>';
        echo '</ul></div></div>';
    }
    echo '</nav>';
}
function admin_head(string $title): void { $p=basename($_SERVER['SCRIPT_NAME'],'.php'); ?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= e($title) ?> · Admin</title>
<link href="https://fonts.googleapis.com/css2?family=Fraunces:wght@600&family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="../assets/css/admin.css?v=<?= (int)@filemtime(__DIR__.'/../assets/css/admin.css') ?>"><meta name="csrf" content="<?= csrf_token() ?>"><script src="../assets/js/admin-notify.js" defer></script><script src="../assets/js/admin-sidebar.js?v=<?= (int)@filemtime(__DIR__.'/../assets/js/admin-sidebar.js') ?>" defer></script></head><body>
<input type="checkbox" id="sb" hidden><label for="sb" class="sb-toggle">Menu</label>
<aside class="side"><h2><?= e(setting('restaurant_name')) ?></h2>
<?php admin_sidebar($p); ?>
<div class="side-foot"><a href="../index.php" target="_blank" rel="noopener"><?= admin_icon('site') ?><span>View website</span></a><a href="logout.php"><?= admin_icon('logout') ?><span>Log out</span></a></div></aside>
<label for="sb" class="sb-overlay" aria-hidden="true"></label>
<main class="main"><?php include __DIR__."/notification-bell.php"; ?><h1><?= e($title) ?></h1>
<?php if($m=flash()): ?><p class="note"><?= e($m) ?></p><?php endif; }
function admin_foot(): void { echo '</main></body></html>'; }
