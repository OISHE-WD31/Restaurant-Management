<?php
require 'layout.php'; admin_require(['owner','manager','kitchen']); $role=admin_role();
?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Kitchen display</title>
<meta name="csrf" content="<?= csrf_token() ?>"><link href="https://fonts.googleapis.com/css2?family=Fraunces:wght@600&family=Nunito:wght@400;700&display=swap" rel="stylesheet">
<style>
:root{--cream:#FBF3E1;--sage:#A9B98A;--sage-l:#DCE3C4;--brown:#4A2F18;--orange:#E8873F}
*{box-sizing:border-box}body{margin:0;background:var(--brown);color:var(--cream);font:400 1rem/1.4 Nunito,sans-serif}
header{display:flex;flex-wrap:wrap;gap:12px;align-items:center;justify-content:space-between;padding:12px 18px;background:#33200f}
h1{font:600 1.4rem Fraunces,serif;margin:0}header a,header button{color:var(--cream);background:none;border:1px solid #8a6a4a;border-radius:999px;padding:6px 14px;font:inherit;cursor:pointer;text-decoration:none}
.board{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;padding:12px;align-items:start}
.col h2{font:600 1.1rem Fraunces,serif;margin:4px 6px 10px}.col h2 span{background:var(--orange);color:#fff;border-radius:999px;padding:1px 10px;font:700 .85rem Nunito}
.k-card{background:var(--cream);color:var(--brown);border-radius:20px;padding:14px;margin-bottom:12px;border-left:10px solid var(--sage)}
.k-card[data-lvl=warn]{border-left-color:#e0b43a}.k-card[data-lvl=late]{border-left-color:#d93025;animation:pulse 1.2s infinite}
@keyframes pulse{50%{box-shadow:0 0 0 4px rgba(217,48,37,.45)}}
.k-top{display:flex;justify-content:space-between;align-items:baseline}.k-top b{font-size:1.25rem}.k-time{font:700 1.1rem Nunito}
.k-tag{display:inline-block;background:var(--sage-l);border-radius:999px;padding:1px 10px;font-size:.8rem;font-weight:700;margin:4px 4px 8px 0}
.k-items{list-style:none;margin:0 0 8px;padding:0;font-size:1.1rem}.k-items li{padding:3px 0;border-bottom:1px dashed #d8c9a4}.k-items b{color:var(--orange)}
.k-note{background:#FFF1B8;border-radius:12px;padding:6px 10px;margin-bottom:8px;font-weight:700}
.k-go{width:100%;min-height:52px;border:0;border-radius:16px;background:var(--orange);color:#fff;font:700 1.05rem Nunito;cursor:pointer}.k-go:disabled{opacity:.5}
.empty{opacity:.55;padding:10px 6px}#toast{position:fixed;bottom:18px;left:50%;transform:translateX(-50%);background:#fff;color:var(--brown);padding:12px 22px;border-radius:999px;font-weight:700;display:none;max-width:92vw;z-index:9}
@media(max-width:1000px){.board{grid-template-columns:repeat(2,1fr)}}@media(max-width:600px){.board{grid-template-columns:1fr}}
</style></head><body>
<header><h1>Kitchen display</h1><span id="clock"></span><span><button id="mute" type="button">Sound on</button> <?php if($role!=='kitchen'): ?><a href="dashboard.php">Dashboard</a> <?php endif; ?><a href="logout.php">Log out</a></span></header>
<div class="board" id="board"></div><div id="toast" role="status"></div>
<script>
const API='kitchen-api.php',csrf=document.querySelector('meta[name=csrf]').content,COLS=[['pending','New orders'],['confirmed','Accepted'],['preparing','Preparing'],['ready','Ready']];
const SRC={website:'Website',kiosk:'Kiosk',admin:'Staff'},TYP={delivery:'Delivery',takeaway:'Takeaway',dine_in:'Dine-in'};
let data=null,at=0,seen=null,muted=localStorage.getItem('kdsMuted')==='1',ctx=null,busy=false;
const mk=(t,c,x)=>{const n=document.createElement(t);if(c)n.className=c;if(x!==undefined)n.textContent=x;return n};
document.addEventListener('click',()=>{try{ctx=ctx||new (window.AudioContext||window.webkitAudioContext)();ctx.resume()}catch(e){}},{once:true});
function beep(){if(muted||!ctx||ctx.state!=='running')return;const t=ctx.currentTime;[784,988,1175].forEach((f,i)=>{const o=ctx.createOscillator(),g=ctx.createGain();o.frequency.value=f;o.connect(g);g.connect(ctx.destination);g.gain.setValueAtTime(.0001,t+i*.14);g.gain.exponentialRampToValueAtTime(.2,t+i*.14+.02);g.gain.exponentialRampToValueAtTime(.0001,t+i*.14+.22);o.start(t+i*.14);o.stop(t+i*.14+.25)})}
const label=o=>o.status==='pending'?'Accept order':o.status==='confirmed'?'Start preparing':o.status==='preparing'?'Mark ready':(o.type==='delivery'?'Out for delivery':'Complete');
const toast=m=>{const t=document.getElementById('toast');t.textContent=m;t.style.display='block';clearTimeout(toast.h);toast.h=setTimeout(()=>t.style.display='none',4500)};
const fmt=s=>Math.floor(s/60)+':'+String(s%60).padStart(2,'0');
function render(){
  const b=document.getElementById('board');b.replaceChildren();
  COLS.forEach(([st,title])=>{const list=data.orders.filter(o=>o.status===st),col=mk('div','col'),h=mk('h2','',title+' ');h.append(mk('span','',list.length));col.append(h);
    if(!list.length)col.append(mk('div','empty','Nothing here'));
    list.forEach(o=>{const c=mk('div','k-card');c.dataset.wait=o.wait;
      const top=mk('div','k-top');top.append(mk('b','',o.no),mk('span','k-time',fmt(o.wait)));
      const tags=mk('div');tags.append(mk('span','k-tag',(SRC[o.source]||o.source)+' · '+(TYP[o.type]||o.type)));if(o.table)tags.append(mk('span','k-tag','Table '+o.table));
      const ul=mk('ul','k-items');o.items.forEach(i=>{const li=mk('li');li.append(mk('b','',i.qty+' × '),document.createTextNode(i.name));ul.append(li)});
      c.append(top,tags,ul);if(o.notes)c.append(mk('div','k-note','Note: '+o.notes));
      const g=mk('button','k-go',label(o));g.onclick=()=>advance(o,g);c.append(g);col.append(c)});
    b.append(col)});tick();
}
function tick(){if(!data)return;const el=(Date.now()-at)/1000;document.querySelectorAll('.k-card').forEach(c=>{const s=Math.floor(+c.dataset.wait+el);c.querySelector('.k-time').textContent=fmt(s);c.dataset.lvl=s>=data.late*60?'late':s>=data.warn*60?'warn':''});
  document.getElementById('clock').textContent=new Date().toLocaleTimeString()}
function apply(d){if(!d||!d.ok)return;data=d;at=Date.now();const ids=d.orders.filter(o=>o.status==='pending').map(o=>o.id);
  if(seen!==null&&ids.some(i=>!seen.has(i)))beep();seen=new Set(ids);render();if(d.msg)toast(d.msg)}
async function call(opts){if(busy)return;busy=true;try{const r=await fetch(API,opts);if(r.status===401||r.status===403){location.href='index.php';return}apply(await r.json())}catch(e){}busy=false}
function advance(o,btn){btn.disabled=true;call({method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded','X-CSRF':csrf},body:new URLSearchParams({id:o.id,from:o.status})})}
const m=document.getElementById('mute');const lab=()=>m.textContent=muted?'Sound off':'Sound on';lab();m.onclick=()=>{muted=!muted;localStorage.setItem('kdsMuted',muted?'1':'0');lab()};
call();setInterval(()=>{if(!document.hidden)call()},4000);setInterval(tick,1000);
</script></body></html>
