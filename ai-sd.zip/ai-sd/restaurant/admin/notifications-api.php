<?php
require __DIR__.'/../includes/functions.php';
header('Content-Type: application/json'); header('Cache-Control: no-store');
if(empty($_SESSION['admin_id'])){ http_response_code(401); exit(json_encode(['ok'=>false,'error'=>'auth'])); }
$aid=(int)$_SESSION['admin_id'];
if($_SERVER['REQUEST_METHOD']==='POST'){
    if(!hash_equals($_SESSION['csrf']??'',$_SERVER['HTTP_X_CSRF']??'')){ http_response_code(403); exit(json_encode(['ok'=>false,'error'=>'csrf'])); }
    notif_action($aid,(string)($_POST['action']??''),(int)($_POST['id']??0));
}
session_write_close(); // polling must not block other admin requests
try{ echo json_encode(notif_payload($aid)); }
catch(Throwable $e){ error_log($e->getMessage()); http_response_code(500); echo json_encode(['ok'=>false,'error'=>'server']); }
