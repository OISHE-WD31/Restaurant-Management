<?php
require 'layout.php'; admin_require(); $pdo=db(); $err=[]; $units=['kg','g','l','ml','piece','packet'];
if($_SERVER['REQUEST_METHOD']==='POST' && csrf_check()){
  $act=$_POST['act']??''; $id=(int)($_POST['id']??0);
  try{
    if($act==='supplier'){ $n=trim($_POST['sname']??''); if($n==='') $err[]='Enter a supplier name.'; else{ $pdo->prepare('INSERT INTO suppliers(name,phone) VALUES(?,?)')->execute([$n,trim($_POST['sphone']??'')]); flash('Supplier added.'); } }
    elseif($act==='delete'){
      $u=$pdo->prepare("SELECT (SELECT COUNT(*) FROM recipe_ingredients WHERE ingredient_id=?)+(SELECT COUNT(*) FROM inventory_movements WHERE ingredient_id=? AND order_id IS NOT NULL)+(SELECT stock>0 FROM ingredients WHERE id=?)"); $u->execute([$id,$id,$id]);
      if((int)$u->fetchColumn()>0) flash('Cannot delete: it is used in a recipe, has order history, or still has stock.'); else{ $pdo->prepare('DELETE FROM ingredients WHERE id=?')->execute([$id]); flash('Ingredient deleted.'); } }
    else{
      $n=trim($_POST['name']??''); $u=$_POST['unit']??''; $min=(float)($_POST['min_stock']??0); $cost=(float)($_POST['unit_cost']??0); $sup=(int)($_POST['supplier_id']??0)?:null; $open=(float)($_POST['stock']??0);
      if($n===''||mb_strlen($n)>120) $err[]='Enter an ingredient name.'; if(!in_array($u,$units,true)) $err[]='Choose a unit.'; if($min<0||$cost<0||$open<0) $err[]='Numbers cannot be negative.';
      if(!$err && $id){ $cur=$pdo->prepare('SELECT unit,stock FROM ingredients WHERE id=?'); $cur->execute([$id]); $cur=$cur->fetch();
        if($cur && $cur['unit']!==$u){
          $mv=$pdo->prepare('SELECT COUNT(*) FROM inventory_movements WHERE ingredient_id=?'); $mv->execute([$id]);
          if((float)$cur['stock']!==0.0 || (int)$mv->fetchColumn()>0) $err[]='The unit cannot be changed once an ingredient has stock or history, because its quantities would be misread. Create a new ingredient with the new unit instead.';
          else{ $ru=$pdo->prepare('SELECT unit FROM recipe_ingredients WHERE ingredient_id=?'); $ru->execute([$id]);
            foreach($ru->fetchAll(PDO::FETCH_COLUMN) as $rUnit) if(unit_convert(1,$rUnit,$u)===null){ $err[]='A recipe uses this ingredient in a unit that cannot be converted to '.$u.'. Fix the recipes first.'; break; } } } }
      if(!$err){ $pdo->beginTransaction();
        if($id) $pdo->prepare('UPDATE ingredients SET name=?,unit=?,min_stock=?,unit_cost=?,supplier_id=? WHERE id=?')->execute([$n,$u,$min,$cost,$sup,$id]);
        else{ $pdo->prepare('INSERT INTO ingredients(name,unit,min_stock,unit_cost,supplier_id) VALUES(?,?,?,?,?)')->execute([$n,$u,$min,$cost,$sup]); if($open>0) stock_apply($pdo,(int)$pdo->lastInsertId(),$open,'adjustment',null,'Opening stock',(int)$_SESSION['admin_id']); }
        $pdo->commit(); flash('Ingredient saved.'); }
    }
  }catch(PDOException $e){ if($pdo->inTransaction()) $pdo->rollBack(); $err[]='That name already exists or the data is invalid.'; }
  if(!$err){ header('Location: ingredients.php'); exit; }
}
$edit=null; if(isset($_GET['edit'])){ $s=$pdo->prepare('SELECT * FROM ingredients WHERE id=?'); $s->execute([(int)$_GET['edit']]); $edit=$s->fetch()?:null; } $x=$edit??[];
$sups=$pdo->query('SELECT * FROM suppliers ORDER BY name')->fetchAll(); $rows=$pdo->query('SELECT i.*,s.name sname FROM ingredients i LEFT JOIN suppliers s ON s.id=i.supplier_id ORDER BY i.name')->fetchAll();
admin_head('Ingredients'); foreach($err as $m) echo '<p class="note bad">'.e($m).'</p>'; ?>
<form method="post" class="card form"><h3><?= $edit?'Edit ingredient':'Add ingredient' ?></h3><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)($x['id']??0) ?>"><div class="cols">
<label>Name<input name="name" value="<?= e($x['name']??'') ?>" required></label><label>Unit<select name="unit"><?php foreach($units as $u): ?><option <?= ($x['unit']??'kg')===$u?'selected':'' ?>><?= $u ?></option><?php endforeach; ?></select></label>
<?php if(!$edit): ?><label>Opening stock<input type="number" step="0.001" min="0" name="stock" value="0"></label><?php endif; ?>
<label>Minimum stock<input type="number" step="0.001" min="0" name="min_stock" value="<?= e($x['min_stock']??0) ?>"></label><label>Purchase price per unit (৳)<input type="number" step="0.0001" min="0" name="unit_cost" value="<?= e($x['unit_cost']??0) ?>"></label>
<label>Supplier<select name="supplier_id"><option value="0">None</option><?php foreach($sups as $s): ?><option value="<?= $s['id'] ?>" <?= (int)($x['supplier_id']??0)===(int)$s['id']?'selected':'' ?>><?= e($s['name']) ?></option><?php endforeach; ?></select></label></div>
<div><button class="btn">Save ingredient</button> <?php if($edit): ?><a href="ingredients.php">Cancel</a><?php endif; ?></div><?php if($edit): ?><small>To change stock use Inventory (purchase, adjustment or wastage) so history stays accurate.</small><?php endif; ?></form>
<form method="post" class="card filters2"><?= csrf_field() ?><input type="hidden" name="act" value="supplier"><input name="sname" placeholder="New supplier name" required><input name="sphone" placeholder="Phone"><button class="btn">Add supplier</button></form>
<div class="card scroll"><table><tr><th>Ingredient</th><th>Stock</th><th>Minimum</th><th>Price/unit</th><th>Supplier</th><th></th></tr><?php foreach($rows as $r): ?><tr><td><?= e($r['name']) ?></td><td><?= fmt_qty($r['stock']) ?> <?= e($r['unit']) ?></td><td><?= fmt_qty($r['min_stock']) ?></td><td><?= money($r['unit_cost']) ?></td><td><?= e($r['sname']??'') ?></td>
<td><a href="?edit=<?= $r['id'] ?>">Edit</a><form method="post" class="inline" onsubmit="return confirm('Delete this ingredient?')"><?= csrf_field() ?><input type="hidden" name="act" value="delete"><input type="hidden" name="id" value="<?= $r['id'] ?>"><button class="link bad">Delete</button></form></td></tr><?php endforeach; ?></table></div>
<?php admin_foot();
