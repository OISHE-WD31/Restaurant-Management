<?php
require 'layout.php'; admin_require(); $pdo=db();
if($_SERVER['REQUEST_METHOD']==='POST' && csrf_check()){ $pdo->prepare('UPDATE customers SET is_active=1-is_active WHERE id=?')->execute([(int)$_POST['id']]); flash('Account status changed.'); header('Location: customers.php'); exit; }
if(isset($_GET['view'])){
  $c=$pdo->prepare('SELECT * FROM customers WHERE id=?'); $c->execute([(int)$_GET['view']]); $c=$c->fetch();
  $o=$pdo->prepare('SELECT order_no,total,status,payment_status,created_at FROM orders WHERE customer_id=? ORDER BY id DESC'); $o->execute([(int)$_GET['view']]); $orders=$o->fetchAll();
  admin_head('Customer'); if(!$c){ echo '<p>Customer not found.</p>'; admin_foot(); exit; } ?>
  <div class="card"><h3><?= e($c['name']) ?></h3><p><?= e($c['email']) ?> · <?= e($c['phone']) ?><br><?= e($c['address']) ?><br>Joined <?= e(date('d M Y',strtotime($c['created_at']))) ?> · <?= $c['is_active']?'Active':'Disabled' ?></p></div>
  <div class="card scroll"><table><tr><th>Order</th><th>Total</th><th>Status</th><th>Payment</th><th>Date</th></tr><?php foreach($orders as $r): ?><tr><td><?= e($r['order_no']) ?></td><td><?= money($r['total']) ?></td><td><?= e($r['status']) ?></td><td><?= e($r['payment_status']) ?></td><td><?= e($r['created_at']) ?></td></tr><?php endforeach; ?></table></div>
  <a href="customers.php">Back to customers</a><?php admin_foot(); exit; }
$q=trim($_GET['q']??'');
$st=$pdo->prepare("SELECT c.*,COUNT(o.id) n,COALESCE(SUM(CASE WHEN o.status<>'cancelled' THEN o.total END),0) spent FROM customers c LEFT JOIN orders o ON o.customer_id=c.id WHERE c.name LIKE ? OR c.email LIKE ? OR c.phone LIKE ? GROUP BY c.id ORDER BY c.id DESC LIMIT 100");
$st->execute(["%$q%","%$q%","%$q%"]); $rows=$st->fetchAll(); admin_head('Customers'); ?>
<form class="card filters2"><input name="q" value="<?= e($q) ?>" placeholder="Name, email or phone"><button class="btn">Search</button></form>
<div class="card scroll"><table><tr><th>Name</th><th>Email</th><th>Orders</th><th>Spent</th><th>Status</th><th></th></tr>
<?php foreach($rows as $c): ?><tr><td><?= e($c['name']) ?></td><td><?= e($c['email']) ?></td><td><?= (int)$c['n'] ?></td><td><?= money($c['spent']) ?></td><td><?= $c['is_active']?'Active':'Disabled' ?></td>
<td><a href="?view=<?= $c['id'] ?>">View</a><form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="id" value="<?= $c['id'] ?>"><button class="link"><?= $c['is_active']?'Disable':'Enable' ?></button></form></td></tr><?php endforeach; ?></table></div>
<?php admin_foot();
