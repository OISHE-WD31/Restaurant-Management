<?php
require 'layout.php'; admin_require(); $pdo=db(); $err=[];
if($_SERVER['REQUEST_METHOD']==='POST' && csrf_check()){
  $act=$_POST['act']??''; $id=(int)($_POST['id']??0);
  if($act==='status'){ $s=$_POST['status']??''; if(in_array($s,['available','occupied','cleaning','unavailable'],true)){ $pdo->prepare('UPDATE restaurant_tables SET status=? WHERE id=?')->execute([$s,$id]); flash('Table status updated.'); } }
  elseif($act==='delete'){ $n=$pdo->prepare('SELECT COUNT(*) FROM table_reservations WHERE table_id=? AND res_date>=CURDATE() AND status IN ('.RES_ACTIVE.')'); $n->execute([$id]);
    if($n->fetchColumn()>0) flash('This table has upcoming reservations. Reassign them or mark the table Unavailable.'); else{ $pdo->prepare('DELETE FROM restaurant_tables WHERE id=?')->execute([$id]); flash('Table deleted.'); } }
  else{
    $no=trim($_POST['table_no']??''); $area=trim($_POST['area']??'')?:'Main hall'; $cap=(int)($_POST['capacity']??0); $st=$_POST['status']??'available';
    if($no===''||mb_strlen($no)>20) $err[]='Enter a table number (up to 20 characters).'; if($cap<1||$cap>30) $err[]='Capacity must be 1 to 30.';
    if(!in_array($st,['available','occupied','cleaning','unavailable'],true)) $st='available';
    if(!$err){ try{
      if($id) $pdo->prepare('UPDATE restaurant_tables SET table_no=?,area=?,capacity=?,status=? WHERE id=?')->execute([$no,$area,$cap,$st,$id]);
      else $pdo->prepare('INSERT INTO restaurant_tables(table_no,area,capacity,status) VALUES(?,?,?,?)')->execute([$no,$area,$cap,$st]);
      flash('Table saved.'); }catch(PDOException $e){ $err[]='A table with this number already exists.'; } }
  }
  if(!$err){ header('Location: tables.php?'.http_build_query(array_intersect_key($_GET,['d'=>1,'t'=>1]))); exit; }
}
$d=preg_match('/^\d{4}-\d{2}-\d{2}$/',$_GET['d']??'')?$_GET['d']:date('Y-m-d'); $t=preg_match('/^([01]\d|2[0-3]):[0-5]\d$/',$_GET['t']??'')?$_GET['t']:date('H:i'); $end=res_hm(min(1439,res_mins($t)+90));
$rs=$pdo->prepare('SELECT * FROM table_reservations WHERE res_date=? AND status IN ('.RES_ACTIVE.') AND start_time<? AND end_time>? ORDER BY start_time'); $rs->execute([$d,$end,$t]); $byTable=[]; foreach($rs->fetchAll() as $r) $byTable[$r['table_id']][]=$r;
$tables=$pdo->query('SELECT * FROM restaurant_tables ORDER BY area,table_no')->fetchAll(); $areas=[]; $state=[];
foreach($tables as $x){ $areas[$x['area']][]=$x; $state[$x['id']]=in_array($x['status'],['occupied','cleaning','unavailable'],true)?$x['status']:(!empty($byTable[$x['id']])?'reserved':'available'); }
$edit=null; if(isset($_GET['edit'])){ $s=$pdo->prepare('SELECT * FROM restaurant_tables WHERE id=?'); $s->execute([(int)$_GET['edit']]); $edit=$s->fetch()?:null; } $x=$edit??[];
admin_head('Table management'); foreach($err as $m) echo '<p class="note bad">'.e($m).'</p>'; ?>
<form class="card filters2"><label>Date <input type="date" name="d" value="<?= e($d) ?>"></label><label>Time <input type="time" name="t" value="<?= e($t) ?>"></label><button class="btn">Show floor plan</button></form>
<p class="legend"><span class="tbl st-available">Available</span> <span class="tbl st-reserved">Reserved</span> <span class="tbl st-occupied">Occupied</span> <span class="tbl st-cleaning">Cleaning</span> <span class="tbl st-unavailable">Unavailable</span></p>
<div class="card"><?php foreach($areas as $a=>$list): ?><h3><?= e($a) ?></h3><div class="plan"><?php foreach($list as $x2): ?><button type="button" class="tbl st-<?= $state[$x2['id']] ?>" data-t="<?= $x2['id'] ?>"><b><?= e($x2['table_no']) ?></b><small><?= (int)$x2['capacity'] ?> seats</small></button><?php endforeach; ?></div><?php endforeach; if(!$tables) echo '<p>No tables yet. Add one below.</p>'; ?></div>
<?php foreach($tables as $x2): ?><div class="card tpanel" id="tp<?= $x2['id'] ?>" hidden><h3>Table <?= e($x2['table_no']) ?> · <?= e($x2['area']) ?> · <?= (int)$x2['capacity'] ?> seats · <?= e(ucfirst($state[$x2['id']])) ?></h3>
<?php foreach($byTable[$x2['id']]??[] as $r): ?><p><b><?= e(substr($r['start_time'],0,5)) ?>–<?= e(substr($r['end_time'],0,5)) ?></b> <?= e($r['name']) ?> · <?= e($r['phone']) ?> · <?= (int)$r['guests'] ?> guests · <?= e($r['status']) ?><?= $r['notes']?' · '.e($r['notes']):'' ?></p><?php endforeach; if(empty($byTable[$x2['id']])) echo '<p>No reservations in this window.</p>'; ?>
<form method="post" class="inline"><?= csrf_field() ?><input type="hidden" name="act" value="status"><input type="hidden" name="id" value="<?= $x2['id'] ?>">
<?php foreach(['available'=>'Set available','occupied'=>'Set occupied','cleaning'=>'Set cleaning','unavailable'=>'Set unavailable'] as $k=>$l): ?><button class="btn" name="status" value="<?= $k ?>"><?= $l ?></button> <?php endforeach; ?></form></div><?php endforeach; ?>
<form method="post" class="card form"><h3><?= $edit?'Edit table':'Add table' ?></h3><?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)($x['id']??0) ?>"><div class="cols">
<label>Table number<input name="table_no" value="<?= e($x['table_no']??'') ?>" required></label><label>Area / section<input name="area" value="<?= e($x['area']??'Main hall') ?>"></label>
<label>Seats<input type="number" name="capacity" min="1" max="30" value="<?= e($x['capacity']??2) ?>" required></label>
<label>Status<select name="status"><?php foreach(['available','occupied','cleaning','unavailable'] as $s): ?><option <?= ($x['status']??'available')===$s?'selected':'' ?>><?= $s ?></option><?php endforeach; ?></select></label></div>
<div><button class="btn">Save table</button> <?php if($edit): ?><a href="tables.php">Cancel</a><?php endif; ?></div></form>
<div class="card scroll"><table><tr><th>Table</th><th>Area</th><th>Seats</th><th>Status</th><th></th></tr><?php foreach($tables as $x2): ?><tr><td><?= e($x2['table_no']) ?></td><td><?= e($x2['area']) ?></td><td><?= (int)$x2['capacity'] ?></td><td><?= e($x2['status']) ?></td>
<td><a href="?edit=<?= $x2['id'] ?>">Edit</a><form method="post" class="inline" onsubmit="return confirm('Delete this table?')"><?= csrf_field() ?><input type="hidden" name="act" value="delete"><input type="hidden" name="id" value="<?= $x2['id'] ?>"><button class="link bad">Delete</button></form></td></tr><?php endforeach; ?></table></div>
<script>document.querySelectorAll('.plan .tbl').forEach(b=>b.onclick=()=>{document.querySelectorAll('.tpanel').forEach(p=>p.hidden=true);const p=document.getElementById('tp'+b.dataset.t);p.hidden=false;p.scrollIntoView({behavior:'smooth',block:'nearest'})})</script>
<?php admin_foot();
