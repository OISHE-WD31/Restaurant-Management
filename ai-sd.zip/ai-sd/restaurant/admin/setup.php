<?php
require __DIR__.'/../includes/functions.php'; $err=[];
$exists=(int)db()->query('SELECT COUNT(*) FROM admins')->fetchColumn()>0;
if(!$exists && $_SERVER['REQUEST_METHOD']==='POST'){
  $n=trim($_POST['name']??''); $em=trim($_POST['email']??''); $pw=$_POST['password']??'';
  if(!csrf_check()) $err[]='Session expired. Reload and try again.';
  if($n==='') $err[]='Enter a name.'; if(!filter_var($em,FILTER_VALIDATE_EMAIL)) $err[]='Enter a valid email.'; if(strlen($pw)<10) $err[]='Use at least 10 characters.';
  if(!$err){ db()->prepare('INSERT INTO admins(name,email,password_hash) VALUES(?,?,?)')->execute([$n,$em,password_hash($pw,PASSWORD_DEFAULT)]); header('Location: index.php'); exit; }
}
?><!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Admin setup</title><link rel="stylesheet" href="../assets/css/admin.css"></head><body class="center">
<form method="post" class="card"><h1>Create the first admin</h1>
<?php if($exists): ?><p class="note">An admin already exists, so setup is closed. <a href="index.php">Log in</a></p>
<?php else: foreach($err as $m): ?><p class="note bad"><?= e($m) ?></p><?php endforeach; echo csrf_field(); ?>
<label>Name<input name="name" required></label><label>Email<input type="email" name="email" required></label>
<label>Password (10+ characters)<input type="password" name="password" minlength="10" required></label><button class="btn">Create admin</button><?php endif; ?></form></body></html>
