<?php
require 'includes/functions.php'; $title='Login'; $err='';
$allowed=['checkout.php','my-orders.php','loyalty.php','cart.php','menu.php','my-account.php']; $next=in_array($_GET['next']??'',$allowed,true)?$_GET['next']:'menu.php';
if($_SERVER['REQUEST_METHOD']==='POST'){
  if(!csrf_check()) $err='Session expired. Reload and try again.';
  else{
    $em=trim($_POST['email']??''); $st=db()->prepare('SELECT * FROM customers WHERE email=? AND is_active=1'); $st->execute([$em]); $u=$st->fetch();
    if(sec_blocked('customer',$em)){ $err=SEC_BLOCK_MSG; }
    elseif($u && password_verify($_POST['password']??'',$u['password_hash'])){
      sec_clear('customer',$em); session_regenerate_id(true); $_SESSION['customer_id']=(int)$u['id']; $_SESSION['customer_name']=$u['name'];
      if(!isset($_GET['next']) && cust_unread_count()>0) $next='my-account.php?section=notifications';
      header('Location: '.$next); exit;
    }
    else{ sec_fail('customer',$em); $err='Email or password is incorrect.'; }
  }
}
require 'includes/header.php'; ?>
<section class="sec wrap narrow"><h2>Welcome back</h2>
<?php if($err): ?><p class="alert"><?= e($err) ?></p><?php endif; ?>
<form method="post" class="form"><?= csrf_field() ?>
<label>Email<input type="email" name="email" required></label>
<label>Password<input type="password" name="password" required></label>
<button class="btn">Log in</button></form>
<p>New here? <a href="register.php"><u>Create an account</u></a></p></section>
<?php require 'includes/footer.php'; ?>
