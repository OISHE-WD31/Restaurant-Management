<?php
require 'includes/cart.php'; $title='Your cart'; $msg='';
if($_SERVER['REQUEST_METHOD']==='POST' && csrf_check()){
  $a=isset($_POST['remove'])?'remove':($_POST['action']??'');
  if($a==='update'){ foreach(($_POST['qty']??[]) as $id=>$q){ $q=(int)$q; if($q<=0) unset($_SESSION['cart'][(int)$id]); else $_SESSION['cart'][(int)$id]=min(20,$q); } }
  elseif($a==='remove'){ unset($_SESSION['cart'][(int)$_POST['remove']]); }
  elseif($a==='coupon'){ if(find_coupon($_POST['code']??'')) $_SESSION['coupon']=strtoupper(trim($_POST['code'])); else{ unset($_SESSION['coupon']); $msg='That coupon is invalid or expired.'; } }
  if($a!=='coupon') { header('Location: cart.php'); exit; }
}
$items=cart_items(); $t=cart_totals($items);
require 'includes/header.php'; ?>
<section class="sec wrap"><h2>Your cart</h2>
<?php if(!$items): ?><p>Your cart is empty. <a href="menu.php"><u>Browse the menu</u></a></p>
<?php else: ?>
<div class="cart-layout">
<form method="post" class="cart-list"><?= csrf_field() ?><input type="hidden" name="action" value="update">
<?php foreach($items as $i): ?>
<div class="cart-row"><img src="<?= product_img($i['image']) ?>" alt=""><div><strong><?= e($i['name']) ?></strong><br><?= money($i['unit']) ?></div>
<input type="number" name="qty[<?= (int)$i['id'] ?>]" value="<?= $i['qty'] ?>" min="0" max="20" aria-label="Quantity">
<b><?= money($i['line']) ?></b>
<button class="link" name="remove" value="<?= (int)$i['id'] ?>">Remove</button></div>
<?php endforeach; ?>
<button class="btn dark">Update quantities</button></form>
<aside class="summary"><h3>Order summary</h3>
<p><span>Subtotal</span><b><?= money($t['subtotal']) ?></b></p>
<p><span>Discount</span><b>-<?= money($t['discount']) ?></b></p>
<p><span>Delivery</span><b><?= money($t['delivery']) ?></b></p>
<p class="grand"><span>Total</span><b><?= money($t['total']) ?></b></p>
<form method="post" class="coupon"><?= csrf_field() ?><input type="hidden" name="action" value="coupon"><input name="code" placeholder="Coupon code" value="<?= e($_SESSION['coupon']??'') ?>"><button class="btn dark">Apply</button></form>
<?php if($msg): ?><p class="alert"><?= e($msg) ?></p><?php endif; ?>
<a class="btn" href="checkout.php">Proceed to checkout</a></aside></div>
<?php endif; ?></section>
<?php require 'includes/footer.php'; ?>
