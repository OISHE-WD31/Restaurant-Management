<?php
require 'includes/sslcommerz.php';
$r=$_SERVER['REQUEST_METHOD']==='POST'?sslc_settle($_POST):['ok'=>false,'msg'=>'No payment details received.'];
pay_page($r['ok']?'Payment received':'Payment not confirmed',$r['msg'],$r['ok']);
