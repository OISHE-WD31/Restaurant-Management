<?php if(!defined('ACCT')) exit;
$view=(int)($_GET['view']??0);
if($view):
    $s=$pdo->prepare('SELECT r.*,t.table_no,t.area FROM table_reservations r LEFT JOIN restaurant_tables t ON t.id=r.table_id WHERE r.id=? AND r.customer_id=?'); $s->execute([$view,$cid]); $r=$s->fetch(); // ownership check
    if(!$r): ?><p class="alert">We could not find that reservation.</p><p><a class="link" href="<?= e(acct_url('reservations')) ?>">&laquo; Back to my reservations</a></p>
    <?php else: ?>
    <p><a class="link" href="<?= e(acct_url('reservations')) ?>">&laquo; Back to my reservations</a></p>
    <article class="order"><header><strong><?= e($r['code']) ?></strong><?= acct_status_badge(RES_LABELS[$r['status']]??$r['status'],$r['status']) ?></header>
    <dl class="acct-dl"><dt>Date</dt><dd><?= e(date('l, d M Y',strtotime($r['res_date']))) ?></dd><dt>Time</dt><dd><?= e(date('g:i A',strtotime($r['start_time']))) ?> – <?= e(date('g:i A',strtotime($r['end_time']))) ?></dd>
    <dt>Guests</dt><dd><?= (int)$r['guests'] ?></dd><dt>Table</dt><dd><?= $r['table_no']?e($r['table_no']).($r['area']?' · '.e($r['area']):''):'Will be assigned by the restaurant' ?></dd>
    <dt>Name</dt><dd><?= e($r['name']) ?></dd><dt>Phone</dt><dd><?= e($r['phone']) ?></dd>
    <?php if(trim((string)$r['notes'])!==''): ?><dt>Special requests</dt><dd><?= e($r['notes']) ?></dd><?php endif; ?>
    <?php if($r['status']==='cancelled'): ?><dt>Cancellation reason</dt><dd><?= e(RES_CANCEL_REASONS[$r['cancel_reason']??'']??'Not given') ?><?= trim((string)$r['cancel_note'])!==''?' – '.e($r['cancel_note']):'' ?></dd><?php endif; ?>
    <dt>Requested on</dt><dd><?= e(date('d M Y, g:i A',strtotime($r['created_at']))) ?></dd></dl>
    <?php if($r['status']==='cancelled'||$r['status']==='rejected'): ?><a class="btn" href="reserve-table.php">Make a new reservation</a><?php endif; ?></article>
    <?php endif;
else:
    $f=(string)($_GET['f']??'all'); if(!in_array($f,['all','upcoming','past'],true)) $f='all';
    $up="(r.res_date>=CURDATE() AND r.status IN ('pending','confirmed','checked_in'))";
    $where=['all'=>'1','upcoming'=>$up,'past'=>"NOT $up"][$f];
    $cnt=$pdo->prepare("SELECT COUNT(*) FROM table_reservations r WHERE r.customer_id=? AND $where"); $cnt->execute([$cid]); $pg=acct_page((int)$cnt->fetchColumn(),8);
    $s=$pdo->prepare("SELECT r.*,t.table_no FROM table_reservations r LEFT JOIN restaurant_tables t ON t.id=r.table_id WHERE r.customer_id=? AND $where ORDER BY ".($f==='upcoming'?'r.res_date,r.start_time':'r.res_date DESC,r.start_time DESC').' LIMIT '.(int)$pg['per'].' OFFSET '.(int)$pg['offset']);
    $s->execute([$cid]); $rows=$s->fetchAll(); ?>
    <div class="chips"><?php foreach(['all'=>'All','upcoming'=>'Upcoming','past'=>'Previous'] as $k=>$l): ?><a class="chip <?= $f===$k?'on':'' ?>" href="<?= e(acct_url('reservations',['f'=>$k])) ?>"><?= $l ?></a><?php endforeach; ?></div>
    <?php if(!$rows): ?><div class="empty-state"><i class="fa-solid fa-calendar-days"></i><p>No reservations to show here.</p><a class="btn" href="reserve-table.php">Reserve a table</a></div><?php endif;
    foreach($rows as $r): ?>
    <article class="order"><header><strong><?= e($r['code']) ?></strong><?= acct_status_badge(RES_LABELS[$r['status']]??$r['status'],$r['status']) ?></header>
    <p><i class="fa-regular fa-calendar"></i> <?= e(date('D, d M Y',strtotime($r['res_date']))) ?> · <?= e(date('g:i A',strtotime($r['start_time']))) ?> · <i class="fa-solid fa-user-group"></i> <?= (int)$r['guests'] ?> guests · <?= $r['table_no']?'Table '.e($r['table_no']):'Table not assigned yet' ?></p>
    <?php if(trim((string)$r['notes'])!==''): ?><p class="hint">Request: <?= e(mb_strimwidth($r['notes'],0,120,'…')) ?></p><?php endif; ?>
    <?php if($r['status']==='cancelled'): ?><p class="hint">Reason: <?= e(RES_CANCEL_REASONS[$r['cancel_reason']??'']??'Not given') ?></p><?php endif; ?>
    <a class="btn dark" href="<?= e(acct_url('reservations',['view'=>$r['id']])) ?>">View details</a></article>
    <?php endforeach; acct_pager($pg,'reservations',['f'=>$f]);
endif; ?>
