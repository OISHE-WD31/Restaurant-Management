<?php if(!defined('ACCT')) exit;
$f=(string)($_GET['f']??'all'); if(!in_array($f,['all','orders','reservations'],true)) $f='all';
$where=['all'=>'1','orders'=>"LEFT(n.type,6)='order_'",'reservations'=>"LEFT(n.type,12)='reservation_'"][$f];
$cnt=$pdo->prepare("SELECT COUNT(*) FROM customer_notifications n WHERE n.customer_id=? AND $where"); $cnt->execute([$cid]); $pg=acct_page((int)$cnt->fetchColumn(),12);
$s=$pdo->prepare("SELECT n.*,o.order_no,r.code FROM customer_notifications n LEFT JOIN orders o ON o.id=n.order_id AND o.customer_id=n.customer_id LEFT JOIN table_reservations r ON r.id=n.reservation_id AND r.customer_id=n.customer_id
    WHERE n.customer_id=? AND $where ORDER BY n.id DESC LIMIT ".(int)$pg['per'].' OFFSET '.(int)$pg['offset']); $s->execute([$cid]); $rows=$s->fetchAll(); ?>
<div class="acct-bar"><div class="chips"><?php foreach(['all'=>'All','orders'=>'Orders','reservations'=>'Reservations'] as $k=>$l): ?><a class="chip <?= $f===$k?'on':'' ?>" href="<?= e(acct_url('notifications',['f'=>$k])) ?>"><?= $l ?></a><?php endforeach; ?></div>
<?php if($unread>0): ?><form method="post" action="<?= e(acct_url('notifications',['f'=>$f])) ?>"><?= csrf_field() ?><input type="hidden" name="do" value="notif_read_all"><input type="hidden" name="f" value="<?= e($f) ?>"><button class="btn dark">Mark all as read (<?= (int)$unread ?>)</button></form><?php endif; ?></div>
<?php if(!$rows): ?><div class="empty-state"><i class="fa-regular fa-bell"></i><p>You have no notifications here yet. We will tell you when your orders and reservations change.</p></div><?php endif;
foreach($rows as $n): ?>
<article class="order note-card<?= $n['is_read']?'':' unread' ?>"><header><strong><?= e($n['title']) ?></strong><span class="badge"><?= $n['is_read']?'Read':'Unread' ?></span></header>
<p><?= e($n['message']) ?></p>
<p class="hint"><?= $n['order_no']?'Order: <b>'.e($n['order_no']).'</b> · ':'' ?><?= $n['code']?'Reservation: <b>'.e($n['code']).'</b> · ':'' ?><?= e(date('d M Y, g:i A',strtotime($n['created_at']))) ?></p>
<div class="addr-actions"><a class="btn dark" href="<?= e(cn_link($n)) ?>" data-notif-id="<?= (int)$n['id'] ?>">View details</a>
<?php if(!$n['is_read']): ?><form method="post" action="<?= e(acct_url('notifications',['f'=>$f])) ?>"><?= csrf_field() ?><input type="hidden" name="do" value="notif_read"><input type="hidden" name="id" value="<?= (int)$n['id'] ?>"><input type="hidden" name="f" value="<?= e($f) ?>"><button class="link">Mark as read</button></form><?php endif; ?></div></article>
<?php endforeach; acct_pager($pg,'notifications',['f'=>$f]); ?>
