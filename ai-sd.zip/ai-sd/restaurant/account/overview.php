<?php if(!defined('ACCT')) exit;
$q=fn($sql,$a=[])=>(function($sql,$a){ $s=db()->prepare($sql); $s->execute($a); return $s; })($sql,$a);
$totalOrders=(int)$q('SELECT COUNT(*) FROM orders WHERE customer_id=?',[$cid])->fetchColumn();
$activeOrders=(int)$q("SELECT COUNT(*) FROM orders WHERE customer_id=? AND status NOT IN ('delivered','cancelled')",[$cid])->fetchColumn();
$totalRes=(int)$q('SELECT COUNT(*) FROM table_reservations WHERE customer_id=?',[$cid])->fetchColumn();
$upRes=(int)$q("SELECT COUNT(*) FROM table_reservations WHERE customer_id=? AND res_date>=CURDATE() AND status IN ('pending','confirmed','checked_in')",[$cid])->fetchColumn();
$pts=(int)$q('SELECT COALESCE(points_balance,0) FROM loyalty_accounts WHERE customer_id=?',[$cid])->fetchColumn();
$recent=$q('SELECT id,order_no,total,status,created_at FROM orders WHERE customer_id=? ORDER BY id DESC LIMIT 5',[$cid])->fetchAll();
$upList=$q("SELECT r.id,r.code,r.res_date,r.start_time,r.guests,r.status FROM table_reservations r WHERE r.customer_id=? AND r.res_date>=CURDATE() AND r.status IN ('pending','confirmed','checked_in') ORDER BY r.res_date,r.start_time LIMIT 5",[$cid])->fetchAll();
$notes=$q('SELECT * FROM customer_notifications WHERE customer_id=? ORDER BY id DESC LIMIT 5',[$cid])->fetchAll();
$cards=[['Total orders',$totalOrders,'fa-bag-shopping','orders'],['Active orders',$activeOrders,'fa-fire-burner','orders'],['Total reservations',$totalRes,'fa-calendar-days','reservations'],
        ['Upcoming reservations',$upRes,'fa-calendar-check','reservations'],['Reward points',$pts,'fa-gift','rewards'],['Unread notifications',$unread,'fa-bell','notifications']]; ?>
<div class="acct-cards"><?php foreach($cards as [$l,$n,$ic,$to]): ?><a class="acct-card" href="<?= e(acct_url($to)) ?>"><i class="fa-solid <?= $ic ?>"></i><b><?= (int)$n ?></b><span><?= e($l) ?></span></a><?php endforeach; ?></div>
<div class="acct-cols">
<div class="acct-box"><h3>Recent orders</h3>
<?php if(!$recent): ?><p class="empty">No orders yet. <a href="menu.php"><u>Order something tasty</u></a></p><?php endif; ?>
<?php foreach($recent as $o): ?><a class="row" href="<?= e(acct_url('orders',['view'=>$o['id']])) ?>"><span><b><?= e($o['order_no']) ?></b><small><?= e(date('d M Y, g:i A',strtotime($o['created_at']))) ?></small></span><span><?= money($o['total']) ?> <?= acct_status_badge(ORDER_LABELS[$o['status']]??$o['status'],$o['status']) ?></span></a><?php endforeach; ?>
<?php if($recent): ?><a class="more" href="<?= e(acct_url('orders')) ?>">View all orders &raquo;</a><?php endif; ?></div>
<div class="acct-box"><h3>Upcoming reservations</h3>
<?php if(!$upList): ?><p class="empty">No upcoming reservations. <a href="reserve-table.php"><u>Reserve a table</u></a></p><?php endif; ?>
<?php foreach($upList as $r): ?><a class="row" href="<?= e(acct_url('reservations',['view'=>$r['id']])) ?>"><span><b><?= e($r['code']) ?></b><small><?= e(date('D, d M Y',strtotime($r['res_date']))) ?> · <?= e(date('g:i A',strtotime($r['start_time']))) ?> · <?= (int)$r['guests'] ?> guests</small></span><?= acct_status_badge(RES_LABELS[$r['status']]??$r['status'],$r['status']) ?></a><?php endforeach; ?>
<?php if($upList): ?><a class="more" href="<?= e(acct_url('reservations')) ?>">View all reservations &raquo;</a><?php endif; ?></div>
</div>
<div class="acct-box"><h3>Recent notifications</h3>
<?php if(!$notes): ?><p class="empty">You have no notifications yet.</p><?php endif; ?>
<?php foreach($notes as $n): ?><a class="row <?= $n['is_read']?'':'unread' ?>" href="<?= e(cn_link($n)) ?>" data-notif-id="<?= (int)$n['id'] ?>"><span><b><?= e($n['title']) ?></b><small><?= e(date('d M Y, g:i A',strtotime($n['created_at']))) ?></small></span><?php if(!$n['is_read']): ?><em class="dot" aria-label="Unread"></em><?php endif; ?></a><?php endforeach; ?>
<?php if($notes): ?><a class="more" href="<?= e(acct_url('notifications')) ?>">View all notifications &raquo;</a><?php endif; ?></div>
