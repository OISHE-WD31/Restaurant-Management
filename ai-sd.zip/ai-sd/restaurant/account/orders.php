<?php if(!defined('ACCT')) exit;
$steps=['pending','confirmed','preparing','ready','out_for_delivery','delivered'];
$view=(int)($_GET['view']??0);
if($view):
    $s=$pdo->prepare('SELECT * FROM orders WHERE id=? AND customer_id=?'); $s->execute([$view,$cid]); $o=$s->fetch();   // ownership check: someone else's id simply finds nothing
    if(!$o): ?><p class="alert">We could not find that order.</p><p><a class="link" href="<?= e(acct_url('orders')) ?>">&laquo; Back to my orders</a></p>
    <?php else: $lines=acct_order_items([$o['id']])[$o['id']]??[]; $cur=array_search($o['status'],$steps,true); ?>
    <p><a class="link" href="<?= e(acct_url('orders')) ?>">&laquo; Back to my orders</a></p>
    <article class="order"><header><strong><?= e($o['order_no']) ?></strong><?= acct_status_badge(ORDER_LABELS[$o['status']]??$o['status'],$o['status']) ?></header>
    <p class="hint">Placed on <?= e(date('d M Y, g:i A',strtotime($o['created_at']))) ?> · <?= e(ucfirst(str_replace('_',' ',$o['order_type']))) ?></p>
    <?php if($o['status']!=='cancelled'&&$cur!==false): ?><ol class="track"><?php foreach($steps as $n=>$st): ?><li class="<?= $n<=$cur?'done':'' ?>"><?= e(ORDER_LABELS[$st]) ?></li><?php endforeach; ?></ol><?php endif; ?>
    <table class="acct-table"><thead><tr><th>Item</th><th>Qty</th><th>Price</th></tr></thead><tbody>
    <?php foreach($lines as $l): ?><tr><td><?= e($l['name']) ?><?= $l['variation']?' <small>('.e($l['variation']).')</small>':'' ?></td><td><?= (int)$l['quantity'] ?></td><td><?= money($l['unit_price']*$l['quantity']) ?></td></tr><?php endforeach; ?></tbody></table>
    <div class="summary"><p><span>Subtotal</span><b><?= money($o['subtotal']) ?></b></p><p><span>Discount</span><b>-<?= money($o['discount']) ?></b></p><p><span>Delivery</span><b><?= money($o['delivery_charge']) ?></b></p><p class="grand"><span>Total</span><b><?= money($o['total']) ?></b></p></div>
    <p><b>Payment:</b> <?= e(acct_pay_label($o)) ?> · <?= e(ucfirst($o['payment_status'])) ?></p>
    <p><b>Delivery address:</b><br><?= nl2br(e($o['address'])) ?></p>
    <?php if(trim((string)$o['notes'])!==''): ?><p><b>Your notes:</b> <?= e($o['notes']) ?></p><?php endif; ?>
    <?php if($o['payment_method']==='online'&&in_array($o['payment_status'],['unpaid','failed','cancelled'],true)&&$o['status']!=='cancelled'&&sslc_ready()): ?><a class="btn" href="payment-start.php?no=<?= e($o['order_no']) ?>">Pay now</a><?php endif; ?></article>
    <?php endif;
else:
    $cnt=$pdo->prepare('SELECT COUNT(*) FROM orders WHERE customer_id=?'); $cnt->execute([$cid]); $pg=acct_page((int)$cnt->fetchColumn(),8);
    $s=$pdo->prepare('SELECT * FROM orders WHERE customer_id=? ORDER BY id DESC LIMIT '.(int)$pg['per'].' OFFSET '.(int)$pg['offset']); $s->execute([$cid]); $orders=$s->fetchAll();
    $items=acct_order_items(array_column($orders,'id'));
    if(!$orders): ?><div class="empty-state"><i class="fa-solid fa-bag-shopping"></i><p>You have not placed any orders yet.</p><a class="btn" href="menu.php">Order something tasty</a></div><?php endif;
    foreach($orders as $o): $cur=array_search($o['status'],$steps,true); ?>
    <article class="order"><header><strong><?= e($o['order_no']) ?></strong><?= acct_status_badge(ORDER_LABELS[$o['status']]??$o['status'],$o['status']) ?></header>
    <p class="hint"><?= e(date('d M Y, g:i A',strtotime($o['created_at']))) ?></p>
    <?php if($o['status']!=='cancelled'&&$cur!==false): ?><ol class="track"><?php foreach($steps as $n=>$st): ?><li class="<?= $n<=$cur?'done':'' ?>"><?= e(ORDER_LABELS[$st]) ?></li><?php endforeach; ?></ol><?php endif; ?>
    <ul><?php foreach(($items[$o['id']]??[]) as $l): ?><li><?= e($l['name']) ?> × <?= (int)$l['quantity'] ?> <b><?= money($l['unit_price']*$l['quantity']) ?></b></li><?php endforeach; ?></ul>
    <p>Total <b><?= money($o['total']) ?></b> · <?= e(acct_pay_label($o)) ?> · Payment: <?= e(ucfirst($o['payment_status'])) ?></p>
    <a class="btn dark" href="<?= e(acct_url('orders',['view'=>$o['id']])) ?>">View details</a>
    <?php if($o['payment_method']==='online'&&in_array($o['payment_status'],['unpaid','failed','cancelled'],true)&&$o['status']!=='cancelled'&&sslc_ready()): ?> <a class="btn" href="payment-start.php?no=<?= e($o['order_no']) ?>">Pay now</a><?php endif; ?></article>
    <?php endforeach; acct_pager($pg,'orders');
endif; ?>
