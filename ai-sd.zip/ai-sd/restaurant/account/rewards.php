<?php if(!defined('ACCT')) exit;
$pdo->prepare('INSERT IGNORE INTO loyalty_accounts(customer_id) VALUES(?)')->execute([$cid]);
$a=$pdo->prepare('SELECT * FROM loyalty_accounts WHERE customer_id=?'); $a->execute([$cid]); $a=$a->fetch();
$R=loy_rules(); $spent=loy_spent($pdo,$cid);
$next=['bronze'=>['Silver',$R['silver_spent']],'silver'=>['Gold',$R['gold_spent']],'gold'=>['VIP',$R['vip_spent']]][$a['tier']]??null;
$rd=$pdo->prepare("SELECT COALESCE(-SUM(points),0) FROM loyalty_transactions WHERE customer_id=? AND type='redeem'"); $rd->execute([$cid]); $redeemed=(int)$rd->fetchColumn();
$h=$pdo->prepare('SELECT * FROM loyalty_transactions WHERE customer_id=? ORDER BY id DESC LIMIT 30'); $h->execute([$cid]); $hist=$h->fetchAll();
$cp=$pdo->prepare('SELECT * FROM coupons WHERE customer_id=? ORDER BY id DESC LIMIT 10'); $cp->execute([$cid]); $coupons=$cp->fetchAll(); ?>
<div class="acct-cards"><div class="acct-card"><i class="fa-solid fa-star"></i><b><?= (int)$a['points_balance'] ?></b><span>Available points</span></div>
<div class="acct-card"><i class="fa-solid fa-arrow-trend-up"></i><b><?= (int)$a['lifetime_points'] ?></b><span>Total earned</span></div>
<div class="acct-card"><i class="fa-solid fa-ticket"></i><b><?= $redeemed ?></b><span>Redeemed</span></div>
<div class="acct-card"><i class="fa-solid fa-medal"></i><b><?= e(ucfirst($a['tier'])) ?></b><span>Your level</span></div></div>
<?php if($next): ?><p class="hint">Next level: <?= e($next[0]) ?> – <?= money(max(0,$next[1]-$spent)) ?> more in completed spending.</p><?php endif; ?>
<p class="hint">You earn 1 point for every <?= (int)$R['spend_per_point'] ?>৳ on delivered, paid orders. Points from refunded orders are removed.</p>
<div class="acct-box"><h3>Available reward</h3><p>Redeem <b><?= (int)$R['redeem_points'] ?> points</b> for a <b><?= money($R['redeem_value']) ?></b> coupon.</p>
<form method="post" action="<?= e(acct_url('rewards')) ?>"><?= csrf_field() ?><input type="hidden" name="do" value="redeem"><button class="btn" <?= (int)$a['points_balance']<(int)$R['redeem_points']?'disabled':'' ?>>Redeem <?= (int)$R['redeem_points'] ?> points</button></form></div>
<?php if($coupons): ?><div class="acct-box"><h3>Your coupons</h3><?php foreach($coupons as $x): ?><p class="row"><span><b><?= e($x['code']) ?></b> · <?= money($x['value']) ?></span><span><?= (int)$x['used_count']>=(int)$x['max_uses']?'Used':'Valid until '.e($x['expires_at']) ?></span></p><?php endforeach; ?></div><?php endif; ?>
<div class="acct-box"><h3>Reward history</h3>
<?php if(!$hist): ?><p class="empty">No activity yet. Your first delivered order earns a welcome bonus.</p><?php endif; ?>
<?php foreach($hist as $t): ?><p class="row"><span><?= e(date('d M Y',strtotime($t['created_at']))) ?> · <?= e($t['note']) ?></span><b class="<?= $t['points']>0?'pos':'neg' ?>"><?= ($t['points']>0?'+':'').(int)$t['points'] ?></b></p><?php endforeach; ?></div>
