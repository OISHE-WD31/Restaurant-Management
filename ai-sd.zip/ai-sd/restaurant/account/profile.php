<?php if(!defined('ACCT')) exit;
$v=$old?['name'=>$old['name']??'','phone'=>$old['phone']??'','email'=>$old['email']??'','gender'=>$old['gender']??'']:['name'=>$c['name'],'phone'=>(string)$c['phone'],'email'=>$c['email'],'gender'=>(string)$c['gender']]; ?>
<?php if($formErr): ?><p class="alert" role="alert"><?= e($formErr) ?></p><?php endif; ?>
<form method="post" action="<?= e(acct_url('profile')) ?>" class="form acct-form" autocomplete="on"><?= csrf_field() ?><input type="hidden" name="do" value="profile_save">
<label>Name<input name="name" value="<?= e($v['name']) ?>" maxlength="100" required autocomplete="name"></label>
<label>Phone number<input name="phone" value="<?= e($v['phone']) ?>" maxlength="20" required autocomplete="tel"></label>
<label>Gender (optional)<select name="gender"><option value="">Prefer not to say</option><?php foreach(['male'=>'Male','female'=>'Female','other'=>'Other'] as $k=>$l): ?><option value="<?= $k ?>" <?= $v['gender']===$k?'selected':'' ?>><?= $l ?></option><?php endforeach; ?></select></label>
<label>Email address<input type="email" name="email" value="<?= e($v['email']) ?>" maxlength="150" required autocomplete="email"></label>
<label>Current password <small>(only needed if you change your email)</small><input type="password" name="current_password" autocomplete="current-password"></label>
<p class="hint">Your email is used to log in. Passwords are not changed on this page.</p>
<div><button class="btn">Save changes</button></div></form>
<p class="hint">Member since <?= e(date('d M Y',strtotime($c['created_at']))) ?></p>
