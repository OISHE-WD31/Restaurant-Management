<?php if(!defined('ACCT')) exit;
$s=$pdo->prepare('SELECT * FROM customer_addresses WHERE customer_id=? ORDER BY is_default DESC,id DESC'); $s->execute([$cid]); $addrs=$s->fetchAll();
$editId=(int)($_GET['edit']??($old['id']??0)); $edit=null; foreach($addrs as $a) if((int)$a['id']===$editId) $edit=$a; if($editId&&!$edit&&!$old) $editId=0;
$f=$old?:($edit?:['address_type'=>'home','full_address'=>'','city'=>'','area'=>'','postal_code'=>'','instructions'=>'']);
$types=['home'=>'Home','work'=>'Work','other'=>'Other']; ?>
<?php if($formErr): ?><p class="alert" role="alert"><?= e($formErr) ?></p><?php endif; ?>
<?php if(!$addrs): ?><p class="empty">You have no saved addresses yet. Add one below and it will be ready at checkout.</p><?php endif; ?>
<div class="addr-grid"><?php foreach($addrs as $a): ?>
<article class="addr <?= $a['is_default']?'is-default':'' ?>"><header><b><i class="fa-solid <?= ['home'=>'fa-house','work'=>'fa-briefcase','other'=>'fa-location-dot'][$a['address_type']] ?? 'fa-location-dot' ?>"></i> <?= e($types[$a['address_type']]??'Other') ?></b><?php if($a['is_default']): ?><span class="badge">Default</span><?php endif; ?></header>
<p><?= e($a['full_address']) ?><br><?= e(trim(($a['area']?$a['area'].', ':'').$a['city'].($a['postal_code']?' '.$a['postal_code']:''))) ?></p>
<?php if($a['instructions']): ?><p class="hint"><i class="fa-regular fa-note-sticky"></i> <?= e($a['instructions']) ?></p><?php endif; ?>
<div class="addr-actions"><a class="link" href="<?= e(acct_url('addresses',['edit'=>$a['id']])) ?>#addr-form">Edit</a>
<?php if(!$a['is_default']): ?><form method="post" action="<?= e(acct_url('addresses')) ?>"><?= csrf_field() ?><input type="hidden" name="do" value="address_default"><input type="hidden" name="id" value="<?= (int)$a['id'] ?>"><button class="link">Set as default</button></form><?php endif; ?>
<form method="post" action="<?= e(acct_url('addresses')) ?>" onsubmit="return confirm('Delete this address?')"><?= csrf_field() ?><input type="hidden" name="do" value="address_delete"><input type="hidden" name="id" value="<?= (int)$a['id'] ?>"><button class="link bad">Delete</button></form></div></article>
<?php endforeach; ?></div>
<div class="acct-box" id="addr-form"><h3><?= $editId?'Edit address':'Add a new address' ?></h3>
<form method="post" action="<?= e(acct_url('addresses')) ?>" class="form acct-form"><?= csrf_field() ?><input type="hidden" name="do" value="address_save"><input type="hidden" name="id" value="<?= (int)$editId ?>">
<label>Address type<select name="address_type"><?php foreach($types as $k=>$l): ?><option value="<?= $k ?>" <?= ($f['address_type']??'')===$k?'selected':'' ?>><?= $l ?></option><?php endforeach; ?></select></label>
<label>Full address<textarea name="full_address" rows="2" maxlength="255" required><?= e($f['full_address']??'') ?></textarea></label>
<div class="two"><label>City<input name="city" maxlength="80" value="<?= e($f['city']??'') ?>" required></label><label>Area<input name="area" maxlength="80" value="<?= e($f['area']??'') ?>"></label></div>
<label>Postal code<input name="postal_code" maxlength="20" value="<?= e($f['postal_code']??'') ?>"></label>
<label>Delivery instructions (optional)<textarea name="instructions" rows="2" maxlength="255"><?= e($f['instructions']??'') ?></textarea></label>
<?php if(!$editId): ?><label class="radio"><input type="checkbox" name="is_default" value="1" <?= !$addrs||!empty($old['is_default'])?'checked':'' ?>> Make this my default address</label><?php endif; ?>
<div><button class="btn"><?= $editId?'Save address':'Add address' ?></button> <?php if($editId): ?><a class="link" href="<?= e(acct_url('addresses')) ?>">Cancel</a><?php endif; ?></div></form></div>
