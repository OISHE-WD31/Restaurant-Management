<?php
require 'includes/functions.php'; $title='Contact'; $err=[]; $sent=isset($_GET['sent']); $v=['name'=>'','email'=>'','message'=>''];
if($_SERVER['REQUEST_METHOD']==='POST'){
  foreach($v as $k=>$_) $v[$k]=trim($_POST[$k]??'');
  if(!csrf_check()) $err[]='Session expired. Reload and try again.';
  if(mb_strlen($v['name'])<2) $err[]='Enter your name.';
  if(!filter_var($v['email'],FILTER_VALIDATE_EMAIL)) $err[]='Enter a valid email address.';
  if(mb_strlen($v['message'])<5||mb_strlen($v['message'])>2000) $err[]='Write a message of 5 to 2000 characters.';
  if(!$err && ($_POST['website']??'')===''){
    db()->prepare('INSERT INTO contact_messages(name,email,message) VALUES(?,?,?)')->execute(array_values($v));
    notify('message','New message received','From '.$v['name'].' ('.$v['email'].'): '.mb_substr($v['message'],0,80),(int)db()->lastInsertId(),'messages.php');
    header('Location: contact.php?sent=1'); exit;
  }
}
require 'includes/header.php'; ?>
<section class="sec wrap"><h2>Contact us</h2><div class="cart-layout">
<div><?php if($sent): ?><p class="ok">Message sent. We will reply soon.</p><?php endif; foreach($err as $m): ?><p class="alert"><?= e($m) ?></p><?php endforeach; ?>
<form method="post" class="form"><?= csrf_field() ?><input type="text" name="website" class="hp" tabindex="-1" autocomplete="off" aria-hidden="true">
<label>Name<input name="name" value="<?= e($v['name']) ?>" required></label><label>Email<input type="email" name="email" value="<?= e($v['email']) ?>" required></label>
<label>Message<textarea name="message" rows="5" required><?= e($v['message']) ?></textarea></label><button class="btn">Send message</button></form></div>
<aside class="summary"><h3>Find us</h3><p><span>Address</span><b><?= e(setting('address')) ?></b></p><p><span>Phone</span><b><?= e(setting('phone')) ?></b></p><p><span>Email</span><b><?= e(setting('email')) ?></b></p><p><span>Hours</span><b><?= e(setting('opening_hours')) ?></b></p></aside></div></section>
<?php require 'includes/footer.php'; ?>
