<?php
require 'includes/functions.php'; $title='Reserve a table'; $err=[]; $done=''; $tips=[];
$v=['name'=>$_SESSION['customer_name']??'','phone'=>'','email'=>'','date'=>'','time'=>'','guests'=>'2','prefer'=>'0','notes'=>'']; $slots=res_slots(); $max=(int)res_cfg()['max_party_size'];
$tables=db()->query("SELECT id,table_no,area,capacity FROM restaurant_tables WHERE status<>'unavailable' ORDER BY area,table_no")->fetchAll();
if($_SERVER['REQUEST_METHOD']==='POST'){
  foreach($v as $k=>$_) $v[$k]=trim($_POST[$k]??'');
  if(!csrf_check()) $err[]='Session expired. Reload and try again.';
  if(mb_strlen($v['name'])<2) $err[]='Enter your name.';
  if(!preg_match('/^\+?[0-9\- ]{7,20}$/',$v['phone'])) $err[]='Enter a valid phone number.';
  if(!filter_var($v['email'],FILTER_VALIDATE_EMAIL)) $err[]='Enter a valid email address.';
  if(mb_strlen($v['notes'])>500) $err[]='Special requests must be under 500 characters.';
  if(!$err && ($e=res_check_when($v['date'],$v['time'],(int)$v['guests']))) $err[]=$e;
  if(!$err){
    $r=res_create(['customer_id'=>$_SESSION['customer_id']??null,'name'=>$v['name'],'phone'=>$v['phone'],'email'=>$v['email'],'date'=>$v['date'],'start'=>$v['time'],'guests'=>(int)$v['guests'],'prefer'=>(int)$v['prefer'],'notes'=>$v['notes']]);
    if($r['ok']) $done=$r['code']; else{ $err[]=$r['msg']; $tips=res_free_slots($v['date'],(int)$v['guests']); }
  }
}
require 'includes/header.php'; ?>
<section class="sec wrap narrow"><h2>Reserve a table</h2>
<?php if($done): ?><p class="ok">Request received. Your reference is <b><?= e($done) ?></b>. We will confirm it shortly. Keep this reference if you need to contact us.</p>
<?php else: foreach($err as $m): ?><p class="alert"><?= e($m) ?></p><?php endforeach; ?>
<?php if($tips): ?><p class="ok">Free times on that day for your party size: <?= e(implode(', ',$tips)) ?></p><?php elseif($err && $_SERVER['REQUEST_METHOD']==='POST' && $v['date']): ?><?php endif; ?>
<form method="post" class="form"><?= csrf_field() ?>
<label>Name<input name="name" value="<?= e($v['name']) ?>" required></label><label>Phone<input name="phone" value="<?= e($v['phone']) ?>" required></label><label>Email<input type="email" name="email" value="<?= e($v['email']) ?>" required></label>
<label>Date<input type="date" name="date" min="<?= date('Y-m-d') ?>" value="<?= e($v['date']) ?>" required></label>
<label>Time<select name="time" required><option value="">Choose a time</option><?php foreach($slots as $s): ?><option <?= $v['time']===$s?'selected':'' ?>><?= e($s) ?></option><?php endforeach; ?></select></label>
<label>Guests<input type="number" name="guests" min="1" max="<?= $max ?>" value="<?= e($v['guests']) ?>" required></label>
<label>Preferred table (optional)<select name="prefer"><option value="0">No preference</option><?php foreach($tables as $t): ?><option value="<?= $t['id'] ?>" <?= (int)$v['prefer']===(int)$t['id']?'selected':'' ?>><?= e($t['table_no'].' · '.$t['area'].' · '.$t['capacity'].' seats') ?></option><?php endforeach; ?></select></label>
<label>Special requests<textarea name="notes" rows="3" maxlength="500"><?= e($v['notes']) ?></textarea></label><button class="btn">Request reservation</button></form><?php endif; ?></section>
<?php require 'includes/footer.php'; ?>
