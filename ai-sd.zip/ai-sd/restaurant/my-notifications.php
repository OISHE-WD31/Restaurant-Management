<?php
// Old address kept working: notifications now live inside My Account.
header('Location: my-account.php?section=notifications'); exit;
