<?php
require 'includes/sslcommerz.php';
if($_SERVER['REQUEST_METHOD']==='POST' && !empty($_POST['tran_id'])) sslc_mark((string)$_POST['tran_id'],'failed');
pay_page('Payment failed','Your payment did not go through and you have not been charged. You can try again from My Orders.',false);
