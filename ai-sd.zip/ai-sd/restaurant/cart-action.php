<?php
require_once 'includes/functions.php';
header('Content-Type: application/json');
if($_SERVER['REQUEST_METHOD']!=='POST'||!hash_equals($_SESSION['csrf']??'',$_SERVER['HTTP_X_CSRF']??'')){ http_response_code(403); exit(json_encode(['ok'=>false,'msg'=>'Invalid request'])); }
$id=(int)($_POST['id']??0); $qty=max(1,min(20,(int)($_POST['qty']??1)));
$st=db()->prepare('SELECT id FROM products WHERE id=? AND is_available=1'); $st->execute([$id]);
if(!$st->fetch()) exit(json_encode(['ok'=>false,'msg'=>'Item unavailable']));
$_SESSION['cart'][$id]=min(20,($_SESSION['cart'][$id]??0)+$qty);
echo json_encode(['ok'=>true,'count'=>cart_count(),'msg'=>'Added to cart']);
