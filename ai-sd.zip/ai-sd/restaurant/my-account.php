<?php
// Customer account dashboard. One page, several sections (?section=...). Logged-out visitors go to the existing login page.
require_once 'includes/account-actions.php'; require_once 'includes/sslcommerz.php';
$c=acct_require('my-account.php'); $cid=(int)$c['id']; $pdo=db(); $title='My Account';
$section=(string)($_GET['section']??'overview'); if(!isset(ACCT_SECTIONS[$section])) $section='overview';
$old=null; $formErr=null; // $old/$formErr keep what the customer typed when a form has an error

if($_SERVER['REQUEST_METHOD']==='POST'){
    $do=(string)($_POST['do']??'');
    if(!csrf_check()){ acct_flash('Your session expired. Please try again.','alert'); header('Location: '.acct_url($section)); exit; }
    $r=null; $stay=false;
    switch($do){
        case 'profile_save':   $r=acct_profile_save($cid,$_POST); $stay=!$r['ok']; $section='profile'; break;
        case 'address_save':   $r=acct_address_save($cid,$_POST,(int)($_POST['id']??0)); $stay=!$r['ok']; $section='addresses'; break;
        case 'address_default':$r=acct_address_default($cid,(int)($_POST['id']??0)); $section='addresses'; break;
        case 'address_delete': $r=acct_address_delete($cid,(int)($_POST['id']??0)); $section='addresses'; break;
        case 'notif_read':     $r=acct_notif_read($cid,(int)($_POST['id']??0)); $section='notifications'; break;
        case 'notif_read_all': $r=acct_notif_read_all($cid); $section='notifications'; break;
        case 'redeem':         $r=loyalty_redeem($cid); $section='rewards'; break;
    }
    if($r){
        if($stay){ $old=$_POST; $formErr=$r['msg']; }          // show the form again with the error, keeping the typed values
        else{ acct_flash($r['msg'],$r['ok']?'ok':'alert'); $keep=[]; if(!empty($_POST['f'])&&in_array($do,['notif_read','notif_read_all'],true)) $keep['f']=(string)$_POST['f']; header('Location: '.acct_url($section,$keep)); exit; }
    }
    $c=acct_customer()??$c;
}
$unread=acct_unread($cid); $flash=acct_flash();
define('ACCT',1);
require 'includes/header.php'; ?>
<section class="sec wrap acct">
<aside class="acct-side">
  <div class="acct-user"><span class="avatar lg"><?= e(mb_strtoupper(mb_substr($c['name'],0,1))) ?></span><div><b><?= e($c['name']) ?></b><small><?= e($c['email']) ?></small></div></div>
  <nav class="acct-nav" aria-label="My account">
  <?php foreach(ACCT_SECTIONS as $k=>[$l,$ic]): ?><a href="<?= e(acct_url($k)) ?>" class="<?= $section===$k?'on':'' ?>" <?= $section===$k?'aria-current="page"':'' ?>><i class="fa-solid <?= $ic ?>"></i><span><?= e($l) ?></span><?php if($k==='notifications'&&$unread>0): ?><em class="alert-badge" data-unread><?= (int)$unread ?></em><?php endif; ?></a><?php endforeach; ?>
  <a href="logout.php" class="out"><i class="fa-solid fa-right-from-bracket"></i><span>Logout</span></a>
  </nav>
</aside>
<div class="acct-main">
  <h2><?= e(ACCT_SECTIONS[$section][0]) ?></h2>
  <?php if($flash): ?><p class="<?= e($flash['kind']==='ok'?'ok':'alert') ?>" role="status"><?= e($flash['msg']) ?></p><?php endif; ?>
  <?php if(!empty($_GET['placed'])): ?><p class="ok">Order <?= e($_GET['placed']) ?> placed. We will confirm it shortly.</p><?php endif; ?>
  <?php require __DIR__.'/account/'.$section.'.php'; ?>
</div>
</section>
<?php require 'includes/footer.php'; ?>
