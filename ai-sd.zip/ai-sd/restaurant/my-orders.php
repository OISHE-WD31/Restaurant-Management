<?php
// Old address kept working: orders now live inside My Account.
$q=['section'=>'orders']; if(!empty($_GET['placed'])) $q['placed']=(string)$_GET['placed'];
header('Location: my-account.php?'.http_build_query($q)); exit;
