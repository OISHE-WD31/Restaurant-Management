<?php
require 'includes/functions.php'; $pdo=db();
function kdeny(): void { http_response_code(403); exit('<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><body style="font-family:sans-serif;text-align:center;padding:60px;background:#FBF3E1;color:#4A2F18"><h2>Kiosk unavailable</h2><p>Please ask a member of staff for help.</p></body>'); }
function kfail(string $m,int $c=400): void { http_response_code($c); exit(json_encode(['ok'=>false,'msg'=>$m])); }
$key=setting('kiosk_key',''); $on=setting('kiosk_enabled','0')==='1';
if(isset($_GET['key'])){ if($on && $key!=='' && hash_equals($key,(string)$_GET['key'])){ session_regenerate_id(true); $_SESSION['kiosk_ok']=hash('sha256',$key); header('Location: kiosk.php'); exit; } kdeny(); }
if(!$on || $key==='' || !hash_equals(hash('sha256',$key),(string)($_SESSION['kiosk_ok']??''))) kdeny();
if($_SERVER['REQUEST_METHOD']==='POST'){
    header('Content-Type: application/json');
    if(!hash_equals($_SESSION['csrf']??'',$_SERVER['HTTP_X_CSRF']??'')) kfail('Please reload the screen and try again.',403);
    if(time()-(int)($_SESSION['kiosk_last']??0)<5) kfail('One moment please, then try again.',429);
    $in=json_decode(file_get_contents('php://input'),true); if(!is_array($in)) kfail('Invalid order.');
    $type=$in['type']??''; if(!in_array($type,['dine_in','takeaway'],true)) kfail('Please choose dine-in or takeaway.');
    $lines=[]; foreach(array_slice((array)($in['items']??[]),0,30) as $l){ $id=(int)($l['id']??0); $q=(int)($l['qty']??0); if($id>0&&$q>=1) $lines[$id]=min(20,($lines[$id]??0)+min(20,$q)); }
    if(!$lines) kfail('Your basket is empty.');
    $st=$pdo->prepare('SELECT * FROM products WHERE is_available=1 AND id IN ('.implode(',',array_fill(0,count($lines),'?')).')'); $st->execute(array_keys($lines)); $prods=$st->fetchAll();
    if(count($prods)!==count($lines)) kfail('Some items are no longer available. Please check your basket.');
    $tid=0; if($type==='dine_in' && (int)($in['table']??0)>0){ $t=$pdo->prepare("SELECT id FROM restaurant_tables WHERE id=? AND status<>'unavailable'"); $t->execute([(int)$in['table']]); $tid=(int)$t->fetchColumn(); }
    $name=mb_substr(trim((string)($in['name']??'')),0,60)?:'Kiosk guest'; $notes=mb_substr(trim((string)($in['notes']??'')),0,200); $sub=0;
    foreach($prods as &$p){ $p['qty']=$lines[$p['id']]; $p['unit']=price_now($p); $sub+=$p['unit']*$p['qty']; } unset($p);
    $no='KSK'.date('ymd').strtoupper(bin2hex(random_bytes(3)));
    try{
        $pdo->beginTransaction();
        $pdo->prepare("INSERT INTO orders(order_no,customer_id,full_name,phone,email,address,notes,subtotal,delivery_charge,discount,total,coupon_id,payment_method,order_source,order_type,table_id) VALUES(?,NULL,?,?,NULL,?,?,?,0,0,?,NULL,'cod','kiosk',?,?)")
            ->execute([$no,$name,'kiosk',$type==='dine_in'?'Dine-in (kiosk)':'Takeaway (kiosk)',$notes,$sub,$sub,$type,$tid?:null]);
        $oid=(int)$pdo->lastInsertId(); $ins=$pdo->prepare('INSERT INTO order_items(order_id,product_id,name,unit_price,quantity) VALUES(?,?,?,?,?)');
        foreach($prods as $p) $ins->execute([$oid,$p['id'],$p['name'],$p['unit'],$p['qty']]);
        $pdo->commit();
    }catch(Throwable $e){ if($pdo->inTransaction()) $pdo->rollBack(); error_log('kiosk order: '.$e->getMessage()); kfail('We could not place your order. Please ask staff for help.',500); }
    $_SESSION['kiosk_last']=time();
    notify('order','New kiosk order','Order '.$no.' · '.money($sub).' · '.($type==='dine_in'?'Dine-in':'Takeaway').' · pay at counter',$oid,'orders.php?q='.$no);
    exit(json_encode(['ok'=>true,'order_no'=>$no,'total'=>$sub]));
}
$cats=$pdo->query('SELECT id,name FROM categories ORDER BY sort_order,name')->fetchAll();
$prods=array_map(fn($p)=>['id'=>(int)$p['id'],'cat'=>(int)$p['category_id'],'name'=>$p['name'],'desc'=>mb_strimwidth((string)$p['description'],0,90,'…'),'price'=>price_now($p),'old'=>$p['discount_price']!==null?(float)$p['price']:null,'img'=>product_img($p['image'])],
    $pdo->query('SELECT * FROM products WHERE is_available=1 ORDER BY name')->fetchAll());
$tables=$pdo->query("SELECT id,table_no FROM restaurant_tables WHERE status<>'unavailable' ORDER BY table_no")->fetchAll();
$J=fn($x)=>json_encode($x,JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT);
?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no"><title><?= e(setting('restaurant_name')) ?> · Order here</title>
<meta name="csrf" content="<?= csrf_token() ?>"><link href="https://fonts.googleapis.com/css2?family=Fraunces:wght@600;700&family=Nunito:wght@400;700&display=swap" rel="stylesheet">
<style>
:root{--cream:#FBF3E1;--sage:#A9B98A;--sage-l:#DCE3C4;--peach:#F7DFC6;--brown:#4A2F18;--orange:#E8873F}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}html,body{height:100%}body{margin:0;background:var(--cream);color:var(--brown);font:400 1.1rem/1.4 Nunito,sans-serif;display:flex;flex-direction:column;touch-action:manipulation}
header{padding:14px 22px;display:flex;justify-content:space-between;align-items:center;background:var(--sage-l)}h1,h2,h3{font-family:Fraunces,serif;margin:0}h1{font-size:1.7rem}
.wrap{flex:1;display:grid;grid-template-columns:1fr 340px;min-height:0}.menu{display:flex;flex-direction:column;min-height:0}
.tabs{display:flex;gap:10px;padding:12px 18px;overflow-x:auto}.tab{border:0;border-radius:999px;padding:14px 26px;background:var(--sage-l);color:var(--brown);font:700 1.1rem Nunito;white-space:nowrap;cursor:pointer}.tab.on{background:var(--brown);color:#fff}
.grid{flex:1;overflow-y:auto;padding:6px 18px 24px;display:grid;grid-template-columns:repeat(auto-fill,minmax(210px,1fr));gap:16px;align-content:start}
.p{background:var(--peach);border-radius:26px;padding:12px;display:flex;flex-direction:column}.p:nth-child(3n+2){background:var(--sage-l)}.p img{width:100%;aspect-ratio:4/3;object-fit:cover;border-radius:18px;background:var(--sage)}
.p h3{font-size:1.15rem;margin:8px 0 2px}.p small{flex:1;opacity:.85}.p .row{display:flex;justify-content:space-between;align-items:center;margin-top:8px}.p s{opacity:.5;font-size:.85rem}
.add{border:0;border-radius:999px;background:var(--orange);color:#fff;font:700 1.15rem Nunito;min-height:52px;padding:0 22px;cursor:pointer}.add:active{transform:scale(.95)}
.cart{background:#fff;border-left:2px solid var(--sage-l);display:flex;flex-direction:column;min-height:0}.cart h2{padding:16px 18px 6px}.lines{flex:1;overflow-y:auto;padding:0 14px}
.line{display:grid;grid-template-columns:1fr auto;gap:4px;padding:10px 0;border-bottom:1px dashed var(--sage)}.qty{display:flex;gap:10px;align-items:center;font-weight:700}.qty button{width:46px;height:46px;border-radius:50%;border:2px solid var(--sage);background:#fff;font-size:1.4rem;color:var(--brown)}
.foot{padding:14px 18px;border-top:2px solid var(--sage-l)}.tot{display:flex;justify-content:space-between;font:700 1.35rem Nunito;margin-bottom:10px}
.go{width:100%;min-height:64px;border:0;border-radius:20px;background:var(--brown);color:#fff;font:700 1.25rem Nunito}.go:disabled{opacity:.4}.empty{padding:20px;opacity:.6}
.ov{position:fixed;inset:0;background:rgba(74,47,24,.6);display:none;align-items:center;justify-content:center;padding:16px;z-index:10}.ov.show{display:flex}
.box{background:var(--cream);border-radius:30px;padding:26px;width:min(560px,100%);max-height:92vh;overflow:auto}.box label{display:block;font-weight:700;margin:12px 0 4px}.box input,.box select,.box textarea{width:100%;padding:14px;border:2px solid var(--sage);border-radius:16px;font:inherit;background:#fff;color:var(--brown)}
.two{display:grid;grid-template-columns:1fr 1fr;gap:12px}.big{min-height:84px;border:3px solid var(--sage);border-radius:22px;background:#fff;font:700 1.2rem Nunito;color:var(--brown)}.big.on{background:var(--orange);border-color:var(--orange);color:#fff}
.err{background:#F7D9C4;border-radius:14px;padding:10px 14px;margin-top:10px;display:none}.num{font:700 3rem Fraunces,serif;text-align:center;margin:10px 0}.c{text-align:center}
@media(max-width:820px){.wrap{grid-template-columns:1fr;grid-template-rows:1fr auto}.cart{border-left:0;border-top:2px solid var(--sage-l);max-height:42vh}}
</style></head><body>
<header><h1><?= e(setting('restaurant_name')) ?></h1><span>Touch to order</span></header>
<div class="wrap"><section class="menu"><div class="tabs" id="tabs"></div><div class="grid" id="grid"></div></section>
<aside class="cart"><h2>Your basket</h2><div class="lines" id="lines"></div><div class="foot"><div class="tot"><span>Total</span><span id="total">৳0</span></div><button class="go" id="next" disabled>Continue</button></div></aside></div>
<div class="ov" id="ov1"><div class="box"><h2>Almost done</h2>
<label>Eating here or taking away?</label><div class="two"><button class="big on" data-t="dine_in" type="button">Dine-in</button><button class="big" data-t="takeaway" type="button">Takeaway</button></div>
<div id="tblw"><label for="tbl">Your table (optional)</label><select id="tbl"><option value="0">I will tell staff</option><?php foreach($tables as $t): ?><option value="<?= (int)$t['id'] ?>">Table <?= e($t['table_no']) ?></option><?php endforeach; ?></select></div>
<label for="nm">Name for your order (optional)</label><input id="nm" maxlength="60" autocomplete="off"><label for="nt">Special instructions (optional)</label><textarea id="nt" rows="2" maxlength="200"></textarea>
<p>You pay at the counter when you collect or finish your meal.</p><div class="err" id="err"></div>
<div class="two" style="margin-top:12px"><button class="big" id="back" type="button">Back</button><button class="big on" id="place" type="button">Place order</button></div></div></div>
<div class="ov" id="ov2"><div class="box c"><h2>Thank you!</h2><p>Your order number is</p><div class="num" id="ono"></div><p>Please pay <b id="otot"></b> at the counter.<br>We will prepare it right away.</p><button class="big on" id="done" type="button" style="width:100%">New order</button></div></div>
<script>
const CATS=<?= $J($cats) ?>,PRODS=<?= $J($prods) ?>,csrf=document.querySelector('meta[name=csrf]').content,cart=new Map();let cat=CATS.length?CATS[0].id:0,type='dine_in',idle,busy=false;
const $=id=>document.getElementById(id),mk=(t,c,x)=>{const n=document.createElement(t);if(c)n.className=c;if(x!==undefined)n.textContent=x;return n},M=n=>'৳'+Math.round(n);
function tabs(){const t=$('tabs');t.replaceChildren();CATS.forEach(c=>{const b=mk('button','tab'+(c.id===cat?' on':''),c.name);b.onclick=()=>{cat=c.id;tabs();grid()};t.append(b)})}
function grid(){const g=$('grid');g.replaceChildren();const l=PRODS.filter(p=>p.cat===cat);if(!l.length)g.append(mk('p','empty','Nothing available in this category.'));
  l.forEach(p=>{const d=mk('div','p'),i=document.createElement('img');i.src=p.img;i.alt='';d.append(i,mk('h3','',p.name),mk('small','',p.desc));
    const r=mk('div','row'),pr=mk('span','',M(p.price));pr.style.fontWeight='700';if(p.old){const s=mk('s','',M(p.old));pr.prepend(s,' ')}const a=mk('button','add','Add');a.onclick=()=>{cart.set(p.id,Math.min(20,(cart.get(p.id)||0)+1));draw()};r.append(pr,a);d.append(r);g.append(d)})}
function draw(){const L=$('lines');L.replaceChildren();let tot=0,n=0;if(!cart.size)L.append(mk('p','empty','Tap Add on any dish to start your order.'));
  cart.forEach((q,id)=>{const p=PRODS.find(x=>x.id===id);if(!p)return;tot+=p.price*q;n+=q;const d=mk('div','line');d.append(mk('b','',p.name),mk('b','',M(p.price*q)));const c=mk('div','qty'),m=mk('button','','−'),pl=mk('button','','+');
    m.onclick=()=>{q>1?cart.set(id,q-1):cart.delete(id);draw()};pl.onclick=()=>{cart.set(id,Math.min(20,q+1));draw()};c.append(m,mk('span','',q),pl);d.append(c);L.append(d)});
  $('total').textContent=M(tot);$('next').disabled=!n;$('next').textContent=n?'Continue ('+n+' item'+(n>1?'s':'')+')':'Continue';bump()}
function reset(){cart.clear();$('nm').value='';$('nt').value='';$('tbl').value='0';type='dine_in';setT();$('ov1').classList.remove('show');$('ov2').classList.remove('show');cat=CATS.length?CATS[0].id:0;tabs();grid();draw()}
function bump(){clearTimeout(idle);idle=setTimeout(()=>{if(!$('ov2').classList.contains('show'))reset()},120000)}
function setT(){document.querySelectorAll('.big[data-t]').forEach(b=>b.classList.toggle('on',b.dataset.t===type));$('tblw').style.display=type==='dine_in'?'block':'none'}
document.querySelectorAll('.big[data-t]').forEach(b=>b.onclick=()=>{type=b.dataset.t;setT()});
$('next').onclick=()=>{$('err').style.display='none';$('ov1').classList.add('show')};$('back').onclick=()=>$('ov1').classList.remove('show');$('done').onclick=reset;
$('place').onclick=async()=>{if(busy)return;busy=true;$('place').disabled=true;const e=$('err');e.style.display='none';
  try{const r=await fetch('kiosk.php',{method:'POST',headers:{'Content-Type':'application/json','X-CSRF':csrf},body:JSON.stringify({type,table:+$('tbl').value,name:$('nm').value,notes:$('nt').value,items:[...cart].map(([id,qty])=>({id,qty}))})});
    const j=await r.json();if(j.ok){$('ov1').classList.remove('show');$('ono').textContent=j.order_no;$('otot').textContent=M(j.total);$('ov2').classList.add('show');cart.clear();draw();setTimeout(()=>{if($('ov2').classList.contains('show'))reset()},20000)}
    else{e.textContent=j.msg||'Something went wrong.';e.style.display='block'}}catch(x){e.textContent='Connection problem. Please try again or ask staff.';e.style.display='block'}
  busy=false;$('place').disabled=false};
['touchstart','click','keydown'].forEach(ev=>document.addEventListener(ev,bump,{passive:true}));setT();tabs();grid();draw();
</script></body></html>
