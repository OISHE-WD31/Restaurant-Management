<?php
require 'includes/functions.php';
unset($_SESSION['customer_id'],$_SESSION['customer_name']); session_regenerate_id(true);
header('Location: index.php');
