<?php
$title='Home';
require 'includes/header.php';
$hero=db()->query('SELECT * FROM products WHERE is_available=1 AND is_featured=1 ORDER BY id LIMIT 1')->fetch();
$featured=db()->query('SELECT * FROM products WHERE is_featured=1 ORDER BY id DESC LIMIT 6')->fetchAll();
$popular=db()->query('SELECT * FROM products WHERE is_popular=1 ORDER BY id DESC LIMIT 6')->fetchAll();
$offers=db()->query('SELECT * FROM products WHERE is_available=1 AND discount_price IS NOT NULL ORDER BY (price-discount_price) DESC LIMIT 3')->fetchAll();
$reviews=db()->query('SELECT name,rating,comment FROM reviews WHERE is_approved=1 AND product_id IS NULL ORDER BY id DESC LIMIT 3')->fetchAll();
?>
<section class="hero">
  <div>
    <span class="price-line"><?= $hero?'From '.money(price_now($hero)):'' ?></span>
    <h1><?= e($hero['name']??'Fresh from our kitchen') ?></h1>
    <p><?= e($hero['description']??'') ?></p>
    <a class="btn dark" href="menu.php">Order now</a>
  </div>
  <img class="hero-img" src="<?= product_img($hero['image']??null) ?>" alt="<?= e($hero['name']??'') ?>">
</section>
<section class="sec wrap"><h2>Featured plates</h2><p class="sub">Picked by our chefs this week.</p>
<div class="grid"><?php foreach($featured as $p) food_card($p,'tall'); ?></div></section>
<section class="sec wrap"><h2>Popular on the menu</h2><p class="sub">What our guests order again and again.</p>
<div class="grid"><?php foreach($popular as $p) food_card($p); ?></div></section>
<?php if($offers): ?><section class="sec wrap"><h2>Special offers</h2><p class="sub">Limited-time prices on guest favourites.</p>
<div class="grid"><?php foreach($offers as $o): ?><a class="offer" href="food-details.php?id=<?= (int)$o['id'] ?>"><span class="save">Save <?= money($o['price']-$o['discount_price']) ?></span><h3><?= e($o['name']) ?></h3><p><s><?= money($o['price']) ?></s> <b><?= money($o['discount_price']) ?></b></p></a><?php endforeach; ?></div></section><?php endif; ?>
<section class="sec wrap"><h2>About our kitchen</h2><p class="sub">We cook in small batches with whole spices, fresh herbs and rice aged for fragrance. <a href="about.php"><u>Read our story</u></a></p></section>
<?php if($reviews): ?><section class="sec wrap"><h2>What guests say</h2><div class="grid"><?php foreach($reviews as $r): ?><blockquote class="quote"><div class="stars"><?= stars((float)$r['rating']) ?></div><p><?= e($r['comment']) ?></p><footer><?= e($r['name']) ?></footer></blockquote><?php endforeach; ?></div></section><?php endif; ?>
<section class="sec wrap"><h2>Visit or get in touch</h2><p class="sub"><?= e(setting('address')) ?> · <?= e(setting('phone')) ?> · <a href="contact.php"><u>Send a message</u></a></p></section>
<?php require 'includes/footer.php'; ?>
